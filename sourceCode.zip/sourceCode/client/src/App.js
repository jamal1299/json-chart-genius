import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import HowToUse from "./components/HowToUse";
import Services from "./components/Services"
import NewsLetter from "./components/NewsLetter";
import OurTeam from "./components/OurTeam";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

function App() {
  return (
    <>
      <div class="container-xxl bg-white p-0">
        <Navbar />
        <Hero />
        <HowToUse />
        <Services />
        <NewsLetter />
        <OurTeam />
        <Contact />
        <Footer />

        <a href="/#" class="btn btn-lg btn-secondary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
      </div >
    </>


  );
}

export default App;
