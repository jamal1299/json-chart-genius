import React, { useEffect, useRef, useState } from "react";
import axios from 'axios';
import hljs from 'highlight.js/lib/core';
import 'highlight.js/styles/atom-one-dark.css';
import javascript from 'highlight.js/lib/languages/javascript';
import python from 'highlight.js/lib/languages/python';
import html from 'highlight.js/lib/languages/xml';
import ALLCharts from './items'


hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('python', python);
hljs.registerLanguage('html', html);

function RenderChart(props) {
    const jsonFile = useRef();
    const jsonForm = useRef();
    const fileStatus = useRef();
    const [copiedHtml, setCopiedHtml] = useState(false);
    const [copiedJs, setCopiedJs] = useState(false);
    const [copiedPy, setCopiedPy] = useState(false);
    const [copiedPip, setCopiedPip] = useState(false);
    const [clicked, setclick] = useState(false);
    const [jsonData, setJsonData] = useState(props.exampleData);
    const [title, setTitle] = useState(props.title);
    const [titleAlignment, setTitleAlignment] = useState(props.titleAlignment);
    const [subTitle, setsubTitle] = useState(props.subTitle);
    const [subTitleAlignment, setSubTitleAlignment] = useState(props.subTitleAlignment);
    const [yAxistext, setYAxistext] = useState(props.yAxistext);
    const [xAxistext, setXAxistext] = useState(props.xAxistext);
    const [chartType, setChartType] = useState(props.ChartName);
    const [globalData, setGlobalData] = useState();
    const [dataKeySelect, setDataKeySelect] = useState("");
    const [dataNameSelect, setDataNameSelect] = useState("");
    const [dateKey, setDateKey] = useState("");
    const [openValue, setOpenValue] = useState("");
    const [highValue, setHighValue] = useState("");
    const [lowValue, setLowValue] = useState("");
    const [closeValue, setCloseValue] = useState("");
    const [showCodeSnippetsJS, setShowCodeSnippetsJS] = useState(true);
    const [showCodeSnippetsPY, setShowCodeSnippetsPY] = useState(false);
    const [selectionofKey, setSelectionofKey] = useState(false);
    const [languageSelection, setLanguageSelection] = useState("JS");
    const scrollToBox = useRef(null);
    const scrollToChart = useRef(null);
    const selectYValue = useRef(null);
    const selectDateValue = useRef(null);
    const selectOpenValue = useRef(null);
    const selectHighValue = useRef(null);
    const selectLowValue = useRef(null);
    const selectCloseValue = useRef(null)
    const selectXName = useRef(null)
    const [minColor, setMincolor] = useState();
    const [maxColor, setMaxColor] = useState();
    const [stockColor, setStockColor] = useState();
    const [treeColor, setTreeColor] = useState();
    const [testData, setTestData] = useState(props.exampleData);
    const filteredChart = ALLCharts.filter(item => item.category === props.category);
    const initialIndex = filteredChart.findIndex(item => props.ChartName === item.title);
    const lengthOfChart = filteredChart.length - 1;
    const [isStockChart, setIsStockChart] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(initialIndex);
    const [program, setProgram] = useState(`Highcharts.chart('container', {
    chart: {
        type: 'spline'
    },
    title: {
        text: 'Snow depth at Vikjafjellet, Norway'
    },
    subtitle: {
        text: 'Irregular time data in Highcharts JS'
    },
    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: {
            // don't display the year
            month: '%e. %b',
            year: '%b'
        },
        title: {
            text: 'Date'
        }
    },
    yAxis: {
        title: {
            text: 'Snow depth (m)'
        },
        min: 0
    },
    tooltip: {
        headerFormat: '<b>{series.name}</b><br>',
        pointFormat: '{point.x:%e. %b}: {point.y:.2f} m'
    },

    plotOptions: {
        series: {
            marker: {
                symbol: 'circle',
                fillColor: '#FFFFFF',
                enabled: true,
                radius: 2.5,
                lineWidth: 1,
                lineColor: null
            }
        }
    },

    colors: ['#6CF', '#39F', '#06C', '#036', '#000'],

    series: chartData
});
  `);
    const [PYProgram, setPYProgram] = useState();
    const htmlCode = `&lt;!DOCTYPE html&gt;
  &lt;html lang="en"&gt;
  &lt;head&gt;
  &lt;meta charset="utf-8"&gt;
  &lt;title&gt;JSON chart Genius&lt;/title&gt;
  &lt;meta content="width=device-width, initial-scale=1.0" name="viewport"&gt;
  &lt;meta content="" name="keywords"&gt;
  &lt;meta content="" name="description"&gt;
  &lt;script src="https://code.highcharts.com/highcharts.js"&gt;&lt;/script&gt;
  &lt;script src="https://code.highcharts.com/highcharts-more.js"&gt;&lt;/script&gt;
  &lt;script src="https://code.highcharts.com/modules/exporting.js"&gt;&lt;/script&gt;
  &lt;/head&gt;
  &lt;body&gt;
  &lt;div id="container"&gt;&lt;/div&gt;
  &lt;/body&gt;
  &lt;script src="script.js"&gt;&lt;/script&gt;
  &lt;/html&gt;
`;
    useEffect(() => {
        const fetchData = async () => {
            try {
                const requestData = {
                    chartType: chartType,
                    userData: jsonData,
                    title: title,
                    titleAlignment: titleAlignment,
                    subTitle: subTitle,
                    subTitleAlignment: subTitleAlignment,
                    yAxistext: yAxistext,
                    xAxistext: xAxistext
                };
                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
        scrollToBox.current.scrollIntoView({ behavior: 'smooth' });
        if (props.category === "Stock Charts") {
            setIsStockChart(true);
        }
    }, []);

    const getFile = (event) => {
        const selectedFile = event.target.files[0];
        if (selectedFile) {
            if (selectedFile.name.endsWith(".json")) {
                const reader = new FileReader();
                reader.onload = (fileEvent) => {
                    try {
                        fileStatus.current.innerText = 'File is a valid JSON with content';
                        fileStatus.current.style.color = 'black';
                        fileStatus.current.style.display = 'block';

                        setGlobalData(JSON.parse(fileEvent.target.result));
                        // ... rest of your code
                    } catch (error) {
                        if (error instanceof SyntaxError && error.message.includes("Unexpected token")) {
                            fileStatus.current.innerText = 'File contains incomplete or invalid JSON content.';
                            fileStatus.current.style.color = 'red';
                            fileStatus.current.style.display = 'block';
                            jsonForm.current.reset();
                        } else {
                            fileStatus.current.innerText = 'Error parsing JSON';
                            fileStatus.current.style.color = 'red';
                            fileStatus.current.style.display = 'block';
                            jsonForm.current.reset();
                        }
                    }
                };
                // Read the file as text
                reader.readAsText(selectedFile);
            } else {
                fileStatus.current.innerText = 'Selected file is not a JSON file.';
                fileStatus.current.style.color = 'red';
                fileStatus.current.style.display = 'block';
                jsonForm.current.reset();
            }
        }
    };
    const handleLanguageSelectionChange = (event) => {
        setLanguageSelection(event.target.value);

    };
    useEffect(() => {
        if (languageSelection === 'JS') {
            setShowCodeSnippetsJS(true);
            setShowCodeSnippetsPY(false);
        } else if (languageSelection === 'PY') {
            setShowCodeSnippetsPY(true);
            setShowCodeSnippetsJS(false);
        }
    }, [languageSelection]);
    function extractUniqueKeys(data) {
        const keys = new Set();
        // Convert array of objects to a single object
        if (Array.isArray(data)) {
            const combinedObject = {};
            data.forEach(obj => {
                Object.keys(obj).forEach(key => {
                    combinedObject[key] = obj[key];
                });
            });
            data = combinedObject;
        }
        // Extract keys from object
        if (typeof data === 'object') {
            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    keys.add(key);
                    if (Array.isArray(data[key])) {
                        const containsObject = data[key].some(item => typeof item === 'object');
                        if (containsObject) {
                            data[key].forEach(item => {
                                if (typeof item === 'object') {
                                    const nestedKeys = extractUniqueKeys(item);
                                    nestedKeys.forEach(nestedKey => keys.add(key + '.' + nestedKey));
                                }
                            });
                        }
                    } else if (typeof data[key] === 'object') {
                        const nestedKeys = extractUniqueKeys(data[key]);
                        nestedKeys.forEach(nestedKey => keys.add(key + '.' + nestedKey));
                    }
                }
            }
        }
        return Array.from(keys);
    }
    function findFullPath(data, targetKey, currentPath = '') {
        if (typeof data !== 'object' || data === null) {
            return '';
        }

        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const newPath = currentPath === '' ? key : currentPath + '.' + key;
                const parts = newPath.split('.');
                const strippedParts = parts.map(part => {
                    if (/^\d+$/.test(part)) {
                        return ''; // Remove leading integers
                    }
                    return part;
                });
                const strippedPath = strippedParts.filter(part => part !== '').join('.');
                if (key === targetKey) {
                    return strippedPath;
                }
                const fullPath = findFullPath(data[key], targetKey, newPath);
                if (fullPath !== '') {
                    return fullPath;
                }
            }
        }

        return '';
    }
    const submitData = async () => {
        if (!jsonFile.current.files[0]) {
            fileStatus.current.innerText = "Upload a JSON file";
            fileStatus.current.style.color = "red";
            fileStatus.current.style.display = 'block';
        } else {
            try {
                const file = jsonFile.current.files[0];
                const reader = new FileReader();
                fileStatus.current.innerText = "";
                fileStatus.current.style.display = 'none';
                reader.onload = function (event) {
                    try {
                        setSelectionofKey(true);
                        let jsonData = JSON.parse(event.target.result);

                        if (props.category === "Stock Charts") {
                            const selectDate = selectDateValue.current;
                            const selectOpen = selectOpenValue.current;
                            const selectHigh = selectHighValue.current;
                            const selectLow =  selectLowValue.current;
                            const selectClose = selectCloseValue.current;
                            if (selectDate) {
                                selectDate.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectDate.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectDate.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectDate.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }
                            if (selectOpen) {
                                selectOpen.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectOpen.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectOpen.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectOpen.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }
                            if (selectHigh) {
                                selectHigh.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectHigh.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectHigh.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectHigh.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }
                            if (selectLow) {
                                selectLow.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectLow.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectLow.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectLow.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }
                            if (selectClose) {
                                selectClose.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectClose.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectClose.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectClose.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }

                        } else {
                            // Populate selectYValue
                            const selectElementY = selectYValue.current;
                            if (selectElementY) {
                                selectElementY.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionY = null;
                                const keysY = extractUniqueKeys(jsonData);
                                keysY.forEach(key => {
                                    const optionY = document.createElement('option');
                                    const partsY = key.split('.');
                                    if (partsY.length > 1) {
                                        const optgroupLabelY = partsY.slice(0, partsY.length - 1).join('.');
                                        let optgroupY = selectElementY.querySelector(`optgroup[label="${optgroupLabelY}"]`);
                                        if (!optgroupY) {
                                            optgroupY = document.createElement('optgroup');
                                            optgroupY.label = optgroupLabelY;
                                            selectElementY.appendChild(optgroupY);
                                        }
                                        optionY.textContent = partsY[partsY.length - 1];
                                        optionY.classList.add(`indent-${partsY.length - 1}`);
                                        optgroupY.appendChild(optionY);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionY && previousOptionY.parentNode !== optgroupY) {
                                            previousOptionY.remove();
                                        }
                                    } else {
                                        optionY.textContent = key;
                                        selectElementY.appendChild(optionY);
                                    }
                                    // Update previous option tag
                                    previousOptionY = optionY;
                                });
                            }
                            // Populate selectXName
                            const selectElementX = selectXName.current;
                            if (selectElementX) {
                                selectElementX.innerHTML = '<option value="">Select a key</option>';
                                let previousOptionX = null;
                                const keysX = extractUniqueKeys(jsonData);
                                keysX.forEach(key => {
                                    const optionX = document.createElement('option');
                                    const partsX = key.split('.');
                                    if (partsX.length > 1) {
                                        const optgroupLabelX = partsX.slice(0, partsX.length - 1).join('.');
                                        let optgroupX = selectElementX.querySelector(`optgroup[label="${optgroupLabelX}"]`);
                                        if (!optgroupX) {
                                            optgroupX = document.createElement('optgroup');
                                            optgroupX.label = optgroupLabelX;
                                            selectElementX.appendChild(optgroupX);
                                        }
                                        optionX.textContent = partsX[partsX.length - 1];
                                        optionX.classList.add(`indent-${partsX.length - 1}`);
                                        optgroupX.appendChild(optionX);
                                        // Remove the previous option if it exists and is not yet removed
                                        if (previousOptionX && previousOptionX.parentNode !== optgroupX) {
                                            previousOptionX.remove();
                                        }
                                    } else {
                                        optionX.textContent = key;
                                        selectElementX.appendChild(optionX);
                                    }
                                    // Update previous option tag
                                    previousOptionX = optionX;
                                });
                            }
                        }


                    } catch (error) {
                        console.error(error);
                    }
                };
                reader.readAsText(file);
            } catch (error) {
                console.error(error);
            }
        }
    };
    const handleCopyHtml = () => {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = htmlCode;
        const htmlText = tempElement.innerText;
        navigator.clipboard.writeText(htmlText)
            .then(() => {
                setCopiedHtml(true);
                setTimeout(() => {
                    setCopiedHtml(false);
                }, 1000);
            })
            .catch(err => console.error('Failed to copy HTML: ', err));
    };
    const handleCopyPy = () => {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = PYProgram;
        const PyCode = tempElement.innerText;
        navigator.clipboard.writeText(PyCode)
            .then(() => {
                setCopiedPy(true);
                setTimeout(() => {
                    setCopiedPy(false);
                }, 1000);
            })
            .catch(err => console.error('Failed to copy Python: ', err));
    };
    const handleCopyPip = () => {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = "pip install highcharts-core";
        const PipCode = tempElement.innerText;
        navigator.clipboard.writeText(PipCode)
            .then(() => {
                setCopiedPip(true);
                setTimeout(() => {
                    setCopiedPip(false);
                }, 1000);
            })
            .catch(err => console.error('Failed to copy Python: ', err));
    };
    const handleCopyJs = () => {
        navigator.clipboard.writeText(program)
            .then(() => {
                setCopiedJs(true);
                setTimeout(() => {
                    setCopiedJs(false);
                }, 1000);
            })
            .catch(err => console.error('Failed to copy JS: ', err));
    };
    const handleClicks = () => {
        if (clicked) {
            setclick(false);
        } else {
            setclick(true)
        }
    }
    const handleInputChange = (setState) => (event) => {
        setState(event.target.value); // Update the state with the new value
    };
    const renderLabels = () => {
        let labelForColor = '';
        if (props.category === "Heat Maps" && props.treeMap === "Not") {
            labelForColor = <>
                <div key='1'>
                    <label htmlFor={`sColors_1`}>Min Color</label>
                    <input
                        id={`sColors_1`}
                        type="color"
                        value={minColor}
                        onChange={(event) => { setMincolor(event.target.value) }} // Handle color change
                    />
                </div>
                <div key='2'>
                    <label htmlFor={`sColors_2`}>Max Color</label>
                    <input
                        id={`sColors_2`}
                        type="color"
                        value={maxColor}
                        onChange={(event) => { setMaxColor(event.target.value) }} // Handle color change
                    />
                </div>
            </>
                ;

        } else if (props.category === "Stock Charts") {
            labelForColor = <>
                <div key='1'>
                    <label htmlFor={`sColors_1`}>Color</label>
                    <input
                        id={`sColors_1`}
                        type="color"
                        value={stockColor}
                        onChange={(event) => { setStockColor(event.target.value) }} // Handle color change
                    />
                </div>

            </>;

        }
        else if (props.treeMap === "Tree") {
            labelForColor = <>
                <div key='1'>
                    <label htmlFor={`sColors_1`}>Color</label>
                    <input
                        id={`sColors_1`}
                        type="color"
                        value={treeColor}
                        onChange={(event) => { setTreeColor(event.target.value) }} // Handle color change
                    />
                </div>

            </>;

        }
        else {
            labelForColor = testData.map((item, index) => (
                <div key={index}>
                    <label htmlFor={`sColors_${index}`}>{item.name}</label>
                    <input
                        id={`sColors_${index}`}
                        type="color"
                        onChange={(event) => handleColorChange(index, event)} // Handle color change
                    />
                </div>
            ));
        }

        return labelForColor;
    };
    const handleColorChange = (index, event) => {
        const newTestData = [...testData];
        newTestData[index].color = event.target.value;
        setTestData(newTestData);
    };
    const updateChart = () => {
        const fetchData = async () => {
            try {

                let requestData = '';
                if (props.category === "Heat Maps" && props.treeMap === "Not") {
                    requestData = {
                        chartType: chartType,
                        userData: jsonData,
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext,
                        minColor: minColor,
                        maxColor: maxColor
                    };
                } else if (props.category === "Stock Charts") {
                    requestData = {
                        chartType: chartType,
                        userData: jsonData,
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext,
                        stockColor: stockColor
                    };
                }
                else if (props.treeMap === "Tree") {
                    requestData = {
                        chartType: chartType,
                        userData: jsonData,
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext,
                        treeColor: treeColor
                    };
                }
                else {
                    const updatedJsonData = jsonData.map(item => {
                        const matchingTestData = testData.find(testItem => testItem.name === item.name);
                        if (matchingTestData) {
                            return { ...item, color: matchingTestData.color };
                        } else {
                            return item;
                        }
                    });
                    setJsonData(updatedJsonData)
                    requestData = {
                        chartType: chartType,
                        userData: jsonData,
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext
                    };
                }

                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }
    const generateChart = async () => {
        try {
            const isSeriesChart = (props.category === "Pie Charts" || props.category === "Stock Charts" || props.category === "Heat Maps" ) ? false : true;  
            let jsonData = globalData;
            if (isSeriesChart) {
                let selectedKey = selectYValue.current.value;
                let selectName = selectXName.current.value;
                // Search for the selected values in the JSON data array and extract corresponding data
                const fullPath = findFullPath(globalData, selectedKey);
                if (fullPath) {
                    let values = [];
                    if (Array.isArray(jsonData)) {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(parent)) {
                                    const nestedValue = obj[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                values.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        values.push(nestedValue[child]);
                                    }
                                }
                            }
                        } else {
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(fullPath)) {
                                    values.push(obj[fullPath]);
                                }
                            }
                        }
                    } else if (typeof jsonData === 'object') {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            if (jsonData.hasOwnProperty(parent)) {
                                const nestedValue = jsonData[parent];
                                if (Array.isArray(nestedValue)) {
                                    for (const item of nestedValue) {
                                        if (item.hasOwnProperty(child)) {
                                            values.push(item[child]);
                                        }
                                    }
                                } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                    values.push(nestedValue[child]);
                                }
                            }
                        } else {
                            if (jsonData.hasOwnProperty(fullPath)) {
                                values.push(jsonData[fullPath]);
                            }
                        }
                    } else {
                        alert('jsonData is not an array or an object.');
                    }


                    const fullPathName = findFullPath(globalData, selectName); // Using the same logic as fullPath
                    if (fullPathName) {
                        let nameValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    nameValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            nameValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathName)) {
                                        nameValues.push(obj[fullPathName]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                nameValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        nameValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathName)) {
                                    nameValues.push(globalData[fullPathName]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }

                        var newData = values.map((item, index) => ({
                            data: item,
                            name: nameValues[index],
                        }));
                    } else {
                        alert('Please select a name key first.');
                    }
                } else {
                    alert('Please select a key first.');
                }
                setTestData(newData);
                // Function to check if the 'data' property in each element of newData is an array
                const isArrayInSpecifiedForm = (data) => {
                    // Check if all 'data' properties in newData are arrays
                    return data.every(obj => Array.isArray(obj.data));
                };
                if (!isArrayInSpecifiedForm(newData)) {
                    // ('Data is not in specified form. Transforming...');

                    // Extract 'data' and 'name' arrays from newData
                    const dataArray = newData.map(obj => obj.data);
                    const nameArray = newData.map(obj => obj.name);

                    // Combine 'data' arrays into a single array
                    const combinedData = [].concat(...dataArray);

                    // Create the transformed data object
                    const transformedData = {
                        data: combinedData,
                        name: nameArray
                    };
                    setTestData([transformedData]);

                    setJsonData([transformedData]);
                    const requestData = {
                        chartType: chartType,
                        userData: [transformedData],
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext
                    };

                    // Send the new data to the server
                    const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                    setProgram(response.data.generatedCode);
                    setPYProgram(response.data.generatedCodePy);
                    const script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.innerHTML = response.data.generatedCode;
                    document.getElementById('container').appendChild(script);
                    hljs.highlightAll();

                } else {
                    setJsonData(newData);
                    setTestData(newData);
                    const requestData = {
                        chartType: chartType,
                        userData: newData, // Use the new data instead of jsonData
                        title: title,
                        titleAlignment: titleAlignment,
                        subTitle: subTitle,
                        subTitleAlignment: subTitleAlignment,
                        yAxistext: yAxistext,
                        xAxistext: xAxistext
                    };

                    // Send the new data to the server
                    const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                    setProgram(response.data.generatedCode);
                    setPYProgram(response.data.generatedCodePy);
                    const script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.innerHTML = response.data.generatedCode;
                    document.getElementById('container').appendChild(script);
                    hljs.highlightAll();

                }


            }
            else if (props.category === "Heat Maps" && props.treeMap === "Not") {
                let selectedKey = selectYValue.current.value;
                let selectName = selectXName.current.value;
                // Search for the selected values in the JSON data array and extract corresponding data
                const fullPath = findFullPath(globalData, selectedKey);
                if (fullPath) {
                    let values = [];
                    if (Array.isArray(jsonData)) {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(parent)) {
                                    const nestedValue = obj[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                values.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        values.push(nestedValue[child]);
                                    }
                                }
                            }
                        } else {
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(fullPath)) {
                                    values.push(obj[fullPath]);
                                }
                            }
                        }
                    } else if (typeof jsonData === 'object') {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            if (jsonData.hasOwnProperty(parent)) {
                                const nestedValue = jsonData[parent];
                                if (Array.isArray(nestedValue)) {
                                    for (const item of nestedValue) {
                                        if (item.hasOwnProperty(child)) {
                                            values.push(item[child]);
                                        }
                                    }
                                } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                    values.push(nestedValue[child]);
                                }
                            }
                        } else {
                            if (jsonData.hasOwnProperty(fullPath)) {
                                values.push(jsonData[fullPath]);
                            }
                        }
                    } else {
                        alert('jsonData is not an array or an object.');
                    }
                    var newDataValue = values.map((item) => ({
                        data: item,
                    }));
                } else {
                    alert('Please select a key first.');
                }
                const transformToHeatmapData = (inputData) => {
                    let heatmapValue = [];
                    inputData.forEach((item) => {
                        if (Array.isArray(item.data)) {
                            // If item.data is an array, flatten it and push its elements into heatmapValue
                            heatmapValue.push(...item.data);
                        } else {
                            // If item.data is not an array, push it directly into heatmapValue
                            heatmapValue.push(item.data);
                        }

                    });
                    let resultArray = [];
                    if (heatmapValue.length > 15) {
                        let column = 0;
                        let pointer = 0;
                        for (let row = 0; row < heatmapValue.length; row++) {
                            if (pointer === 5) {
                                column++;
                                pointer = 0; // Reset p to 0
                            }
                            pointer++;
                            resultArray.push([column, pointer, heatmapValue[row]]);
                        }

                    } else {
                        let column = 0;
                        let pointer = 0;
                        for (let row = 0; row < heatmapValue.length; row++) {
                            if (pointer === 3) {
                                column++;
                                pointer = 0; // Reset p to 0
                            }
                            pointer++;
                            resultArray.push([column, pointer, heatmapValue[row]]);
                        }

                    }
                    return resultArray;

                };
                const transformedData = transformToHeatmapData(newDataValue);
                setTestData(transformedData);
                setJsonData(transformedData);
                const requestData = {
                    chartType: chartType,
                    userData: transformedData,
                    title: title,
                    titleAlignment: titleAlignment,
                    subTitle: subTitle,
                    subTitleAlignment: subTitleAlignment,
                    yAxistext: yAxistext,
                    xAxistext: xAxistext
                };

                // Send the new data to the server
                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();

            }
            else if (props.treeMap === "Tree") {
                let selectedKey = selectYValue.current.value;
                let selectName = selectXName.current.value;
                // Search for the selected values in the JSON data array and extract corresponding data
                const fullPath = findFullPath(globalData, selectedKey);
                if (fullPath) {
                    let values = [];
                    if (Array.isArray(jsonData)) {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(parent)) {
                                    const nestedValue = obj[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                values.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        values.push(nestedValue[child]);
                                    }
                                }
                            }
                        } else {
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(fullPath)) {
                                    values.push(obj[fullPath]);
                                }
                            }
                        }
                    } else if (typeof jsonData === 'object') {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            if (jsonData.hasOwnProperty(parent)) {
                                const nestedValue = jsonData[parent];
                                if (Array.isArray(nestedValue)) {
                                    for (const item of nestedValue) {
                                        if (item.hasOwnProperty(child)) {
                                            values.push(item[child]);
                                        }
                                    }
                                } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                    values.push(nestedValue[child]);
                                }
                            }
                        } else {
                            if (jsonData.hasOwnProperty(fullPath)) {
                                values.push(jsonData[fullPath]);
                            }
                        }
                    } else {
                        alert('jsonData is not an array or an object.');
                    }

                    const fullPathName = findFullPath(globalData, selectName); // Using the same logic as fullPath
                    if (fullPathName) {
                        let nameValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    nameValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            nameValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathName)) {
                                        nameValues.push(obj[fullPathName]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                nameValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        nameValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathName)) {
                                    nameValues.push(globalData[fullPathName]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }

                        var extractedData = values.map((item, index) => ({
                            name: nameValues[index],
                            value: item
                        }));
                    } else {
                        alert('Please select a name key first.');
                    }
                } else {
                    alert('Please select a key first.');
                }

                // If 'y' is an array, create multiple objects for each value
                const transformedData = extractedData.flatMap(item => {
                    if (Array.isArray(item.value)) {
                        return item.value.map(value => ({ value, name: item.name }));
                    } else {
                        return [item]; // If 'y' is not an array, return the item as a single-element array
                    }
                });
                console.log(transformedData);
                setJsonData(transformedData);
                setTestData(transformedData);
                const requestData = {
                    chartType: chartType,
                    userData: transformedData, // Use the new data instead of jsonData
                    title: title,
                    titleAlignment: titleAlignment,
                    subTitle: subTitle,
                    subTitleAlignment: subTitleAlignment,
                    yAxistext: yAxistext,
                    xAxistext: xAxistext
                };

                // Send the new data to the server
                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();

            }
            else if (props.category === "Stock Charts") {
                const selectedDate = selectDateValue.current.value;
                const selectedOpenValue = selectOpenValue.current.value;
                const selectedHighValue = selectHighValue.current.value;
                const selectedLowValue = selectLowValue.current.value;
                const selectedCloseValue = selectCloseValue.current.value;
                const fullPath = findFullPath(globalData, selectedDate);
                if (fullPath) {
                    let values = [];
                    if (Array.isArray(jsonData)) {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(parent)) {
                                    const nestedValue = obj[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                values.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        values.push(nestedValue[child]);
                                    }
                                }
                            }
                        } else {
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(fullPath)) {
                                    values.push(obj[fullPath]);
                                }
                            }
                        }
                    } else if (typeof jsonData === 'object') {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            if (jsonData.hasOwnProperty(parent)) {
                                const nestedValue = jsonData[parent];
                                if (Array.isArray(nestedValue)) {
                                    for (const item of nestedValue) {
                                        if (item.hasOwnProperty(child)) {
                                            values.push(item[child]);
                                        }
                                    }
                                } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                    values.push(nestedValue[child]);
                                }
                            }
                        } else {
                            if (jsonData.hasOwnProperty(fullPath)) {
                                values.push(jsonData[fullPath]);
                            }
                        }
                    } else {
                        alert('jsonData is not an array or an object.');
                    }

                    const fullPathOpenValue = findFullPath(globalData, selectedOpenValue); // Using the same logic as fullPath
    
                        let openValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathOpenValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    openValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            openValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathOpenValue)) {
                                        openValues.push(obj[fullPathOpenValue]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathOpenValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                openValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        openValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathOpenValue)) {
                                    openValues.push(globalData[fullPathOpenValue]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }

                    // High Value 
                    const fullPathHighValue = findFullPath(globalData, selectedHighValue); // Using the same logic as fullPath
                        let highValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathHighValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    highValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            highValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathHighValue)) {
                                        highValues.push(obj[fullPathHighValue]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathHighValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                highValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        highValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathHighValue)) {
                                    highValues.push(globalData[fullPathHighValue]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }

                    // Low Value
                    const fullPathLowValue = findFullPath(globalData, selectedLowValue); // Using the same logic as fullPath
                        let lowValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathLowValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    lowValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            lowValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathLowValue)) {
                                        lowValues.push(obj[fullPathLowValue]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathLowValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                lowValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        lowValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathLowValue)) {
                                    lowValues.push(globalData[fullPathLowValue]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }

                    //Close Value
                    const fullPathCloseValue = findFullPath(globalData, selectedCloseValue); // Using the same logic as fullPath
                        let closeValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathCloseValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    closeValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            closeValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathCloseValue)) {
                                        closeValues.push(obj[fullPathCloseValue]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathCloseValue.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                closeValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        closeValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathCloseValue)) {
                                    closeValues.push(globalData[fullPathCloseValue]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }
                        let TransformedDate = values.map(item => {
                            // Check if the current item is an array
                            if (Array.isArray(item)) {
                                // Handle sub-array case
                                return item.map(subItem => {
                                    let dateTransforming = new Date(subItem).getTime();
                                    return isNaN(dateTransforming) ? 0 : dateTransforming;
                                });
                            } else {
                                // Handle individual item case
                                let dateTransforming = new Date(item).getTime();
                                return isNaN(dateTransforming) ? 0 : dateTransforming;
                            }
                        }).flat(); // Flatten the resulting array
                                                
                        let getMaxLength= Math.max(
                        TransformedDate.flat().length,
                        openValues.flat().length,
                        highValues.flat().length,
                        lowValues.flat().length,
                        closeValues.flat().length
                    
                    );
                    let FlatTransformedDate = TransformedDate.flat();
                    let FlatopenValues = openValues.flat();
                    let FlathighValues = highValues.flat();
                    let FlatlowValues = lowValues.flat();
                    let FlatcloseValues = closeValues.flat();
                    let stockTransformedData = [];
                    
                    for(let i = 0; i < getMaxLength; i++) {
                        stockTransformedData.push([
                        (i < FlatTransformedDate.length) ? FlatTransformedDate[i] : 0 ,
                        (i < FlatopenValues.length) ? FlatopenValues[i] : 0 ,
                        (i < FlathighValues.length) ? FlathighValues[i] : 0 ,
                        (i < FlatlowValues.length) ? FlatlowValues[i] : 0 ,
                        (i < FlatcloseValues.length) ? FlatcloseValues[i] : 0 
                        ]);
                    }
                    console.log(stockTransformedData);
                    setJsonData(stockTransformedData);
                        const requestData = {
                            chartType: chartType,
                            userData: stockTransformedData, // Use the new data instead of jsonData
                            title: title,
                            titleAlignment: titleAlignment,
                            subTitle: subTitle,
                            subTitleAlignment: subTitleAlignment,
                            yAxistext: yAxistext,
                            xAxistext: xAxistext
                        };
        
                        // Send the new data to the server
                        const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                        setProgram(response.data.generatedCode);
                        setPYProgram(response.data.generatedCodePy);
                        const script = document.createElement('script');
                        script.type = 'text/javascript';
                        script.innerHTML = response.data.generatedCode;
                        document.getElementById('container').appendChild(script);
                        hljs.highlightAll();
                      

                }else {
                    alert('Please select a key first.');
                }
            }
            else {
                let selectedKey = selectYValue.current.value;
                let selectName = selectXName.current.value;
                // Search for the selected values in the JSON data array and extract corresponding data
                const fullPath = findFullPath(globalData, selectedKey);
                if (fullPath) {
                    let values = [];
                    if (Array.isArray(jsonData)) {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(parent)) {
                                    const nestedValue = obj[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                values.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        values.push(nestedValue[child]);
                                    }
                                }
                            }
                        } else {
                            for (const obj of jsonData) {
                                if (obj.hasOwnProperty(fullPath)) {
                                    values.push(obj[fullPath]);
                                }
                            }
                        }
                    } else if (typeof jsonData === 'object') {
                        const pathParts = fullPath.split('.');
                        if (pathParts.length > 1) {
                            const [parent, child] = pathParts;
                            if (jsonData.hasOwnProperty(parent)) {
                                const nestedValue = jsonData[parent];
                                if (Array.isArray(nestedValue)) {
                                    for (const item of nestedValue) {
                                        if (item.hasOwnProperty(child)) {
                                            values.push(item[child]);
                                        }
                                    }
                                } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                    values.push(nestedValue[child]);
                                }
                            }
                        } else {
                            if (jsonData.hasOwnProperty(fullPath)) {
                                values.push(jsonData[fullPath]);
                            }
                        }
                    } else {
                        alert('jsonData is not an array or an object.');
                    }

                    const fullPathName = findFullPath(globalData, selectName); // Using the same logic as fullPath
                    if (fullPathName) {
                        let nameValues = [];
                        if (Array.isArray(globalData)) {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(parent)) {
                                        const nestedValue = obj[parent];
                                        if (Array.isArray(nestedValue)) {
                                            for (const item of nestedValue) {
                                                if (item.hasOwnProperty(child)) {
                                                    nameValues.push(item[child]);
                                                }
                                            }
                                        } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                            nameValues.push(nestedValue[child]);
                                        }
                                    }
                                }
                            } else {
                                for (const obj of globalData) {
                                    if (obj.hasOwnProperty(fullPathName)) {
                                        nameValues.push(obj[fullPathName]);
                                    }
                                }
                            }
                        } else if (typeof globalData === 'object') {
                            const pathParts = fullPathName.split('.');
                            if (pathParts.length > 1) {
                                const [parent, child] = pathParts;
                                if (globalData.hasOwnProperty(parent)) {
                                    const nestedValue = globalData[parent];
                                    if (Array.isArray(nestedValue)) {
                                        for (const item of nestedValue) {
                                            if (item.hasOwnProperty(child)) {
                                                nameValues.push(item[child]);
                                            }
                                        }
                                    } else if (typeof nestedValue === 'object' && nestedValue.hasOwnProperty(child)) {
                                        nameValues.push(nestedValue[child]);
                                    }
                                }
                            } else {
                                if (globalData.hasOwnProperty(fullPathName)) {
                                    nameValues.push(globalData[fullPathName]);
                                }
                            }
                        } else {
                            alert('globalData is not an array or an object.');
                        }
                        console.log('Name Values:', nameValues);

                        var extractedData = values.map((item, index) => ({
                            y: item,
                            name: nameValues[index]
                        }));
                        console.log(newData);
                    } else {
                        alert('Please select a name key first.');
                    }
                } else {
                    alert('Please select a key first.');
                }

                // If 'y' is an array, create multiple objects for each value
                const transformedData = extractedData.flatMap(item => {
                    if (Array.isArray(item.y)) {
                        return item.y.map(y => ({ y, name: item.name }));
                    } else {
                        return [item]; // If 'y' is not an array, return the item as a single-element array
                    }
                });
                setJsonData(transformedData);
                setTestData(transformedData);
                const requestData = {
                    chartType: chartType,
                    userData: transformedData, // Use the new data instead of jsonData
                    title: title,
                    titleAlignment: titleAlignment,
                    subTitle: subTitle,
                    subTitleAlignment: subTitleAlignment,
                    yAxistext: yAxistext,
                    xAxistext: xAxistext
                };

                // Send the new data to the server
                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();
            }
            scrollToChart.current.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error(error);
        }

    };
    const nextChart = () => {
        if (currentIndex < lengthOfChart) {
            setCurrentIndex(currentIndex + 1);
        } else {
            alert("No more charts");
        }

    };
    const prevChart = () => {
        if (currentIndex != 0) {
            setCurrentIndex(currentIndex - 1);
        } else {
            alert("End");
        }

    };
    useEffect(() => {
        const fetchData = async () => {
            try {
                setChartType(filteredChart[currentIndex].title);
                const requestData = {
                    chartType: filteredChart[currentIndex].title,
                    userData: jsonData,
                    title: title,
                    titleAlignment: titleAlignment,
                    subTitle: subTitle,
                    subTitleAlignment: subTitleAlignment,
                    yAxistext: yAxistext,
                    xAxistext: xAxistext
                };
                const response = await axios.post('http://localhost:3001/generate-chart', requestData);
                setProgram(response.data.generatedCode);
                setPYProgram(response.data.generatedCodePy);
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = response.data.generatedCode;
                document.getElementById('container').appendChild(script);
                hljs.highlightAll();
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, [currentIndex])

    return (
        <>
            <h1 className="text-center">{chartType}</h1>
            <div className="controlBtnsBox" ref={scrollToBox}>
                    <div className="controlBtn controlBtnNext" onClick={prevChart}><i class="fa fa-solid fa-arrow-left"></i> Prev Chart</div>
                    <div className="controlBtn controlBtnNext" onClick={nextChart}>Next Chart <i class="fa fa-solid fa-arrow-right "></i></div>
                </div>
            <div className="boxis1" >
                <p>Select Programming Language</p>
                <select className="selectLanguage" name="" id="languageSelection"
                    value={languageSelection}
                    onChange={handleLanguageSelectionChange} >
                    <option value="JS" selected>Javascript</option>
                    <option value="PY">Python</option>
                </select>
            </div>
            <div className="flex-boxes" ref={scrollToChart} >
                <div className="uploaddatabtn btn btn-primary py-sm-3 px-sm-5 rounded-pill mt-0">
                    <form ref={jsonForm}>
                        <input
                            type="file"
                            ref={jsonFile}
                            placeholder="Upload a JSON file"
                            onChange={getFile}
                        />

                    </form>
                </div>


                <div className="uploaddatabtn btn btn-primary py-sm-3 px-sm-5 rounded-pill mt-0`" onClick={submitData}>
                    <input className="generateBtn" type="button" value="Submit Data" />
                </div>
            </div>
            <span ref={fileStatus} style={{display: 'none'}}></span>
            <div className="selectKeyWraper" style={{ display: selectionofKey ? 'block' : 'none' }}>
                {isStockChart ? <div className="selectKey"   >
                    <div>
                        <label htmlFor="keyBox">Select Date</label>
                        <select className="keyBox mx-2" name="keyBox"
                            value={dateKey}
                            onChange={(e) => setDateKey(e.target.value)}
                            ref={selectDateValue}
                        >

                            <option value="">Select Date</option>

                        </select>
                    </div>
                    <div>
                        <label htmlFor="nameBox">Select Open Value</label>
                        <select className="nameBox mx-2" name="nameBox" id="nameBox"
                            value={openValue}
                            onChange={(e) => setOpenValue(e.target.value)}
                            ref={selectOpenValue}
                        >
                            <option value="">Select Open Value</option>
                        </select>

                    </div>
                    <div>
                        <label htmlFor="nameBox">Select High Value</label>
                        <select className="nameBox mx-2" name="nameBox" id="nameBox"
                            value={highValue}
                            onChange={(e) => setHighValue(e.target.value)}
                            ref={selectHighValue}
                        >
                            <option value="">Select High Value</option>
                        </select>

                    </div>
                    <div>
                        <label htmlFor="nameBox">Select Low Value</label>
                        <select className="nameBox mx-2" name="nameBox" id="nameBox"
                            value={lowValue}
                            onChange={(e) => setLowValue(e.target.value)}
                            ref={selectLowValue}
                        >
                            <option value="">Select Low Value</option>
                        </select>

                    </div>
                    <div>
                        <label htmlFor="nameBox">Select Close Value</label>
                        <select className="nameBox mx-2" name="nameBox" id="nameBox"
                            value={closeValue}
                            onChange={(e) => setCloseValue(e.target.value)}
                            ref={selectCloseValue}
                        >
                            <option value="">Select Close Value</option>
                        </select>

                    </div>
                    <div>
                        <a className="SaveBtnKey" onClick={generateChart}>Generate Chart</a>
                        {/* Validation Remains */}

                    </div>


                </div>
                    :
                    <div className="selectKey"   >
                        <div>
                            <label htmlFor="keyBox">Select data for Y-axis</label>
                            <select className="keyBox mx-2" name="keyBox"
                                value={dataKeySelect}
                                onChange={(e) => setDataKeySelect(e.target.value)}
                                ref={selectYValue}
                            >

                                <option value="">Select a key</option>

                            </select>
                        </div>
                        <div>
                            <label htmlFor="nameBox">Select Name for X-axis</label>
                            <select className="nameBox mx-2" name="nameBox" id="nameBox"
                                value={dataNameSelect}
                                onChange={(e) => setDataNameSelect(e.target.value)}
                                ref={selectXName}
                            >
                                <option value="">Select a key</option>
                            </select>

                        </div>
                        <div>
                            <a className="SaveBtnKey" onClick={generateChart}>Generate Chart</a>
                            {/* Validation Remains */}

                        </div>


                    </div>
                }


            </div>
            <div className="container customization" >
        
                <div className="customize">
                    <div className="customize-btn" onClick={handleClicks}>
                        <img src="img/creativity.png" alt="" /> Customization</div>
                    {clicked ? <div className="customize-menu">
                        <div className="node-icon"> </div>
                        <div className="wrape-custom-items">
                            <div>
                                <label htmlFor="title">Title</label>
                            </div>
                            <div>
                                <input id="title" type="text" value={title} onChange={handleInputChange(setTitle)} />
                            </div>
                            <div>
                                <label htmlFor="alignTitle">Align Title</label>
                            </div>
                            <div>
                                <select name="alignTitle" id="alignTitle" value={titleAlignment}
                                    onChange={handleInputChange(setTitleAlignment)}  >

                                    <option value="left" >left</option>
                                    <option value="center" >center</option>
                                    <option value="right" >right</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="subTitle">Subtitle</label>
                            </div>
                            <div>
                                <input id="subTitle" type="text" value={subTitle} onChange={handleInputChange(setsubTitle)} />
                            </div>
                            <div>
                                <label htmlFor="alignSubTitle">Align Subtitle</label>
                            </div>
                            <div>
                                <select name="alignSubTitle" id="alignSubTitle" value={subTitleAlignment}
                                    onChange={handleInputChange(setSubTitleAlignment)} >
                                    <option value="left" selected>left</option>
                                    <option value="center" >center</option>
                                    <option value="right" >right</option>
                                </select>
                            </div>

                            <div>
                                <label htmlFor="textOnXaxis">Text On X-Axis</label>
                            </div>
                            <div>
                                <input id="textOnXaxis" type="text" value={yAxistext}
                                    onChange={handleInputChange(setYAxistext)} />
                            </div>
                            <div>
                                <label htmlFor="textOnYaxis">Text On Y-Axis</label>
                            </div>
                            <div>
                                <input id="textOnYaxis" type="text" value={xAxistext}
                                    onChange={handleInputChange(setXAxistext)} />
                            </div>

                            {renderLabels()}
                            {/* <div>
                                <label htmlFor="chartbg">Chart Background</label>
                            </div>
                            <div>
                                <input id="chartbg" type="color" />
                            </div> */}
                            <div className="saveChages" onClick={updateChart}>
                                Save Changes
                            </div>



                        </div>


                    </div> : ''}

                </div>
            </div>
            <div className="chartWrapper">
                <div id="container"></div>

            </div>
            <div className="codeSnipeetWraper">
                <div className="JScodeBox" style={{ display: showCodeSnippetsJS ? 'block' : 'none' }} >
                    <div className="codeWraper" >

                        <div className="htmlWraper">
                            <div className="code-header">
                                <h3>
                                    <img src="img/html.png" alt="" />
                                    HTML
                                </h3>
                                <span className="copy-btn" onClick={handleCopyHtml}>
                                    {copiedHtml ? "Copied!" : <img src="img/copied.png" alt="" />}
                                </span>
                            </div>


                            <pre>
                                <code className="language-html" dangerouslySetInnerHTML={{ __html: htmlCode }} />
                            </pre>

                        </div>
                        <div className="jsWraper">
                            <div className="code-header">
                                <h3>
                                    <img src="img/js-file.png" alt="" />
                                    JS
                                </h3>
                                <span className="copy-btn" id="copyJs" onClick={handleCopyJs}>
                                    {copiedJs ? "Copied!" : <img src="img/copied.png" alt="" />}
                                </span>
                            </div>
                            {program && (
                                <pre>
                                    <code className="language-javascript" dangerouslySetInnerHTML={{ __html: hljs.highlight('javascript', program).value }} />
                                </pre>
                            )}


                        </div>
                    </div>
                </div>
                <div className="pythonCodeBox" style={{ display: showCodeSnippetsPY ? 'block' : 'none' }} >

                    <div className="PYWraper-2">
                        <div className="code-header">
                            <h3>
                                <img src="img/pyLogo.png" alt="" />
                                Install Package
                            </h3>
                            <span className="copy-btn" onClick={handleCopyPip}>
                                {copiedPip ? "Copied!" : <img src="img/copied.png" alt="" />}
                            </span>
                        </div>
                        <pre>
                            <code className="language-python"  >
                                pip install highcharts-core
                            </code>
                        </pre>


                    </div>
                    <div className="codeWraper" >

                        <div className="PYWraper">
                            <div className="code-header">
                                <h3>
                                    <img src="img/pyLogo.png" alt="" />
                                    Python
                                </h3>
                                <span className="copy-btn" onClick={handleCopyPy}>
                                    {copiedPy ? "Copied!" : <img src="img/copied.png" alt="" />}
                                </span>
                            </div>
                            {PYProgram && (
                                <pre>
                                    <code className="language-python" dangerouslySetInnerHTML={{ __html: hljs.highlight('python', PYProgram).value }} />
                                </pre>
                            )}

                        </div>

                    </div>

                </div>
            </div>
        </>
    );
}

export default RenderChart;
