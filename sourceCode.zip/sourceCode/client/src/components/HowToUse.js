import React from "react";

function HowToUse(){
    return(
        <>
        <div class="container-xxl py-0">
                <div class="container py-5 px-lg-5">
                    <div class="row g-5 align-items-center">
                        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                            <p class="section-title text-secondary">How To Use<span></span></p>
                            <h1 class="mb-5">How To Convert Your JSON To Chart</h1>
                            <p class="mb-4 htu-small-desc" >Follow these steps to effortlessly integrate visual representations of your data:</p>
                           <ul>
                            <li>
                                Choose a chart.
                            </li>
                            <li>
                                Upload JSON data.

                            </li>   
                            <li>
                                Customize to Your Specifications.
                            </li>
                            <li>
                                Retrieve Source Code or Image.
                            </li>
                            <li>
                                Easily Integrate it in your project.
                            </li>
                           </ul>
                          
                            <a href="/#" class="btn btn-primary py-sm-3 px-sm-5 rounded-pill mt-3">Read More</a>
                        </div>
                        <div class="col-lg-6 aboutImg">
                            <img class="img-fluid wow zoomIn" data-wow-delay="0.5s" src="img/about.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>

        </>
    );
}
export default HowToUse