const ALLCharts = [
    {
        id: 1,
        title: "Line Charts",
        image: "img/charts/lineChart.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Installation & Developers',
            data: [72, 15, 22, 14, 4, 10.2]
        }, {
            name: 'Manufacturing',
            data: [24916, 37941, 29742, 29851, 32490, 30282,
                38121, 36885, 33726, 34243, 31050]
        }, {
            name: 'Sales & Distribution',
            data: [11744, 30000, 16005, 19771, 20185, 24377, 32147, 30912, 29243, 29213, 25663]
        }, {
            name: 'Operations & Maintenance',
            data: [null, null, null, null, null, null, null,
                null, 11164, 11218, 10077]
        }, {
            name: 'Other',
            data: [21908, 5548, 8105, 11248, 8989, 11816, 18274,
                17300, 13053, 11906, 10073]
        }],
        chartAttribute: {
            title: {
                text: 'U.S Solar Employment Test',
                align: 'left'
            },
            subtitle: {
                text: 'By Job Category',
                align: 'left'
            },
            yAxistext: 'Number of Employees',
            xAxistext: 'Numbers',

        }
    },
    {
        id: 2,
        title: "Spline with symbols",
        image: "img/charts/Spline.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Tokyo',
            marker: {
                symbol: 'square'
            },
            data: [5.2, 5.7, 8.7, 13.9, 18.2, 21.4, 25.0, {
                y: 26.4,
                marker: {
                    symbol: 'url(https://www.highcharts.com/samples/graphics/sun.png)'
                },
                accessibility: {
                    description: 'Sunny symbol, this is the warmest point in the chart.'
                }
            }, 22.8, 17.5, 12.1, 7.6]

        }, {
            name: 'Bergen',
            marker: {
                symbol: 'diamond'
            },
            data: [{
                y: 1.5,
                marker: {
                    symbol: 'url(https://www.highcharts.com/samples/graphics/snow.png)'
                },
                accessibility: {
                    description: 'Snowy symbol, this is the coldest point in the chart.'
                }
            }, 1.6, 3.3, 5.9, 10.5, 13.5, 14.5, 14.4, 11.5, 8.7, 4.7, 2.6]
        }],
        chartAttribute: {
            title: {
                text: 'Monthly Average Temperature',
                align: 'left'
            },
            subtitle: {
                text: 'Source Wekipedia',
                align: 'left'
            },
            yAxistext: 'By Temperature',
            xAxistext: '',

        }


    },
    {
        id: 3,
        title: "Inverted axes",
        image: "img/charts/invertedaxes.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Temperature',
            _data: [[0, 15], [10, -50], [20, -56.5], [30, -46.5], [40, -22.1],
            [50, -2.5], [60, -27.7], [70, -55.7], [80, -76.5]],
            data: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 4,
        title: "With data labels",
        image: "img/charts/Withdatalabels.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Reggane',
            data: [16.0, 18.2, 23.1, 27.9, 32.2, 36.4, 39.8, 38.4, 35.5, 29.2,
                22.0, 17.8]
        }, {
            name: 'Tallinn',
            data: [-2.9, -3.6, -0.6, 4.8, 10.2, 14.5, 17.6, 16.5, 12.0, 6.5,
                2.0, -0.9]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }

    },
    {
        id: 5,
        title: "Logarithmic axis",
        image: "img/charts/logarithmic-axis-demo.png",
        category: "Line Charts",
        exampleData: [{
            data: [1, 2, 4, 8, 16, 32, 64, 128, 256, 512],
            pointStart: 1
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 8,
        title: "irregular intervals",
        image: "img/charts/irregular.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Hestavollane',
            data: [5.4, 5.2, 5.7, 6.3, 5.2, 5.6, 6.1,
                5.6, 5.9, 7.1, 8.6, 7.8, 8.6,
                8.0, 9.7, 11.2, 12.5, 13.1, 10.6,
                10.9, 8.9, 9.5, 7.5, 3.5, 4.2]

        }, {
            name: 'Vik',
            data: [0.2, 0.1, 0.1, 0.5, 0.3, 0.2, 0.1,
                0.1, 0.1, 0.1, 0.2, 1.1, 1.3,
                2.0, 1.5, 1.5, 1.5, 1.4, 1.7,
                2.0, 2.9, 2.1, 2.1, 3.5, 2.9]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 9,
        title: "Plot bands",
        image: "img/charts/plotbands.png",
        category: "Line Charts",
        exampleData: [{
            name: 'Hestavollane',
            data: [5.4, 5.2, 5.7, 6.3, 5.2, 5.6, 6.1,
                5.6, 5.9, 7.1, 8.6, 7.8, 8.6,
                8.0, 9.7, 11.2, 12.5, 13.1, 10.6,
                10.9, 8.9, 9.5, 7.5, 3.5, 4.2]

        }, {
            name: 'Vik',
            data: [0.2, 0.1, 0.1, 0.5, 0.3, 0.2, 0.1,
                0.1, 0.1, 0.1, 0.2, 1.1, 1.3,
                2.0, 1.5, 1.5, 1.5, 1.4, 1.7,
                2.0, 2.9, 2.1, 2.1, 3.5, 2.9]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 10,
        title: "Basic area",
        image: "img/charts/basicArea.png",
        category: "Area Charts",
        exampleData: [{
            name: 'USA',
            data: [
                null, null, null, null, null, 2, 9, 13, 50, 170, 299, 438, 841,
                1169, 1703, 2422, 3692, 5543, 7345, 12298, 18638, 22229, 25540,
                28133, 29463, 31139, 31175, 31255, 29561, 27552, 26008, 25830,
                26516, 27835, 28537, 27519, 25914, 25542, 24418, 24138, 24104,
                23208, 22886, 23305, 23459, 23368, 23317, 23575, 23205, 22217,
                21392, 19008, 13708, 11511, 10979, 10904, 11011, 10903, 10732,
                10685, 10577, 10526, 10457, 10027, 8570, 8360, 7853, 5709, 5273,
                5113, 5066, 4897, 4881, 4804, 4717, 4571, 4018, 3822, 3785, 3805,
                3750, 3708, 3708
            ]
        }, {
            name: 'USSR/Russia',
            data: [null, null, null, null, null, null, null, null, null,
                1, 5, 25, 50, 120, 150, 200, 426, 660, 863, 1048, 1627, 2492,
                3346, 4259, 5242, 6144, 7091, 8400, 9490, 10671, 11736, 13279,
                14600, 15878, 17286, 19235, 22165, 24281, 26169, 28258, 30665,
                32146, 33486, 35130, 36825, 38582, 40159, 38107, 36538, 35078,
                32980, 29154, 26734, 24403, 21339, 18179, 15942, 15442, 14368,
                13188, 12188, 11152, 10114, 9076, 8038, 7000, 6643, 6286, 5929,
                5527, 5215, 4858, 4750, 4650, 4600, 4500, 4490, 4300, 4350, 4330,
                4310, 4495, 4477
            ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }


    },
    {
        id: 11,
        title: "Stacked area",
        image: "img/charts/stackedArea.png",
        category: "Area Charts",
        exampleData: [{
            name: 'Ocean transport',
            data: [13234, 12729, 11533, 17798, 10398, 12811, 15483, 16196, 16214]
        }, {
            name: 'Households',
            data: [6685, 6535, 6389, 6384, 6251, 5725, 5631, 5047, 5039]

        }, {
            name: 'Agriculture and hunting',
            data: [4752, 4820, 4877, 4925, 5006, 4976, 4946, 4911, 4913]
        }, {
            name: 'Air transport',
            data: [3164, 3541, 3898, 4115, 3388, 3569, 3887, 4593, 1550]

        }, {
            name: 'Construction',
            data: [2019, 2189, 2150, 2217, 2175, 2257, 2344, 2176, 2186]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 12,
        title: "Percentage area",
        image: "img/charts/countriesregions-with-hi.png",
        category: "Area Charts",
        exampleData: [{
            name: 'China',
            data: [2.5, 2.6, 2.7, 2.9, 3.1, 3.4, 3.5, 3.5, 3.4, 3.4, 3.4,
                3.5, 3.9, 4.5, 5.2, 5.9, 6.5, 7, 7.5, 7.9, 8.6, 9.5, 9.8,
                10, 10, 9.8, 9.7, 9.9, 10.3, 10.5, 10.7, 10.9
            ]
        }, {
            name: 'USA',
            data: [5.1, 5.1, 5.2, 5.3, 5.4, 5.4, 5.6, 5.7, 5.7, 5.8, 6, 5.9,
                5.9, 6, 6.1, 6.1, 6.1, 6.1, 5.9, 5.5, 5.7, 5.5, 5.3, 5.5,
                5.5, 5.4, 5.2, 5.2, 5.4, 5.3, 4.7, 5
            ]
        }, {
            name: 'EU',
            data: [3.9, 3.8, 3.7, 3.6, 3.6, 3.6, 3.7, 3.7, 3.6, 3.6, 3.6, 3.7,
                3.7, 3.7, 3.8, 3.7, 3.7, 3.7, 3.6, 3.3, 3.4, 3.3, 3.3, 3.2, 3,
                3.1, 3.1, 3.1, 3, 2.9, 2.6, 2.7]
        }, {
            name: 'India',
            data: [0.6, 0.6, 0.7, 0.7, 0.7, 0.8, 0.8, 0.9, 0.9, 1, 1, 1,
                1, 1.1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 2, 2,
                2.2, 2.3, 2.4, 2.4, 2.6, 2.6, 2.4, 2.7]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },

    {
        id: 14,
        title: "Area-spline",
        image: "img/charts/moose-and-deer-hunting-i.png",
        category: "Area Charts",
        exampleData: [{
            name: 'Moose',
            data:
                [
                    38000,
                    37300,
                    37892,
                    38564,
                    36770,
                    36026,
                    34978,
                    35657,
                    35620,
                    35971,
                    36409,
                    36435,
                    34643,
                    34956,
                    33199,
                    31136,
                    30835,
                    31611,
                    30666,
                    30319,
                    31766
                ]
        }, {
            name: 'Deer',
            data:
                [
                    22534,
                    23599,
                    24533,
                    25195,
                    25896,
                    27635,
                    29173,
                    32646,
                    35686,
                    37709,
                    39143,
                    36829,
                    35031,
                    36202,
                    35140,
                    33718,
                    37773,
                    42556,
                    43820,
                    46445,
                    50048
                ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },

    {
        id: 16,
        title: "Missing points",
        image: "img/charts/born-persons-by-boys-nam.png",
        category: "Area Charts",
        exampleData: [{
            name: 'Arvid',
            data: [10, 9, 11, 11, 8, 13, 12, 14]
        }, {
            name: 'Yasin',
            data: [13, 9, 10, 10, 8, null, 8, 6]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 17,
        title: "With negative values Area Chart",
        image: "img/charts/production-consumption-a.png",
        category: "Area Charts",
        exampleData: [{
            name: 'Total production',
            data: [37.8, 29.3, 30.8, 36.8, 40.5, 35.3, 34.9, 43.6, 45.7, 35.9, 32.7
            ]
        }, {
            name: 'Gross consumption',
            data: [39.9, 29.9, 26.7, 38.1, 39.3, 30.2, 27.5, 36.7, 42.7, 31.4, 27.5
            ]
        }, {
            name: 'Trade surplus',
            data: [-2.2, -0.6, 4.1, -1.3, 1.2, 5.1, 7.4, 6.9, 2.9, 4.5, 5.2]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }

    }
    ,
    {
        id: 18,
        title: "Basic bar",
        image: "img/charts/historic-world-populatio.png",
        category: "Bar Charts",
        exampleData: [{
            name: 'Year 1990',
            data: [631, 727, 3202, 721]
        }, {
            name: 'Year 2000',
            data: [814, 841, 3714, 726]
        }, {
            name: 'Year 2018',
            data: [1276, 1007, 4561, 746]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 19,
        title: "Basic column",
        image: "img/charts/corn-vs-wheat-estimated.png",
        category: "Bar Charts",
        exampleData: [
            {
                name: 'Corn',
                data: [406292, 260000, 107000, 68300, 27500, 14500]
            },
            {
                name: 'Wheat',
                data: [51086, 136000, 5500, 141000, 107180, 77000]
            }
        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 20,
        title: "Stacked and grouped",
        image: "img/charts/olympic-games-all-time-m.png",
        category: "Bar Charts",
        exampleData: [{
            name: 'Norway',
            data: [148, 133, 124],
            stack: 'Europe'
        }, {
            name: 'Germany',
            data: [102, 98, 65],
            stack: 'Europe'
        }, {
            name: 'United States',
            data: [113, 122, 95],
            stack: 'North America'
        }, {
            name: 'Canada',
            data: [77, 72, 80],
            stack: 'North America'
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 21,
        title: "Column range",
        image: "img/charts/columnChart.png",
        category: "Bar Charts",
        exampleData: [{
            name: 'Norway',
            data: [148, 133, 124],
            stack: 'Europe'
        }, {
            name: 'Germany',
            data: [102, 98, 65],
            stack: 'Europe'
        }, {
            name: 'United States',
            data: [113, 122, 95],
            stack: 'North America'
        }, {
            name: 'Canada',
            data: [77, 72, 80],
            stack: 'North America'
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 22,
        title: "Variwide",
        image: "img/charts/labor-costs-in-europe-20.png",
        category: "Bar Charts",
        exampleData: [
            ['Norway', 50.2, 335504],
            ['Denmark', 42, 277339],
            ['Belgium', 39.2, 421611],
            ['Sweden', 38, 462057],
            ['France', 35.6, 2228857],
            ['Netherlands', 34.3, 702641],
            ['Finland', 33.2, 215615],
            ['Germany', 33.0, 3144050],
            ['Austria', 32.7, 349344],
            ['Ireland', 30.4, 275567],
            ['Italy', 27.8, 1672438],
            ['United Kingdom', 26.7, 2366911],
            ['Spain', 21.3, 1113851],
            ['Greece', 14.2, 175887],
            ['Portugal', 13.7, 184933],
            ['Czech Republic', 10.2, 176564],
            ['Poland', 8.6, 424269],
            ['Romania', 5.5, 169578]

        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 23,
        title: "With negative values Bar Chart",
        image: "img/charts/column-chart-with-negati.png",
        category: "Bar Charts",
        exampleData: [{
            name: 'John',
            data: [5, 3, 4, 7, 2]
        }, {
            name: 'Jane',
            data: [2, -2, -3, 2, 1]
        }, {
            name: 'Joe',
            data: [3, 4, 4, -2, 5]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },

    {
        id: 26,
        title: "Stacked column",
        image: "img/charts/major-trophies-for-some.png",
        category: "Bar Charts",
        exampleData: [{
            name: 'BPL',
            data: [3, 5, 1, 13]
        }, {
            name: 'FA Cup',
            data: [14, 8, 8, 12]
        }, {
            name: 'CL',
            data: [0, 2, 6, 3]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,

    {
        id: 28,
        title: "Pie chart",
        image: "img/charts/egg-yolk-composition.png",
        category: "Pie Charts",
        exampleData: [
            {
                name: 'Water',
                y: 55.02
            },
            {
                name: 'Fat',
                y: 26.71
            },
            {
                name: 'Carbohydrates',
                y: 1.09
            },
            {
                name: 'Protein',
                y: 15.5
            },
            {
                name: 'Ash',
                y: 1.68
            }
        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 30,
        title: "custom entrance animation",
        image: "img/charts/departamental-strength-o.png",
        category: "Pie Charts",
        exampleData: [{
            name: 'Customer Support',
            y: 21.3
        }, {
            name: 'Development',
            y: 18.7
        }, {
            name: 'Sales',
            y: 20.2
        }, {
            name: 'Marketing',
            y: 14.2
        }, {
            name: 'Other',
            y: 25.6
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 31,
        title: "With monochrome fill",
        image: "img/charts/browser-market-shares-in.png",
        category: "Pie Charts",
        exampleData: [{
            name: 'Customer Support',
            y: 21.3
        }, {
            name: 'Development',
            y: 18.7
        }, {
            name: 'Sales',
            y: 20.2
        }, {
            name: 'Marketing',
            y: 14.2
        }, {
            name: 'Other',
            y: 25.6
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    }
    ,
    {
        id: 33,
        title: "Semi circle donut",
        image: "img/charts/browsersharesjanuary2022.png",
        category: "Pie Charts",
        exampleData: [
            ['Chrome', 73.86],
            ['Edge', 11.97],
            ['Firefox', 5.52],
            ['Safari', 2.98],
            ['Internet Explorer', 1.90],
            ['Other', 3.77]
        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 34,
        title: "Bubble chart",
        image: "img/charts/sugar-and-fat-intake-per.png",
        category: "Scatter Charts",
        exampleData: [{
            name: 'Installation & Developers',
            data: [43934, 48656, 65165, 81827, 112143, 142383,
                171533, 165174, 155157, 161454, 154610]
        }, {
            name: 'Manufacturing',
            data: [24916, 37941, 29742, 29851, 32490, 30282,
                38121, 36885, 33726, 34243, 31050]
        }, {
            name: 'Sales & Distribution',
            data: [11744, 30000, 16005, 19771, 20185, 24377,
                32147, 30912, 29243, 29213, 25663]
        }, {
            name: 'Operations & Maintenance',
            data: [null, null, null, null, null, null, null,
                null, 11164, 11218, 10077]
        }, {
            name: 'Other',
            data: [21908, 5548, 8105, 11248, 8989, 11816, 18274,
                17300, 13053, 11906, 10073]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }

    },
    {
        id: 35,
        title: "Scatter plot",
        image: "img/charts/olympics-athletes-by-hei.png",
        category: "Scatter Charts",
        exampleData: [{
            name: 'Installation & Developers',
            data: [43934, 48656, 65165, 81827, 112143, 142383,
                171533, 165174, 155157, 161454, 154610]
        }, {
            name: 'Manufacturing',
            data: [24916, 37941, 29742, 29851, 32490, 30282,
                38121, 36885, 33726, 34243, 31050]
        }, {
            name: 'Sales & Distribution',
            data: [11744, 30000, 16005, 19771, 20185, 24377,
                32147, 30912, 29243, 29213, 25663]
        }, {
            name: 'Operations & Maintenance',
            data: [null, null, null, null, null, null, null,
                null, 11164, 11218, 10077]
        }, {
            name: 'Other',
            data: [21908, 5548, 8105, 11248, 8989, 11816, 18274,
                17300, 13053, 11906, 10073]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 35,
        title: "plot with jitter",
        image: "img/charts/scatter-chart-with-jitte.png",
        category: "Scatter Charts",
        exampleData: [{
            name: 'Installation & Developers',
            data: [43934, 48656, 65165, 81827, 112143, 142383,
                171533, 165174, 155157, 161454, 154610]
        }, {
            name: 'Manufacturing',
            data: [24916, 37941, 29742, 29851, 32490, 30282,
                38121, 36885, 33726, 34243, 31050]
        }, {
            name: 'Sales & Distribution',
            data: [11744, 30000, 16005, 19771, 20185, 24377,
                32147, 30912, 29243, 29213, 25663]
        }, {
            name: 'Operations & Maintenance',
            data: [null, null, null, null, null, null, null,
                null, 11164, 11218, 10077]
        }, {
            name: 'Other',
            data: [21908, 5548, 8105, 11248, 8989, 11816, 18274,
                17300, 13053, 11906, 10073]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 36,
        title: "Packed bubble chart",
        image: "img/charts/carbon-emissions-around.png",
        category: "Scatter Charts",
        exampleData: [{
            name: 'Europe',
            data: [{
                name: 'Germany',
                value: 767.1
            }, {
                name: 'Croatia',
                value: 20.7
            },
            {
                name: 'Belgium',
                value: 97.2
            },
            {
                name: 'Czech Republic',
                value: 111.7
            },
            {
                name: 'Netherlands',
                value: 158.1
            },
            {
                name: 'Spain',
                value: 241.6
            },
            {
                name: 'Ukraine',
                value: 249.1
            },
            {
                name: 'Poland',
                value: 298.1
            },
            {
                name: 'France',
                value: 323.7
            },
            {
                name: 'Romania',
                value: 78.3
            },
            {
                name: 'United Kingdom',
                value: 415.4
            }, {
                name: 'Turkey',
                value: 353.2
            }, {
                name: 'Italy',
                value: 337.6
            },
            {
                name: 'Greece',
                value: 71.1
            },
            {
                name: 'Austria',
                value: 69.8
            },
            {
                name: 'Belarus',
                value: 67.7
            },
            {
                name: 'Serbia',
                value: 59.3
            },
            {
                name: 'Finland',
                value: 54.8
            },
            {
                name: 'Bulgaria',
                value: 51.2
            },
            {
                name: 'Portugal',
                value: 48.3
            },
            {
                name: 'Norway',
                value: 44.4
            },
            {
                name: 'Sweden',
                value: 44.3
            },
            {
                name: 'Hungary',
                value: 43.7
            },
            {
                name: 'Switzerland',
                value: 40.2
            },
            {
                name: 'Denmark',
                value: 40
            },
            {
                name: 'Slovakia',
                value: 34.7
            },
            {
                name: 'Ireland',
                value: 34.6
            },
            {
                name: 'Croatia',
                value: 20.7
            },
            {
                name: 'Estonia',
                value: 19.4
            },
            {
                name: 'Slovenia',
                value: 16.7
            },
            {
                name: 'Lithuania',
                value: 12.3
            },
            {
                name: 'Luxembourg',
                value: 10.4
            },
            {
                name: 'Macedonia',
                value: 9.5
            },
            {
                name: 'Moldova',
                value: 7.8
            },
            {
                name: 'Latvia',
                value: 7.5
            },
            {
                name: 'Cyprus',
                value: 7.2
            }]
        }, {
            name: 'Africa',
            data: [{
                name: 'Senegal',
                value: 8.2
            },
            {
                name: 'Cameroon',
                value: 9.2
            },
            {
                name: 'Zimbabwe',
                value: 13.1
            },
            {
                name: 'Ghana',
                value: 14.1
            },
            {
                name: 'Kenya',
                value: 14.1
            },
            {
                name: 'Sudan',
                value: 17.3
            },
            {
                name: 'Tunisia',
                value: 24.3
            },
            {
                name: 'Angola',
                value: 25
            },
            {
                name: 'Libya',
                value: 50.6
            },
            {
                name: 'Ivory Coast',
                value: 7.3
            },
            {
                name: 'Morocco',
                value: 60.7
            },
            {
                name: 'Ethiopia',
                value: 8.9
            },
            {
                name: 'United Republic of Tanzania',
                value: 9.1
            },
            {
                name: 'Nigeria',
                value: 93.9
            },
            {
                name: 'South Africa',
                value: 392.7
            }, {
                name: 'Egypt',
                value: 225.1
            }, {
                name: 'Algeria',
                value: 141.5
            }]
        }, {
            name: 'Oceania',
            data: [{
                name: 'Australia',
                value: 409.4
            },
            {
                name: 'New Zealand',
                value: 34.1
            },
            {
                name: 'Papua New Guinea',
                value: 7.1
            }]
        }, {
            name: 'North America',
            data: [{
                name: 'Costa Rica',
                value: 7.6
            },
            {
                name: 'Honduras',
                value: 8.4
            },
            {
                name: 'Jamaica',
                value: 8.3
            },
            {
                name: 'Panama',
                value: 10.2
            },
            {
                name: 'Guatemala',
                value: 12
            },
            {
                name: 'Dominican Republic',
                value: 23.4
            },
            {
                name: 'Cuba',
                value: 30.2
            },
            {
                name: 'USA',
                value: 5334.5
            }, {
                name: 'Canada',
                value: 566
            }, {
                name: 'Mexico',
                value: 456.3
            }]
        }, {
            name: 'South America',
            data: [{
                name: 'El Salvador',
                value: 7.2
            },
            {
                name: 'Uruguay',
                value: 8.1
            },
            {
                name: 'Bolivia',
                value: 17.8
            },
            {
                name: 'Trinidad and Tobago',
                value: 34
            },
            {
                name: 'Ecuador',
                value: 43
            },
            {
                name: 'Chile',
                value: 78.6
            },
            {
                name: 'Peru',
                value: 52
            },
            {
                name: 'Colombia',
                value: 74.1
            },
            {
                name: 'Brazil',
                value: 501.1
            }, {
                name: 'Argentina',
                value: 199
            },
            {
                name: 'Venezuela',
                value: 195.2
            }]
        }, {
            name: 'Asia',
            data: [{
                name: 'Nepal',
                value: 6.5
            },
            {
                name: 'Georgia',
                value: 6.5
            },
            {
                name: 'Brunei Darussalam',
                value: 7.4
            },
            {
                name: 'Kyrgyzstan',
                value: 7.4
            },
            {
                name: 'Afghanistan',
                value: 7.9
            },
            {
                name: 'Myanmar',
                value: 9.1
            },
            {
                name: 'Mongolia',
                value: 14.7
            },
            {
                name: 'Sri Lanka',
                value: 16.6
            },
            {
                name: 'Bahrain',
                value: 20.5
            },
            {
                name: 'Yemen',
                value: 22.6
            },
            {
                name: 'Jordan',
                value: 22.3
            },
            {
                name: 'Lebanon',
                value: 21.1
            },
            {
                name: 'Azerbaijan',
                value: 31.7
            },
            {
                name: 'Singapore',
                value: 47.8
            },
            {
                name: 'Hong Kong',
                value: 49.9
            },
            {
                name: 'Syria',
                value: 52.7
            },
            {
                name: 'DPR Korea',
                value: 59.9
            },
            {
                name: 'Israel',
                value: 64.8
            },
            {
                name: 'Turkmenistan',
                value: 70.6
            },
            {
                name: 'Oman',
                value: 74.3
            },
            {
                name: 'Qatar',
                value: 88.8
            },
            {
                name: 'Philippines',
                value: 96.9
            },
            {
                name: 'Kuwait',
                value: 98.6
            },
            {
                name: 'Uzbekistan',
                value: 122.6
            },
            {
                name: 'Iraq',
                value: 139.9
            },
            {
                name: 'Pakistan',
                value: 158.1
            },
            {
                name: 'Vietnam',
                value: 190.2
            },
            {
                name: 'United Arab Emirates',
                value: 201.1
            },
            {
                name: 'Malaysia',
                value: 227.5
            },
            {
                name: 'Kazakhstan',
                value: 236.2
            },
            {
                name: 'Thailand',
                value: 272
            },
            {
                name: 'Taiwan',
                value: 276.7
            },
            {
                name: 'Indonesia',
                value: 453
            },
            {
                name: 'Saudi Arabia',
                value: 494.8
            },
            {
                name: 'Japan',
                value: 1278.9
            },
            {
                name: 'China',
                value: 10540.8
            },
            {
                name: 'India',
                value: 2341.9
            },
            {
                name: 'Russia',
                value: 1766.4
            },
            {
                name: 'Iran',
                value: 618.2
            },
            {
                name: 'Korea',
                value: 610.1
            }]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 37,
        title: "3D column",
        image: "img/charts/electricity-production-i.png",
        category: "3D Charts",
        exampleData: [{
            name: 'South Korea',
            data: [563, 57, 590, 982, 571],
            stack: 'Asia'
        }, {
            name: 'Germany',
            data: [60, 654, 943, 612, 372],
            stack: 'Europe'
        }, {
            name: 'Saudi Arabia',
            data: [368, 318, 378, 167, 663],
            stack: 'Asia'
        }, {
            name: 'France',
            data: [564, 262, 582, 171, 433],
            stack: 'Europe'
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 38,
        title: "3D donuts",
        image: "img/charts/beijing-2022-gold-medals.png",
        category: "3D Charts",
        exampleData: [{
            name: 'Medals',
            data: [
                ['Norway', 16],
                ['Germany', 12],
                ['USA', 8],
                ['Sweden', 8],
                ['Netherlands', 8],
                ['ROC', 6],
                ['Austria', 7],
                ['Canada', 4],
                ['Japan', 3]

            ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 39,
        title: "3D funnel",
        image: "img/charts/highcharts-funnel3d-char.png",
        category: "3D Charts",
        exampleData: [{
            name: 'Unique users',
            data: [
                ['Website visits', 15654],
                ['Downloads', 4064],
                ['Requested price list', 1987],
                ['Invoice sent', 976],
                ['Finalized', 846]
            ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 40,
        title: "3D pyramid",
        image: "img/charts/highcharts-pyramid3d-cha.png",
        category: "3D Charts",
        exampleData: [{
            name: 'Unique users',
            data: [
                ['Website visits', 15654],
                ['Downloads', 4064],
                ['Requested price list', 1987],
                ['Invoice sent', 976],
                ['Finalized', 846]
            ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 42,
        title: "3D pie",
        image: "img/charts/global-smartphone-shipme.png",
        category: "3D Charts",
        exampleData: [{
            name: 'Share',
            data: [
                ['Samsung', 23],
                ['Apple', 18],
                {
                    name: 'Xiaomi',
                    y: 12
                },
                ['Oppo*', 9],
                ['Vivo', 8],
                ['Others', 30]
            ]
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 43,
        title: "3D cylinder",
        image: "img/charts/number-of-confirmed-covi.png",
        category: "3D Charts",
        exampleData: [{
            data: [1318, 1073, 1060, 813, 775, 745, 537, 444, 416, 395],
            colorByPoint: true
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 47,
        title: "Heat map",
        image: "img/charts/sales-per-employee-per-w.png",
        category: "Heat Maps",
        exampleData: [[0, 0, 10], [0, 1, 19], [0, 2, 8], [0, 3, 24], [0, 4, 67],
        [1, 0, 92], [1, 1, 58], [1, 2, 78], [1, 3, 117], [1, 4, 48],
        [2, 0, 35], [2, 1, 15], [2, 2, 123], [2, 3, 64], [2, 4, 52],
        [3, 0, 72], [3, 1, 132], [3, 2, 114], [3, 3, 19], [3, 4, 16],
        [4, 0, 38], [4, 1, 5], [4, 2, 8], [4, 3, 117], [4, 4, 115],
        [5, 0, 88], [5, 1, 32], [5, 2, 12], [5, 3, 6], [5, 4, 120],
        [6, 0, 13], [6, 1, 44], [6, 2, 88], [6, 3, 98], [6, 4, 96],
        [7, 0, 31], [7, 1, 1], [7, 2, 82], [7, 3, 32], [7, 4, 30],
        [8, 0, 85], [8, 1, 97], [8, 2, 123], [8, 3, 64], [8, 4, 84],
        [9, 0, 47], [9, 1, 114], [9, 2, 31], [9, 3, 48], [9, 4, 91]],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    // {
    //     id:48,
    //     title: "Calendar Heatmap",
    //     image: "img/charts/day-temperature-in-oslo.png",
    //     category: "Heat Maps",
    //     exampleData:[{
    //         date: '2023-07-01',
    //         temperature: 19.1
    //     },
    //     {
    //         date: '2023-07-02',
    //         temperature: 15.3
    //     },
    //     {
    //         date: '2023-07-03',
    //         temperature: 16.4
    //     },
    //     {
    //         date: '2023-07-04',
    //         temperature: 16.0
    //     },
    //     {
    //         date: '2023-07-05',
    //         temperature: 17.9
    //     },
    //     {
    //         date: '2023-07-06',
    //         temperature: 15.8
    //     },
    //     {
    //         date: '2023-07-07',
    //         temperature: 21.1
    //     },
    //     {
    //         date: '2023-07-08',
    //         temperature: 23.3
    //     },
    //     {
    //         date: '2023-07-09',
    //         temperature: 24.8
    //     },
    //     {
    //         date: '2023-07-10',
    //         temperature: 25.1
    //     },
    //     {
    //         date: '2023-07-11',
    //         temperature: 18.2
    //     },
    //     {
    //         date: '2023-07-12',
    //         temperature: 14.4
    //     },
    //     {
    //         date: '2023-07-13',
    //         temperature: 19.3
    //     },
    //     {
    //         date: '2023-07-14',
    //         temperature: 20.2
    //     },
    //     {
    //         date: '2023-07-15',
    //         temperature: 15.8
    //     },
    //     {
    //         date: '2023-07-16',
    //         temperature: 16.1
    //     },
    //     {
    //         date: '2023-07-17',
    //         temperature: 15.7
    //     },
    //     {
    //         date: '2023-07-18',
    //         temperature: 19.2
    //     },
    //     {
    //         date: '2023-07-19',
    //         temperature: 18.6
    //     },
    //     {
    //         date: '2023-07-20',
    //         temperature: 18.3
    //     },
    //     {
    //         date: '2023-07-21',
    //         temperature: 15.0
    //     },
    //     {
    //         date: '2023-07-22',
    //         temperature: 14.7
    //     },
    //     {
    //         date: '2023-07-23',
    //         temperature: 18.8
    //     },
    //     {
    //         date: '2023-07-24',
    //         temperature: 17.7
    //     },
    //     {
    //         date: '2023-07-25',
    //         temperature: 17.4
    //     },
    //     {
    //         date: '2023-07-26',
    //         temperature: 17.6
    //     },
    //     {
    //         date: '2023-07-27',
    //         temperature: 18.1
    //     },
    //     {
    //         date: '2023-07-28',
    //         temperature: 18.2
    //     },
    //     {
    //         date: '2023-07-29',
    //         temperature: 20.3
    //     },
    //     {
    //         date: '2023-07-30',
    //         temperature: 16.4
    //     },
    //     {
    //         date: '2023-07-31',
    //         temperature: 17.0
    //     }]
    // },
    {
        id: 49,
        title: "Large heat map",
        image: "img/charts/highcharts-heat-map.png",
        category: "Heat Maps",
        exampleData: [[0, 0, 10], [0, 1, 19], [0, 2, 8], [0, 3, 24], [0, 4, 67],
        [1, 0, 92], [1, 1, 58], [1, 2, 78], [1, 3, 117], [1, 4, 48],
        [2, 0, 35], [2, 1, 15], [2, 2, 123], [2, 3, 64], [2, 4, 52],
        [3, 0, 72], [3, 1, 132], [3, 2, 114], [3, 3, 19], [3, 4, 16],
        [4, 0, 38], [4, 1, 5], [4, 2, 8], [4, 3, 117], [4, 4, 115],
        [5, 0, 88], [5, 1, 32], [5, 2, 12], [5, 3, 6], [5, 4, 120],
        [6, 0, 13], [6, 1, 44], [6, 2, 88], [6, 3, 98], [6, 4, 96],
        [7, 0, 31], [7, 1, 1], [7, 2, 82], [7, 3, 32], [7, 4, 30],
        [8, 0, 85], [8, 1, 97], [8, 2, 123], [8, 3, 64], [8, 4, 84],
        [9, 0, 47], [9, 1, 114], [9, 2, 31], [9, 3, 48], [9, 4, 91]],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 50,
        title: "map with color axis",
        image: "img/charts/highcharts-treemap.png",
        category: "Heat Maps",
        exampleData: [{
            name: 'A',
            value: 6
        }, {
            name: 'B',
            value: 6
        }, {
            name: 'C',
            value: 4
        }, {
            name: 'D',
            value: 3
        }, {
            name: 'E',
            value: 2
        }, {
            name: 'F',
            value: 2
        }, {
            name: 'G',
            value: 1
        }],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        },
        treeMap: "Tree"
    },
    {
        id: 51,
        title: "Flags marking events",
        image: "img/charts/singleSeries.png",
        category: "Stock Charts",
        exampleData: [
            [
                1644503400000,
                172.12
            ],
            [
                1644589800000,
                168.64
            ],
            [
                1644849000000,
                168.88
            ],
            [
                1644935400000,
                172.79
            ],
            [
                1645021800000,
                172.55
            ],
            [
                1645108200000,
                168.88
            ],
            [
                1645194600000,
                167.3
            ],
            [
                1645540200000,
                164.32
            ],
            [
                1645626600000,
                160.07
            ],
            [
                1645713000000,
                162.74
            ],
            [
                1645799400000,
                164.85
            ],
            [
                1646058600000,
                165.12
            ],
            [
                1646145000000,
                163.2
            ],
            [
                1646231400000,
                166.56
            ],
            [
                1646317800000,
                166.23
            ],
            [
                1646404200000,
                163.17
            ],
            [
                1646663400000,
                159.3
            ],
            [
                1646749800000,
                157.44
            ],
            [
                1646836200000,
                162.95
            ],
            [
                1646922600000,
                158.52
            ],
            [
                1647009000000,
                154.73
            ],
            [
                1647264600000,
                150.62
            ],
            [
                1647351000000,
                155.09
            ],
            [
                1647437400000,
                159.59
            ],
            [
                1647523800000,
                160.62
            ],
            [
                1647610200000,
                163.98
            ],
            [
                1647869400000,
                165.38
            ],
            [
                1647955800000,
                168.82
            ],
            [
                1648042200000,
                170.21
            ],
            [
                1648128600000,
                174.07
            ],
            [
                1648215000000,
                174.72
            ],
            [
                1648474200000,
                175.6
            ],
            [
                1648560600000,
                178.96
            ],
            [
                1648647000000,
                177.77
            ],
            [
                1648733400000,
                174.61
            ],
            [
                1648819800000,
                174.31
            ],
            [
                1649079000000,
                178.44
            ],
            [
                1649165400000,
                175.06
            ],
            [
                1649251800000,
                171.83
            ],
            [
                1649338200000,
                172.14
            ],
            [
                1649424600000,
                170.09
            ],
            [
                1649683800000,
                165.75
            ],
            [
                1649770200000,
                167.66
            ],
            [
                1649856600000,
                170.4
            ],
            [
                1649943000000,
                165.29
            ],
            [
                1650288600000,
                165.07
            ],
            [
                1650375000000,
                167.4
            ],
            [
                1650461400000,
                167.23
            ],
            [
                1650547800000,
                166.42
            ],
            [
                1650634200000,
                161.79
            ],
            [
                1650893400000,
                162.88
            ],
            [
                1650979800000,
                156.8
            ],
            [
                1651066200000,
                156.57
            ],
            [
                1651152600000,
                163.64
            ],
            [
                1651239000000,
                157.65
            ],
            [
                1651498200000,
                157.96
            ],
            [
                1651584600000,
                159.48
            ],
            [
                1651671000000,
                166.02
            ],
            [
                1651757400000,
                156.77
            ],
            [
                1651843800000,
                157.28
            ],
            [
                1652103000000,
                152.06
            ],
            [
                1652189400000,
                154.51
            ],
            [
                1652275800000,
                146.5
            ],
            [
                1652362200000,
                142.56
            ],
            [
                1652448600000,
                147.11
            ],
            [
                1652707800000,
                145.54
            ],
            [
                1652794200000,
                149.24
            ],
            [
                1652880600000,
                140.82
            ],
            [
                1652967000000,
                137.35
            ],
            [
                1653053400000,
                137.59
            ],
            [
                1653312600000,
                143.11
            ],
            [
                1653399000000,
                140.36
            ],
            [
                1653485400000,
                140.52
            ],
            [
                1653571800000,
                143.78
            ],
            [
                1653658200000,
                149.64
            ],
            [
                1654003800000,
                148.84
            ],
            [
                1654090200000,
                148.71
            ],
            [
                1654176600000,
                151.21
            ],
            [
                1654263000000,
                145.38
            ],
            [
                1654522200000,
                146.14
            ],
            [
                1654608600000,
                148.71
            ],
            [
                1654695000000,
                147.96
            ],
            [
                1654781400000,
                142.64
            ],
            [
                1654867800000,
                137.13
            ],
            [
                1655127000000,
                131.88
            ],
            [
                1655213400000,
                132.76
            ],
            [
                1655299800000,
                135.43
            ],
            [
                1655386200000,
                130.06
            ],
            [
                1655472600000,
                131.56
            ],
            [
                1655818200000,
                135.87
            ],
            [
                1655904600000,
                135.35
            ],
            [
                1655991000000,
                138.27
            ],
            [
                1656077400000,
                141.66
            ],
            [
                1656336600000,
                141.66
            ],
            [
                1656423000000,
                137.44
            ],
            [
                1656509400000,
                139.23
            ],
            [
                1656595800000,
                136.72
            ],
            [
                1656682200000,
                138.93
            ],
            [
                1657027800000,
                141.56
            ],
            [
                1657114200000,
                142.92
            ],
            [
                1657200600000,
                146.35
            ],
            [
                1657287000000,
                147.04
            ],
            [
                1657546200000,
                144.87
            ],
            [
                1657632600000,
                145.86
            ],
            [
                1657719000000,
                145.49
            ],
            [
                1657805400000,
                148.47
            ],
            [
                1657891800000,
                150.17
            ],
            [
                1658151000000,
                147.07
            ],
            [
                1658237400000,
                151
            ],
            [
                1658323800000,
                153.04
            ],
            [
                1658410200000,
                155.35
            ],
            [
                1658496600000,
                154.09
            ],
            [
                1658755800000,
                152.95
            ],
            [
                1658842200000,
                151.6
            ],
            [
                1658928600000,
                156.79
            ],
            [
                1659015000000,
                157.35
            ],
            [
                1659101400000,
                162.51
            ],
            [
                1659360600000,
                161.51
            ],
            [
                1659447000000,
                160.01
            ],
            [
                1659533400000,
                166.13
            ],
            [
                1659619800000,
                165.81
            ],
            [
                1659706200000,
                165.35
            ],
            [
                1659965400000,
                164.87
            ],
            [
                1660051800000,
                164.92
            ],
            [
                1660138200000,
                169.24
            ],
            [
                1660224600000,
                168.49
            ],
            [
                1660311000000,
                172.1
            ],
            [
                1660570200000,
                173.19
            ],
            [
                1660656600000,
                173.03
            ],
            [
                1660743000000,
                174.55
            ],
            [
                1660829400000,
                174.15
            ],
            [
                1660915800000,
                171.52
            ],
            [
                1661175000000,
                167.57
            ],
            [
                1661261400000,
                167.23
            ],
            [
                1661347800000,
                167.53
            ],
            [
                1661434200000,
                170.03
            ],
            [
                1661520600000,
                163.62
            ],
            [
                1661779800000,
                161.38
            ],
            [
                1661866200000,
                158.91
            ],
            [
                1661952600000,
                157.22
            ],
            [
                1662039000000,
                157.96
            ],
            [
                1662125400000,
                155.81
            ],
            [
                1662471000000,
                154.53
            ],
            [
                1662557400000,
                155.96
            ],
            [
                1662643800000,
                154.46
            ],
            [
                1662730200000,
                157.37
            ],
            [
                1662989400000,
                163.43
            ],
            [
                1663075800000,
                153.84
            ],
            [
                1663162200000,
                155.31
            ],
            [
                1663248600000,
                152.37
            ],
            [
                1663335000000,
                150.7
            ],
            [
                1663594200000,
                154.48
            ],
            [
                1663680600000,
                156.9
            ],
            [
                1663767000000,
                153.72
            ],
            [
                1663853400000,
                152.74
            ],
            [
                1663939800000,
                150.43
            ],
            [
                1664199000000,
                150.77
            ],
            [
                1664285400000,
                151.76
            ],
            [
                1664371800000,
                149.84
            ],
            [
                1664458200000,
                142.48
            ],
            [
                1664544600000,
                138.2
            ],
            [
                1664803800000,
                142.45
            ],
            [
                1664890200000,
                146.1
            ],
            [
                1664976600000,
                146.4
            ],
            [
                1665063000000,
                145.43
            ],
            [
                1665149400000,
                140.09
            ],
            [
                1665408600000,
                140.42
            ],
            [
                1665495000000,
                138.98
            ],
            [
                1665581400000,
                138.34
            ],
            [
                1665667800000,
                142.99
            ],
            [
                1665754200000,
                138.38
            ],
            [
                1666013400000,
                142.41
            ],
            [
                1666099800000,
                143.75
            ],
            [
                1666186200000,
                143.86
            ],
            [
                1666272600000,
                143.39
            ],
            [
                1666359000000,
                147.27
            ],
            [
                1666618200000,
                149.45
            ],
            [
                1666704600000,
                152.34
            ],
            [
                1666791000000,
                149.35
            ],
            [
                1666877400000,
                144.8
            ],
            [
                1666963800000,
                155.74
            ],
            [
                1667223000000,
                153.34
            ],
            [
                1667309400000,
                150.65
            ],
            [
                1667395800000,
                145.03
            ],
            [
                1667482200000,
                138.88
            ],
            [
                1667568600000,
                138.38
            ],
            [
                1667831400000,
                138.92
            ],
            [
                1667917800000,
                139.5
            ],
            [
                1668004200000,
                134.87
            ],
            [
                1668090600000,
                146.87
            ],
            [
                1668177000000,
                149.7
            ],
            [
                1668436200000,
                148.28
            ],
            [
                1668522600000,
                150.04
            ],
            [
                1668609000000,
                148.79
            ],
            [
                1668695400000,
                150.72
            ],
            [
                1668781800000,
                151.29
            ],
            [
                1669041000000,
                148.01
            ],
            [
                1669127400000,
                150.18
            ],
            [
                1669213800000,
                151.07
            ],
            [
                1669386600000,
                148.11
            ],
            [
                1669645800000,
                144.22
            ],
            [
                1669732200000,
                141.17
            ],
            [
                1669818600000,
                148.03
            ],
            [
                1669905000000,
                148.31
            ],
            [
                1669991400000,
                147.81
            ],
            [
                1670250600000,
                146.63
            ],
            [
                1670337000000,
                142.91
            ],
            [
                1670423400000,
                140.94
            ],
            [
                1670509800000,
                142.65
            ],
            [
                1670596200000,
                142.16
            ],
            [
                1670855400000,
                144.49
            ],
            [
                1670941800000,
                145.47
            ],
            [
                1671028200000,
                143.21
            ],
            [
                1671114600000,
                136.5
            ],
            [
                1671201000000,
                134.51
            ],
            [
                1671460200000,
                132.37
            ],
            [
                1671546600000,
                132.3
            ],
            [
                1671633000000,
                135.45
            ],
            [
                1671719400000,
                132.23
            ],
            [
                1671805800000,
                131.86
            ],
            [
                1672151400000,
                130.03
            ],
            [
                1672237800000,
                126.04
            ],
            [
                1672324200000,
                129.61
            ],
            [
                1672410600000,
                129.93
            ],
            [
                1672756200000,
                125.07
            ],
            [
                1672842600000,
                126.36
            ],
            [
                1672929000000,
                125.02
            ],
            [
                1673015400000,
                129.62
            ],
            [
                1673274600000,
                130.15
            ],
            [
                1673361000000,
                130.73
            ],
            [
                1673447400000,
                133.49
            ],
            [
                1673533800000,
                133.41
            ],
            [
                1673620200000,
                134.76
            ],
            [
                1673965800000,
                135.94
            ],
            [
                1674052200000,
                135.21
            ],
            [
                1674138600000,
                135.27
            ],
            [
                1674225000000,
                137.87
            ],
            [
                1674484200000,
                141.11
            ],
            [
                1674570600000,
                142.53
            ],
            [
                1674657000000,
                141.86
            ],
            [
                1674743400000,
                143.96
            ],
            [
                1674829800000,
                145.93
            ],
            [
                1675089000000,
                143
            ],
            [
                1675175400000,
                144.29
            ],
            [
                1675261800000,
                145.43
            ],
            [
                1675348200000,
                150.82
            ],
            [
                1675434600000,
                154.5
            ],
            [
                1675693800000,
                151.73
            ],
            [
                1675780200000,
                154.65
            ],
            [
                1675866600000,
                151.92
            ],
            [
                1675953000000,
                150.87
            ],
            [
                1676039400000,
                151.01
            ],
            [
                1676298600000,
                153.85
            ],
            [
                1676385000000,
                153.2
            ],
            [
                1676471400000,
                155.33
            ],
            [
                1676557800000,
                153.71
            ],
            [
                1676644200000,
                152.55
            ],
            [
                1676989800000,
                148.48
            ],
            [
                1677076200000,
                148.91
            ],
            [
                1677162600000,
                149.4
            ],
            [
                1677249000000,
                146.71
            ],
            [
                1677508200000,
                147.92
            ],
            [
                1677594600000,
                147.41
            ],
            [
                1677681000000,
                145.31
            ],
            [
                1677767400000,
                145.91
            ],
            [
                1677853800000,
                151.03
            ],
            [
                1678113000000,
                153.83
            ],
            [
                1678199400000,
                151.6
            ],
            [
                1678285800000,
                152.87
            ],
            [
                1678372200000,
                150.59
            ],
            [
                1678458600000,
                148.5
            ],
            [
                1678714200000,
                150.47
            ],
            [
                1678800600000,
                152.59
            ],
            [
                1678887000000,
                152.99
            ],
            [
                1678973400000,
                155.85
            ],
            [
                1679059800000,
                155
            ],
            [
                1679319000000,
                157.4
            ],
            [
                1679405400000,
                159.28
            ],
            [
                1679491800000,
                157.83
            ],
            [
                1679578200000,
                158.93
            ],
            [
                1679664600000,
                160.25
            ],
            [
                1679923800000,
                158.28
            ],
            [
                1680010200000,
                157.65
            ],
            [
                1680096600000,
                160.77
            ],
            [
                1680183000000,
                162.36
            ],
            [
                1680269400000,
                164.9
            ],
            [
                1680528600000,
                166.17
            ],
            [
                1680615000000,
                165.63
            ],
            [
                1680701400000,
                163.76
            ],
            [
                1680787800000,
                164.66
            ],
            [
                1681133400000,
                162.03
            ],
            [
                1681219800000,
                160.8
            ],
            [
                1681306200000,
                160.1
            ],
            [
                1681392600000,
                165.56
            ],
            [
                1681479000000,
                165.21
            ],
            [
                1681738200000,
                165.23
            ],
            [
                1681824600000,
                166.47
            ],
            [
                1681911000000,
                167.63
            ],
            [
                1681997400000,
                166.65
            ],
            [
                1682083800000,
                165.02
            ],
            [
                1682343000000,
                165.33
            ],
            [
                1682429400000,
                163.77
            ],
            [
                1682515800000,
                163.76
            ],
            [
                1682602200000,
                168.41
            ],
            [
                1682688600000,
                169.68
            ],
            [
                1682947800000,
                169.59
            ],
            [
                1683034200000,
                168.54
            ],
            [
                1683120600000,
                167.45
            ],
            [
                1683207000000,
                165.79
            ],
            [
                1683293400000,
                173.57
            ],
            [
                1683552600000,
                173.5
            ],
            [
                1683639000000,
                171.77
            ],
            [
                1683725400000,
                173.56
            ],
            [
                1683811800000,
                173.75
            ],
            [
                1683898200000,
                172.57
            ],
            [
                1684157400000,
                172.07
            ],
            [
                1684243800000,
                172.07
            ],
            [
                1684330200000,
                172.69
            ],
            [
                1684416600000,
                175.05
            ],
            [
                1684503000000,
                175.16
            ],
            [
                1684762200000,
                174.2
            ],
            [
                1684848600000,
                171.56
            ],
            [
                1684935000000,
                171.84
            ],
            [
                1685021400000,
                172.99
            ],
            [
                1685107800000,
                175.43
            ],
            [
                1685453400000,
                177.3
            ],
            [
                1685539800000,
                177.25
            ],
            [
                1685626200000,
                180.09
            ],
            [
                1685712600000,
                180.95
            ],
            [
                1685971800000,
                179.58
            ],
            [
                1686058200000,
                179.21
            ],
            [
                1686144600000,
                177.82
            ],
            [
                1686231000000,
                180.57
            ],
            [
                1686317400000,
                180.96
            ],
            [
                1686576600000,
                183.79
            ],
            [
                1686663000000,
                183.31
            ],
            [
                1686749400000,
                183.95
            ],
            [
                1686835800000,
                186.01
            ],
            [
                1686922200000,
                184.92
            ],
            [
                1687267800000,
                185.01
            ],
            [
                1687354200000,
                183.96
            ],
            [
                1687440600000,
                187
            ],
            [
                1687527000000,
                186.68
            ],
            [
                1687786200000,
                185.27
            ],
            [
                1687872600000,
                188.06
            ],
            [
                1687959000000,
                189.25
            ],
            [
                1688045400000,
                189.59
            ],
            [
                1688131800000,
                193.97
            ],
            [
                1688391000000,
                192.46
            ],
            [
                1688563800000,
                191.33
            ],
            [
                1688650200000,
                191.81
            ],
            [
                1688736600000,
                190.68
            ],
            [
                1688995800000,
                188.61
            ],
            [
                1689082200000,
                188.08
            ],
            [
                1689168600000,
                189.77
            ],
            [
                1689255000000,
                190.54
            ],
            [
                1689341400000,
                190.69
            ],
            [
                1689600600000,
                193.99
            ],
            [
                1689687000000,
                193.73
            ],
            [
                1689773400000,
                195.1
            ],
            [
                1689859800000,
                193.13
            ],
            [
                1689946200000,
                191.94
            ],
            [
                1690205400000,
                192.75
            ],
            [
                1690291800000,
                193.62
            ],
            [
                1690378200000,
                194.5
            ],
            [
                1690464600000,
                193.22
            ],
            [
                1690551000000,
                195.83
            ],
            [
                1690810200000,
                196.45
            ],
            [
                1690896600000,
                195.61
            ],
            [
                1690983000000,
                192.58
            ],
            [
                1691069400000,
                191.17
            ],
            [
                1691155800000,
                181.99
            ],
            [
                1691415000000,
                178.85
            ],
            [
                1691501400000,
                179.8
            ],
            [
                1691587800000,
                178.19
            ],
            [
                1691674200000,
                177.97
            ],
            [
                1691760600000,
                177.79
            ],
            [
                1692019800000,
                179.46
            ],
            [
                1692106200000,
                177.45
            ],
            [
                1692192600000,
                176.57
            ],
            [
                1692279000000,
                174
            ],
            [
                1692365400000,
                174.49
            ],
            [
                1692624600000,
                175.84
            ],
            [
                1692711000000,
                177.23
            ],
            [
                1692797400000,
                181.12
            ],
            [
                1692883800000,
                176.38
            ],
            [
                1692970200000,
                178.61
            ],
            [
                1693229400000,
                180.19
            ],
            [
                1693315800000,
                184.12
            ],
            [
                1693402200000,
                187.65
            ],
            [
                1693488600000,
                187.87
            ],
            [
                1693575000000,
                189.46
            ],
            [
                1693920600000,
                189.7
            ],
            [
                1694007000000,
                182.91
            ],
            [
                1694093400000,
                177.56
            ],
            [
                1694179800000,
                178.18
            ],
            [
                1694439000000,
                179.36
            ],
            [
                1694525400000,
                176.3
            ],
            [
                1694611800000,
                174.21
            ],
            [
                1694698200000,
                175.74
            ],
            [
                1694784600000,
                175.01
            ],
            [
                1695043800000,
                177.97
            ],
            [
                1695130200000,
                179.07
            ],
            [
                1695216600000,
                175.49
            ],
            [
                1695303000000,
                173.93
            ],
            [
                1695389400000,
                174.79
            ],
            [
                1695648600000,
                176.08
            ],
            [
                1695735000000,
                171.96
            ],
            [
                1695821400000,
                170.43
            ],
            [
                1695907800000,
                170.69
            ],
            [
                1695994200000,
                171.21
            ],
            [
                1696253400000,
                173.75
            ],
            [
                1696339800000,
                172.4
            ],
            [
                1696426200000,
                173.66
            ],
            [
                1696512600000,
                174.91
            ],
            [
                1696599000000,
                177.49
            ],
            [
                1696858200000,
                178.99
            ],
            [
                1696944600000,
                178.39
            ],
            [
                1697031000000,
                179.8
            ],
            [
                1697117400000,
                180.71
            ],
            [
                1697203800000,
                178.85
            ],
            [
                1697463000000,
                178.72
            ],
            [
                1697549400000,
                177.15
            ],
            [
                1697635800000,
                175.84
            ],
            [
                1697722200000,
                175.46
            ],
            [
                1697808600000,
                172.88
            ],
            [
                1698067800000,
                173
            ],
            [
                1698154200000,
                173.44
            ],
            [
                1698240600000,
                171.1
            ],
            [
                1698327000000,
                166.89
            ],
            [
                1698413400000,
                168.22
            ],
            [
                1698672600000,
                170.29
            ],
            [
                1698759000000,
                170.77
            ],
            [
                1698845400000,
                173.97
            ],
            [
                1698931800000,
                177.57
            ],
            [
                1699018200000,
                176.65
            ],
            [
                1699281000000,
                179.23
            ],
            [
                1699367400000,
                181.82
            ],
            [
                1699453800000,
                182.89
            ],
            [
                1699540200000,
                182.41
            ],
            [
                1699626600000,
                186.4
            ],
            [
                1699885800000,
                184.8
            ],
            [
                1699972200000,
                187.44
            ],
            [
                1700058600000,
                188.01
            ],
            [
                1700145000000,
                189.71
            ],
            [
                1700231400000,
                189.69
            ],
            [
                1700490600000,
                191.45
            ],
            [
                1700577000000,
                190.64
            ],
            [
                1700663400000,
                191.31
            ],
            [
                1700836200000,
                189.97
            ],
            [
                1701095400000,
                189.79
            ],
            [
                1701181800000,
                190.4
            ],
            [
                1701268200000,
                189.37
            ],
            [
                1701354600000,
                189.95
            ],
            [
                1701441000000,
                191.24
            ],
            [
                1701700200000,
                189.43
            ],
            [
                1701786600000,
                193.42
            ],
            [
                1701873000000,
                192.32
            ],
            [
                1701959400000,
                194.27
            ],
            [
                1702045800000,
                195.71
            ],
            [
                1702305000000,
                193.18
            ],
            [
                1702391400000,
                194.71
            ],
            [
                1702477800000,
                197.96
            ],
            [
                1702564200000,
                198.11
            ],
            [
                1702650600000,
                197.57
            ],
            [
                1702909800000,
                195.89
            ],
            [
                1702996200000,
                196.94
            ],
            [
                1703082600000,
                194.83
            ],
            [
                1703169000000,
                194.68
            ],
            [
                1703255400000,
                193.6
            ],
            [
                1703601000000,
                193.05
            ],
            [
                1703687400000,
                193.15
            ],
            [
                1703773800000,
                193.58
            ],
            [
                1703860200000,
                192.53
            ],
            [
                1704205800000,
                185.64
            ],
            [
                1704292200000,
                184.25
            ],
            [
                1704378600000,
                181.91
            ],
            [
                1704465000000,
                181.18
            ],
            [
                1704724200000,
                185.56
            ],
            [
                1704810600000,
                185.14
            ],
            [
                1704897000000,
                186.19
            ],
            [
                1704983400000,
                185.59
            ],
            [
                1705069800000,
                185.92
            ],
            [
                1705415400000,
                183.63
            ],
            [
                1705501800000,
                182.68
            ],
            [
                1705588200000,
                188.63
            ],
            [
                1705674600000,
                191.56
            ],
            [
                1705933800000,
                193.89
            ],
            [
                1706020200000,
                195.18
            ],
            [
                1706106600000,
                194.5
            ],
            [
                1706193000000,
                194.17
            ],
            [
                1706279400000,
                192.42
            ],
            [
                1706538600000,
                191.73
            ],
            [
                1706625000000,
                188.04
            ],
            [
                1706711400000,
                184.4
            ],
            [
                1706797800000,
                186.86
            ],
            [
                1706884200000,
                185.85
            ],
            [
                1707143400000,
                187.68
            ],
            [
                1707229800000,
                189.3
            ],
            [
                1707316200000,
                189.41
            ],
            [
                1707402600000,
                188.32
            ],
            [
                1707489000000,
                188.85
            ]
        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        },
    },
    {
        id: 52,
        title: "Intraday candlestick",
        image: "img/charts/aapl-stock-price-by-min.png",
        category: "Stock Charts",
        exampleData: [[1644503400000, 174.14, 175.48, 171.55, 172.12], [1644589800000, 172.33, 173.08, 168.04, 168.64], [1644849000000, 167.37, 169.58, 166.56, 168.88], [1644935400000, 170.97, 172.95, 170.25, 172.79], [1645021800000, 171.85, 173.34, 170.05, 172.55], [1645108200000, 171.03, 171.91, 168.47, 168.88], [1645194600000, 169.82, 170.54, 166.19, 167.3], [1645540200000, 164.98, 166.69, 162.15, 164.32], [1645626600000, 165.54, 166.15, 159.75, 160.07], [1645713000000, 152.58, 162.85, 152, 162.74], [1645799400000, 163.84, 165.12, 160.87, 164.85], [1646058600000, 163.06, 165.42, 162.43, 165.12], [1646145000000, 164.7, 166.6, 161.97, 163.2], [1646231400000, 164.39, 167.36, 162.95, 166.56], [1646317800000, 168.47, 168.91, 165.55, 166.23], [1646404200000, 164.49, 165.55, 162.1, 163.17], [1646663400000, 163.36, 165.02, 159.04, 159.3], [1646749800000, 158.82, 162.88, 155.8, 157.44], [1646836200000, 161.48, 163.41, 159.41, 162.95], [1646922600000, 160.2, 160.39, 155.98, 158.52], [1647009000000, 158.93, 159.28, 154.5, 154.73], [1647264600000, 151.45, 154.12, 150.1, 150.62], [1647351000000, 150.9, 155.57, 150.38, 155.09], [1647437400000, 157.05, 160, 154.46, 159.59], [1647523800000, 158.61, 161, 157.63, 160.62], [1647610200000, 160.51, 164.48, 159.76, 163.98], [1647869400000, 163.51, 166.35, 163.01, 165.38], [1647955800000, 165.51, 169.42, 164.91, 168.82], [1648042200000, 167.99, 172.64, 167.65, 170.21], [1648128600000, 171.06, 174.14, 170.21, 174.07], [1648215000000, 173.88, 175.28, 172.75, 174.72], [1648474200000, 172.17, 175.73, 172, 175.6], [1648560600000, 176.69, 179.01, 176.34, 178.96], [1648647000000, 178.55, 179.61, 176.7, 177.77], [1648733400000, 177.84, 178.03, 174.4, 174.61], [1648819800000, 174.03, 174.88, 171.94, 174.31], [1649079000000, 174.57, 178.49, 174.44, 178.44], [1649165400000, 177.5, 178.3, 174.42, 175.06], [1649251800000, 172.36, 173.63, 170.13, 171.83], [1649338200000, 171.16, 173.36, 169.85, 172.14], [1649424600000, 171.78, 171.78, 169.2, 170.09], [1649683800000, 168.71, 169.03, 165.5, 165.75], [1649770200000, 168.02, 169.87, 166.64, 167.66], [1649856600000, 167.39, 171.04, 166.77, 170.4], [1649943000000, 170.62, 171.27, 165.04, 165.29], [1650288600000, 163.92, 166.6, 163.57, 165.07], [1650375000000, 165.02, 167.82, 163.91, 167.4], [1650461400000, 168.76, 168.88, 166.1, 167.23], [1650547800000, 168.91, 171.53, 165.91, 166.42], [1650634200000, 166.46, 167.87, 161.5, 161.79], [1650893400000, 161.12, 163.17, 158.46, 162.88], [1650979800000, 162.25, 162.34, 156.72, 156.8], [1651066200000, 155.91, 159.79, 155.38, 156.57], [1651152600000, 159.25, 164.52, 158.93, 163.64], [1651239000000, 161.84, 166.2, 157.25, 157.65], [1651498200000, 156.71, 158.23, 153.27, 157.96], [1651584600000, 158.15, 160.71, 156.32, 159.48], [1651671000000, 159.67, 166.48, 159.26, 166.02], [1651757400000, 163.85, 164.08, 154.95, 156.77], [1651843800000, 156.01, 159.44, 154.18, 157.28], [1652103000000, 154.93, 155.83, 151.49, 152.06], [1652189400000, 155.52, 156.74, 152.93, 154.51], [1652275800000, 153.5, 155.45, 145.81, 146.5], [1652362200000, 142.77, 146.2, 138.8, 142.56], [1652448600000, 144.59, 148.1, 143.11, 147.11], [1652707800000, 145.55, 147.52, 144.18, 145.54], [1652794200000, 148.86, 149.77, 146.68, 149.24], [1652880600000, 146.85, 147.36, 139.9, 140.82], [1652967000000, 139.88, 141.66, 136.6, 137.35], [1653053400000, 139.09, 140.7, 132.61, 137.59], [1653312600000, 137.79, 143.26, 137.65, 143.11], [1653399000000, 140.81, 141.97, 137.33, 140.36], [1653485400000, 138.43, 141.79, 138.34, 140.52], [1653571800000, 137.39, 144.34, 137.14, 143.78], [1653658200000, 145.39, 149.68, 145.26, 149.64], [1654003800000, 149.07, 150.66, 146.84, 148.84], [1654090200000, 149.9, 151.74, 147.68, 148.71], [1654176600000, 147.83, 151.27, 146.86, 151.21], [1654263000000, 146.9, 147.97, 144.46, 145.38], [1654522200000, 147.03, 148.57, 144.9, 146.14], [1654608600000, 144.35, 149, 144.1, 148.71], [1654695000000, 148.58, 149.87, 147.46, 147.96], [1654781400000, 147.08, 147.95, 142.53, 142.64], [1654867800000, 140.28, 140.76, 137.06, 137.13], [1655127000000, 132.87, 135.2, 131.44, 131.88], [1655213400000, 133.13, 133.89, 131.48, 132.76], [1655299800000, 134.29, 137.34, 132.16, 135.43], [1655386200000, 132.08, 132.39, 129.04, 130.06], [1655472600000, 130.07, 133.08, 129.81, 131.56], [1655818200000, 133.42, 137.06, 133.32, 135.87], [1655904600000, 134.79, 137.76, 133.91, 135.35], [1655991000000, 136.82, 138.59, 135.63, 138.27], [1656077400000, 139.9, 141.91, 139.77, 141.66], [1656336600000, 142.7, 143.49, 140.97, 141.66], [1656423000000, 142.13, 143.42, 137.32, 137.44], [1656509400000, 137.46, 140.67, 136.67, 139.23], [1656595800000, 137.25, 138.37, 133.77, 136.72], [1656682200000, 136.04, 139.04, 135.66, 138.93], [1657027800000, 137.77, 141.61, 136.93, 141.56], [1657114200000, 141.35, 144.12, 141.08, 142.92], [1657200600000, 143.29, 146.55, 143.28, 146.35], [1657287000000, 145.26, 147.55, 145, 147.04], [1657546200000, 145.67, 146.64, 143.78, 144.87], [1657632600000, 145.76, 148.45, 145.05, 145.86], [1657719000000, 142.99, 146.45, 142.12, 145.49], [1657805400000, 144.08, 148.95, 143.25, 148.47], [1657891800000, 149.78, 150.86, 148.2, 150.17], [1658151000000, 150.74, 151.57, 146.7, 147.07], [1658237400000, 147.92, 151.23, 146.91, 151], [1658323800000, 151.12, 153.72, 150.37, 153.04], [1658410200000, 154.5, 155.57, 151.94, 155.35], [1658496600000, 155.39, 156.28, 153.41, 154.09], [1658755800000, 154.01, 155.04, 152.28, 152.95], [1658842200000, 152.26, 153.09, 150.8, 151.6], [1658928600000, 152.58, 157.33, 152.16, 156.79], [1659015000000, 156.98, 157.64, 154.41, 157.35], [1659101400000, 161.24, 163.63, 159.5, 162.51], [1659360600000, 161.01, 163.59, 160.89, 161.51], [1659447000000, 160.1, 162.41, 159.63, 160.01], [1659533400000, 160.84, 166.59, 160.75, 166.13], [1659619800000, 166.01, 167.19, 164.43, 165.81], [1659706200000, 163.21, 165.85, 163, 165.35], [1659965400000, 166.37, 167.81, 164.2, 164.87], [1660051800000, 164.02, 165.82, 163.25, 164.92], [1660138200000, 167.68, 169.34, 166.9, 169.24], [1660224600000, 170.06, 170.99, 168.19, 168.49], [1660311000000, 169.82, 172.17, 169.4, 172.1], [1660570200000, 171.52, 173.39, 171.35, 173.19], [1660656600000, 172.78, 173.71, 171.66, 173.03], [1660743000000, 172.77, 176.15, 172.57, 174.55], [1660829400000, 173.75, 174.9, 173.12, 174.15], [1660915800000, 173.03, 173.74, 171.31, 171.52], [1661175000000, 169.69, 169.86, 167.14, 167.57], [1661261400000, 167.08, 168.71, 166.65, 167.23], [1661347800000, 167.32, 168.11, 166.25, 167.53], [1661434200000, 168.78, 170.14, 168.35, 170.03], [1661520600000, 170.57, 171.05, 163.56, 163.62], [1661779800000, 161.15, 162.9, 159.82, 161.38], [1661866200000, 162.13, 162.56, 157.72, 158.91], [1661952600000, 160.31, 160.58, 157.14, 157.22], [1662039000000, 156.64, 158.42, 154.67, 157.96], [1662125400000, 159.75, 160.36, 154.97, 155.81], [1662471000000, 156.47, 157.09, 153.69, 154.53], [1662557400000, 154.82, 156.67, 153.61, 155.96], [1662643800000, 154.64, 156.36, 152.68, 154.46], [1662730200000, 155.47, 157.82, 154.75, 157.37], [1662989400000, 159.59, 164.26, 159.3, 163.43], [1663075800000, 159.9, 160.54, 153.37, 153.84], [1663162200000, 154.79, 157.1, 153.61, 155.31], [1663248600000, 154.65, 155.24, 151.38, 152.37], [1663335000000, 151.21, 151.35, 148.37, 150.7], [1663594200000, 149.31, 154.56, 149.1, 154.48], [1663680600000, 153.4, 158.08, 153.08, 156.9], [1663767000000, 157.34, 158.74, 153.6, 153.72], [1663853400000, 152.38, 154.47, 150.91, 152.74], [1663939800000, 151.19, 151.47, 148.56, 150.43], [1664199000000, 149.66, 153.77, 149.64, 150.77], [1664285400000, 152.74, 154.72, 149.95, 151.76], [1664371800000, 147.64, 150.64, 144.84, 149.84], [1664458200000, 146.1, 146.72, 140.68, 142.48]],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },
    {
        id: 54,
        title: "Single series",
        image: "img/charts/aapl-stock-price.png",
        category: "Stock Charts",
        exampleData: [
            [
                1644503400000,
                172.12
            ],
            [
                1644589800000,
                168.64
            ],
            [
                1644849000000,
                168.88
            ],
            [
                1644935400000,
                172.79
            ],
            [
                1645021800000,
                172.55
            ],
            [
                1645108200000,
                168.88
            ],
            [
                1645194600000,
                167.3
            ],
            [
                1645540200000,
                164.32
            ],
            [
                1645626600000,
                160.07
            ],
            [
                1645713000000,
                162.74
            ],
            [
                1645799400000,
                164.85
            ],
            [
                1646058600000,
                165.12
            ],
            [
                1646145000000,
                163.2
            ],
            [
                1646231400000,
                166.56
            ],
            [
                1646317800000,
                166.23
            ],
            [
                1646404200000,
                163.17
            ],
            [
                1646663400000,
                159.3
            ],
            [
                1646749800000,
                157.44
            ],
            [
                1646836200000,
                162.95
            ],
            [
                1646922600000,
                158.52
            ],
            [
                1647009000000,
                154.73
            ],
            [
                1647264600000,
                150.62
            ],
            [
                1647351000000,
                155.09
            ],
            [
                1647437400000,
                159.59
            ],
            [
                1647523800000,
                160.62
            ],
            [
                1647610200000,
                163.98
            ],
            [
                1647869400000,
                165.38
            ],
            [
                1647955800000,
                168.82
            ],
            [
                1648042200000,
                170.21
            ],
            [
                1648128600000,
                174.07
            ],
            [
                1648215000000,
                174.72
            ],
            [
                1648474200000,
                175.6
            ],
            [
                1648560600000,
                178.96
            ],
            [
                1648647000000,
                177.77
            ],
            [
                1648733400000,
                174.61
            ],
            [
                1648819800000,
                174.31
            ],
            [
                1649079000000,
                178.44
            ],
            [
                1649165400000,
                175.06
            ],
            [
                1649251800000,
                171.83
            ],
            [
                1649338200000,
                172.14
            ],
            [
                1649424600000,
                170.09
            ],
            [
                1649683800000,
                165.75
            ],
            [
                1649770200000,
                167.66
            ],
            [
                1649856600000,
                170.4
            ],
            [
                1649943000000,
                165.29
            ],
            [
                1650288600000,
                165.07
            ],
            [
                1650375000000,
                167.4
            ],
            [
                1650461400000,
                167.23
            ],
            [
                1650547800000,
                166.42
            ],
            [
                1650634200000,
                161.79
            ],
            [
                1650893400000,
                162.88
            ],
            [
                1650979800000,
                156.8
            ],
            [
                1651066200000,
                156.57
            ],
            [
                1651152600000,
                163.64
            ],
            [
                1651239000000,
                157.65
            ],
            [
                1651498200000,
                157.96
            ],
            [
                1651584600000,
                159.48
            ],
            [
                1651671000000,
                166.02
            ],
            [
                1651757400000,
                156.77
            ],
            [
                1651843800000,
                157.28
            ],
            [
                1652103000000,
                152.06
            ],
            [
                1652189400000,
                154.51
            ],
            [
                1652275800000,
                146.5
            ],
            [
                1652362200000,
                142.56
            ],
            [
                1652448600000,
                147.11
            ],
            [
                1652707800000,
                145.54
            ],
            [
                1652794200000,
                149.24
            ],
            [
                1652880600000,
                140.82
            ],
            [
                1652967000000,
                137.35
            ],
            [
                1653053400000,
                137.59
            ],
            [
                1653312600000,
                143.11
            ],
            [
                1653399000000,
                140.36
            ],
            [
                1653485400000,
                140.52
            ],
            [
                1653571800000,
                143.78
            ],
            [
                1653658200000,
                149.64
            ],
            [
                1654003800000,
                148.84
            ],
            [
                1654090200000,
                148.71
            ],
            [
                1654176600000,
                151.21
            ],
            [
                1654263000000,
                145.38
            ],
            [
                1654522200000,
                146.14
            ],
            [
                1654608600000,
                148.71
            ],
            [
                1654695000000,
                147.96
            ],
            [
                1654781400000,
                142.64
            ],
            [
                1654867800000,
                137.13
            ],
            [
                1655127000000,
                131.88
            ],
            [
                1655213400000,
                132.76
            ],
            [
                1655299800000,
                135.43
            ],
            [
                1655386200000,
                130.06
            ],
            [
                1655472600000,
                131.56
            ],
            [
                1655818200000,
                135.87
            ],
            [
                1655904600000,
                135.35
            ],
            [
                1655991000000,
                138.27
            ],
            [
                1656077400000,
                141.66
            ],
            [
                1656336600000,
                141.66
            ],
            [
                1656423000000,
                137.44
            ],
            [
                1656509400000,
                139.23
            ],
            [
                1656595800000,
                136.72
            ],
            [
                1656682200000,
                138.93
            ],
            [
                1657027800000,
                141.56
            ],
            [
                1657114200000,
                142.92
            ],
            [
                1657200600000,
                146.35
            ],
            [
                1657287000000,
                147.04
            ],
            [
                1657546200000,
                144.87
            ],
            [
                1657632600000,
                145.86
            ],
            [
                1657719000000,
                145.49
            ],
            [
                1657805400000,
                148.47
            ],
            [
                1657891800000,
                150.17
            ],
            [
                1658151000000,
                147.07
            ],
            [
                1658237400000,
                151
            ],
            [
                1658323800000,
                153.04
            ],
            [
                1658410200000,
                155.35
            ],
            [
                1658496600000,
                154.09
            ],
            [
                1658755800000,
                152.95
            ],
            [
                1658842200000,
                151.6
            ],
            [
                1658928600000,
                156.79
            ],
            [
                1659015000000,
                157.35
            ],
            [
                1659101400000,
                162.51
            ],
            [
                1659360600000,
                161.51
            ],
            [
                1659447000000,
                160.01
            ],
            [
                1659533400000,
                166.13
            ],
            [
                1659619800000,
                165.81
            ],
            [
                1659706200000,
                165.35
            ],
            [
                1659965400000,
                164.87
            ],
            [
                1660051800000,
                164.92
            ],
            [
                1660138200000,
                169.24
            ],
            [
                1660224600000,
                168.49
            ],
            [
                1660311000000,
                172.1
            ],
            [
                1660570200000,
                173.19
            ],
            [
                1660656600000,
                173.03
            ],
            [
                1660743000000,
                174.55
            ],
            [
                1660829400000,
                174.15
            ],
            [
                1660915800000,
                171.52
            ],
            [
                1661175000000,
                167.57
            ],
            [
                1661261400000,
                167.23
            ],
            [
                1661347800000,
                167.53
            ],
            [
                1661434200000,
                170.03
            ],
            [
                1661520600000,
                163.62
            ],
            [
                1661779800000,
                161.38
            ],
            [
                1661866200000,
                158.91
            ],
            [
                1661952600000,
                157.22
            ],
            [
                1662039000000,
                157.96
            ],
            [
                1662125400000,
                155.81
            ],
            [
                1662471000000,
                154.53
            ],
            [
                1662557400000,
                155.96
            ],
            [
                1662643800000,
                154.46
            ],
            [
                1662730200000,
                157.37
            ],
            [
                1662989400000,
                163.43
            ],
            [
                1663075800000,
                153.84
            ],
            [
                1663162200000,
                155.31
            ],
            [
                1663248600000,
                152.37
            ],
            [
                1663335000000,
                150.7
            ],
            [
                1663594200000,
                154.48
            ],
            [
                1663680600000,
                156.9
            ],
            [
                1663767000000,
                153.72
            ],
            [
                1663853400000,
                152.74
            ],
            [
                1663939800000,
                150.43
            ],
            [
                1664199000000,
                150.77
            ],
            [
                1664285400000,
                151.76
            ],
            [
                1664371800000,
                149.84
            ],
            [
                1664458200000,
                142.48
            ],
            [
                1664544600000,
                138.2
            ],
            [
                1664803800000,
                142.45
            ],
            [
                1664890200000,
                146.1
            ],
            [
                1664976600000,
                146.4
            ],
            [
                1665063000000,
                145.43
            ],
            [
                1665149400000,
                140.09
            ],
            [
                1665408600000,
                140.42
            ],
            [
                1665495000000,
                138.98
            ],
            [
                1665581400000,
                138.34
            ],
            [
                1665667800000,
                142.99
            ],
            [
                1665754200000,
                138.38
            ],
            [
                1666013400000,
                142.41
            ],
            [
                1666099800000,
                143.75
            ],
            [
                1666186200000,
                143.86
            ],
            [
                1666272600000,
                143.39
            ],
            [
                1666359000000,
                147.27
            ],
            [
                1666618200000,
                149.45
            ],
            [
                1666704600000,
                152.34
            ],
            [
                1666791000000,
                149.35
            ],
            [
                1666877400000,
                144.8
            ],
            [
                1666963800000,
                155.74
            ],
            [
                1667223000000,
                153.34
            ],
            [
                1667309400000,
                150.65
            ],
            [
                1667395800000,
                145.03
            ],
            [
                1667482200000,
                138.88
            ],
            [
                1667568600000,
                138.38
            ],
            [
                1667831400000,
                138.92
            ],
            [
                1667917800000,
                139.5
            ],
            [
                1668004200000,
                134.87
            ],
            [
                1668090600000,
                146.87
            ],
            [
                1668177000000,
                149.7
            ],
            [
                1668436200000,
                148.28
            ],
            [
                1668522600000,
                150.04
            ],
            [
                1668609000000,
                148.79
            ],
            [
                1668695400000,
                150.72
            ],
            [
                1668781800000,
                151.29
            ],
            [
                1669041000000,
                148.01
            ],
            [
                1669127400000,
                150.18
            ],
            [
                1669213800000,
                151.07
            ],
            [
                1669386600000,
                148.11
            ],
            [
                1669645800000,
                144.22
            ],
            [
                1669732200000,
                141.17
            ],
            [
                1669818600000,
                148.03
            ],
            [
                1669905000000,
                148.31
            ],
            [
                1669991400000,
                147.81
            ],
            [
                1670250600000,
                146.63
            ],
            [
                1670337000000,
                142.91
            ],
            [
                1670423400000,
                140.94
            ],
            [
                1670509800000,
                142.65
            ],
            [
                1670596200000,
                142.16
            ],
            [
                1670855400000,
                144.49
            ],
            [
                1670941800000,
                145.47
            ],
            [
                1671028200000,
                143.21
            ],
            [
                1671114600000,
                136.5
            ],
            [
                1671201000000,
                134.51
            ],
            [
                1671460200000,
                132.37
            ],
            [
                1671546600000,
                132.3
            ],
            [
                1671633000000,
                135.45
            ],
            [
                1671719400000,
                132.23
            ],
            [
                1671805800000,
                131.86
            ],
            [
                1672151400000,
                130.03
            ],
            [
                1672237800000,
                126.04
            ],
            [
                1672324200000,
                129.61
            ],
            [
                1672410600000,
                129.93
            ],
            [
                1672756200000,
                125.07
            ],
            [
                1672842600000,
                126.36
            ],
            [
                1672929000000,
                125.02
            ],
            [
                1673015400000,
                129.62
            ],
            [
                1673274600000,
                130.15
            ],
            [
                1673361000000,
                130.73
            ],
            [
                1673447400000,
                133.49
            ],
            [
                1673533800000,
                133.41
            ],
            [
                1673620200000,
                134.76
            ],
            [
                1673965800000,
                135.94
            ],
            [
                1674052200000,
                135.21
            ],
            [
                1674138600000,
                135.27
            ],
            [
                1674225000000,
                137.87
            ],
            [
                1674484200000,
                141.11
            ],
            [
                1674570600000,
                142.53
            ],
            [
                1674657000000,
                141.86
            ],
            [
                1674743400000,
                143.96
            ],
            [
                1674829800000,
                145.93
            ],
            [
                1675089000000,
                143
            ],
            [
                1675175400000,
                144.29
            ],
            [
                1675261800000,
                145.43
            ],
            [
                1675348200000,
                150.82
            ],
            [
                1675434600000,
                154.5
            ],
            [
                1675693800000,
                151.73
            ],
            [
                1675780200000,
                154.65
            ],
            [
                1675866600000,
                151.92
            ],
            [
                1675953000000,
                150.87
            ],
            [
                1676039400000,
                151.01
            ],
            [
                1676298600000,
                153.85
            ],
            [
                1676385000000,
                153.2
            ],
            [
                1676471400000,
                155.33
            ],
            [
                1676557800000,
                153.71
            ],
            [
                1676644200000,
                152.55
            ],
            [
                1676989800000,
                148.48
            ],
            [
                1677076200000,
                148.91
            ],
            [
                1677162600000,
                149.4
            ],
            [
                1677249000000,
                146.71
            ],
            [
                1677508200000,
                147.92
            ],
            [
                1677594600000,
                147.41
            ],
            [
                1677681000000,
                145.31
            ],
            [
                1677767400000,
                145.91
            ],
            [
                1677853800000,
                151.03
            ],
            [
                1678113000000,
                153.83
            ],
            [
                1678199400000,
                151.6
            ],
            [
                1678285800000,
                152.87
            ],
            [
                1678372200000,
                150.59
            ],
            [
                1678458600000,
                148.5
            ],
            [
                1678714200000,
                150.47
            ],
            [
                1678800600000,
                152.59
            ],
            [
                1678887000000,
                152.99
            ],
            [
                1678973400000,
                155.85
            ],
            [
                1679059800000,
                155
            ],
            [
                1679319000000,
                157.4
            ],
            [
                1679405400000,
                159.28
            ],
            [
                1679491800000,
                157.83
            ],
            [
                1679578200000,
                158.93
            ],
            [
                1679664600000,
                160.25
            ],
            [
                1679923800000,
                158.28
            ],
            [
                1680010200000,
                157.65
            ],
            [
                1680096600000,
                160.77
            ],
            [
                1680183000000,
                162.36
            ],
            [
                1680269400000,
                164.9
            ],
            [
                1680528600000,
                166.17
            ],
            [
                1680615000000,
                165.63
            ],
            [
                1680701400000,
                163.76
            ],
            [
                1680787800000,
                164.66
            ],
            [
                1681133400000,
                162.03
            ],
            [
                1681219800000,
                160.8
            ],
            [
                1681306200000,
                160.1
            ],
            [
                1681392600000,
                165.56
            ],
            [
                1681479000000,
                165.21
            ],
            [
                1681738200000,
                165.23
            ],
            [
                1681824600000,
                166.47
            ],
            [
                1681911000000,
                167.63
            ],
            [
                1681997400000,
                166.65
            ],
            [
                1682083800000,
                165.02
            ],
            [
                1682343000000,
                165.33
            ],
            [
                1682429400000,
                163.77
            ],
            [
                1682515800000,
                163.76
            ],
            [
                1682602200000,
                168.41
            ],
            [
                1682688600000,
                169.68
            ],
            [
                1682947800000,
                169.59
            ],
            [
                1683034200000,
                168.54
            ],
            [
                1683120600000,
                167.45
            ],
            [
                1683207000000,
                165.79
            ],
            [
                1683293400000,
                173.57
            ],
            [
                1683552600000,
                173.5
            ],
            [
                1683639000000,
                171.77
            ],
            [
                1683725400000,
                173.56
            ],
            [
                1683811800000,
                173.75
            ],
            [
                1683898200000,
                172.57
            ],
            [
                1684157400000,
                172.07
            ],
            [
                1684243800000,
                172.07
            ],
            [
                1684330200000,
                172.69
            ],
            [
                1684416600000,
                175.05
            ],
            [
                1684503000000,
                175.16
            ],
            [
                1684762200000,
                174.2
            ],
            [
                1684848600000,
                171.56
            ],
            [
                1684935000000,
                171.84
            ],
            [
                1685021400000,
                172.99
            ],
            [
                1685107800000,
                175.43
            ],
            [
                1685453400000,
                177.3
            ],
            [
                1685539800000,
                177.25
            ],
            [
                1685626200000,
                180.09
            ],
            [
                1685712600000,
                180.95
            ],
            [
                1685971800000,
                179.58
            ],
            [
                1686058200000,
                179.21
            ],
            [
                1686144600000,
                177.82
            ],
            [
                1686231000000,
                180.57
            ],
            [
                1686317400000,
                180.96
            ],
            [
                1686576600000,
                183.79
            ],
            [
                1686663000000,
                183.31
            ],
            [
                1686749400000,
                183.95
            ],
            [
                1686835800000,
                186.01
            ],
            [
                1686922200000,
                184.92
            ],
            [
                1687267800000,
                185.01
            ],
            [
                1687354200000,
                183.96
            ],
            [
                1687440600000,
                187
            ],
            [
                1687527000000,
                186.68
            ],
            [
                1687786200000,
                185.27
            ],
            [
                1687872600000,
                188.06
            ],
            [
                1687959000000,
                189.25
            ],
            [
                1688045400000,
                189.59
            ],
            [
                1688131800000,
                193.97
            ],
            [
                1688391000000,
                192.46
            ],
            [
                1688563800000,
                191.33
            ],
            [
                1688650200000,
                191.81
            ],
            [
                1688736600000,
                190.68
            ],
            [
                1688995800000,
                188.61
            ],
            [
                1689082200000,
                188.08
            ],
            [
                1689168600000,
                189.77
            ],
            [
                1689255000000,
                190.54
            ],
            [
                1689341400000,
                190.69
            ],
            [
                1689600600000,
                193.99
            ],
            [
                1689687000000,
                193.73
            ],
            [
                1689773400000,
                195.1
            ],
            [
                1689859800000,
                193.13
            ],
            [
                1689946200000,
                191.94
            ],
            [
                1690205400000,
                192.75
            ],
            [
                1690291800000,
                193.62
            ],
            [
                1690378200000,
                194.5
            ],
            [
                1690464600000,
                193.22
            ],
            [
                1690551000000,
                195.83
            ],
            [
                1690810200000,
                196.45
            ],
            [
                1690896600000,
                195.61
            ],
            [
                1690983000000,
                192.58
            ],
            [
                1691069400000,
                191.17
            ],
            [
                1691155800000,
                181.99
            ],
            [
                1691415000000,
                178.85
            ],
            [
                1691501400000,
                179.8
            ],
            [
                1691587800000,
                178.19
            ],
            [
                1691674200000,
                177.97
            ],
            [
                1691760600000,
                177.79
            ],
            [
                1692019800000,
                179.46
            ],
            [
                1692106200000,
                177.45
            ],
            [
                1692192600000,
                176.57
            ],
            [
                1692279000000,
                174
            ],
            [
                1692365400000,
                174.49
            ],
            [
                1692624600000,
                175.84
            ],
            [
                1692711000000,
                177.23
            ],
            [
                1692797400000,
                181.12
            ],
            [
                1692883800000,
                176.38
            ],
            [
                1692970200000,
                178.61
            ],
            [
                1693229400000,
                180.19
            ],
            [
                1693315800000,
                184.12
            ],
            [
                1693402200000,
                187.65
            ],
            [
                1693488600000,
                187.87
            ],
            [
                1693575000000,
                189.46
            ],
            [
                1693920600000,
                189.7
            ],
            [
                1694007000000,
                182.91
            ],
            [
                1694093400000,
                177.56
            ],
            [
                1694179800000,
                178.18
            ],
            [
                1694439000000,
                179.36
            ],
            [
                1694525400000,
                176.3
            ],
            [
                1694611800000,
                174.21
            ],
            [
                1694698200000,
                175.74
            ],
            [
                1694784600000,
                175.01
            ],
            [
                1695043800000,
                177.97
            ],
            [
                1695130200000,
                179.07
            ],
            [
                1695216600000,
                175.49
            ],
            [
                1695303000000,
                173.93
            ],
            [
                1695389400000,
                174.79
            ],
            [
                1695648600000,
                176.08
            ],
            [
                1695735000000,
                171.96
            ],
            [
                1695821400000,
                170.43
            ],
            [
                1695907800000,
                170.69
            ],
            [
                1695994200000,
                171.21
            ],
            [
                1696253400000,
                173.75
            ],
            [
                1696339800000,
                172.4
            ],
            [
                1696426200000,
                173.66
            ],
            [
                1696512600000,
                174.91
            ],
            [
                1696599000000,
                177.49
            ],
            [
                1696858200000,
                178.99
            ],
            [
                1696944600000,
                178.39
            ],
            [
                1697031000000,
                179.8
            ],
            [
                1697117400000,
                180.71
            ],
            [
                1697203800000,
                178.85
            ],
            [
                1697463000000,
                178.72
            ],
            [
                1697549400000,
                177.15
            ],
            [
                1697635800000,
                175.84
            ],
            [
                1697722200000,
                175.46
            ],
            [
                1697808600000,
                172.88
            ],
            [
                1698067800000,
                173
            ],
            [
                1698154200000,
                173.44
            ],
            [
                1698240600000,
                171.1
            ],
            [
                1698327000000,
                166.89
            ],
            [
                1698413400000,
                168.22
            ],
            [
                1698672600000,
                170.29
            ],
            [
                1698759000000,
                170.77
            ],
            [
                1698845400000,
                173.97
            ],
            [
                1698931800000,
                177.57
            ],
            [
                1699018200000,
                176.65
            ],
            [
                1699281000000,
                179.23
            ],
            [
                1699367400000,
                181.82
            ],
            [
                1699453800000,
                182.89
            ],
            [
                1699540200000,
                182.41
            ],
            [
                1699626600000,
                186.4
            ],
            [
                1699885800000,
                184.8
            ],
            [
                1699972200000,
                187.44
            ],
            [
                1700058600000,
                188.01
            ],
            [
                1700145000000,
                189.71
            ],
            [
                1700231400000,
                189.69
            ],
            [
                1700490600000,
                191.45
            ],
            [
                1700577000000,
                190.64
            ],
            [
                1700663400000,
                191.31
            ],
            [
                1700836200000,
                189.97
            ],
            [
                1701095400000,
                189.79
            ],
            [
                1701181800000,
                190.4
            ],
            [
                1701268200000,
                189.37
            ],
            [
                1701354600000,
                189.95
            ],
            [
                1701441000000,
                191.24
            ],
            [
                1701700200000,
                189.43
            ],
            [
                1701786600000,
                193.42
            ],
            [
                1701873000000,
                192.32
            ],
            [
                1701959400000,
                194.27
            ],
            [
                1702045800000,
                195.71
            ],
            [
                1702305000000,
                193.18
            ],
            [
                1702391400000,
                194.71
            ],
            [
                1702477800000,
                197.96
            ],
            [
                1702564200000,
                198.11
            ],
            [
                1702650600000,
                197.57
            ],
            [
                1702909800000,
                195.89
            ],
            [
                1702996200000,
                196.94
            ],
            [
                1703082600000,
                194.83
            ],
            [
                1703169000000,
                194.68
            ],
            [
                1703255400000,
                193.6
            ],
            [
                1703601000000,
                193.05
            ],
            [
                1703687400000,
                193.15
            ],
            [
                1703773800000,
                193.58
            ],
            [
                1703860200000,
                192.53
            ],
            [
                1704205800000,
                185.64
            ],
            [
                1704292200000,
                184.25
            ],
            [
                1704378600000,
                181.91
            ],
            [
                1704465000000,
                181.18
            ],
            [
                1704724200000,
                185.56
            ],
            [
                1704810600000,
                185.14
            ],
            [
                1704897000000,
                186.19
            ],
            [
                1704983400000,
                185.59
            ],
            [
                1705069800000,
                185.92
            ],
            [
                1705415400000,
                183.63
            ],
            [
                1705501800000,
                182.68
            ],
            [
                1705588200000,
                188.63
            ],
            [
                1705674600000,
                191.56
            ],
            [
                1705933800000,
                193.89
            ],
            [
                1706020200000,
                195.18
            ],
            [
                1706106600000,
                194.5
            ],
            [
                1706193000000,
                194.17
            ],
            [
                1706279400000,
                192.42
            ],
            [
                1706538600000,
                191.73
            ],
            [
                1706625000000,
                188.04
            ],
            [
                1706711400000,
                184.4
            ],
            [
                1706797800000,
                186.86
            ],
            [
                1706884200000,
                185.85
            ],
            [
                1707143400000,
                187.68
            ],
            [
                1707229800000,
                189.3
            ],
            [
                1707316200000,
                189.41
            ],
            [
                1707402600000,
                188.32
            ],
            [
                1707489000000,
                188.85
            ]
        ],
        chartAttribute: {
            title: {
                text: 'Logarithmic axis demoe',
                align: 'left'
            },
            subtitle: {
                text: 'According to the Standard Atmosphere Model',
                align: 'left'
            },
            yAxistext: 'logarithmic',
            xAxistext: 'Altitude',

        }
    },

]
export default ALLCharts