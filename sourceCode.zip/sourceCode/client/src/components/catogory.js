const Category = [
    {
        id:1,
        title: "Line Charts",
        image: "img/charts/lineChart.png"
    },
    {
        id:2,
        title: "Area Charts",
        image: "img/charts/areaCharts.png"
    },
    {
        id:3,
        title: "Bar Charts",
        image: "img/charts/barCharts.png"
    },
    {
        id:4,
        title: "Pie Charts",
        image: "img/charts/pieCharts.png"
    },
    {
        id:5,
        title: "Scatter Charts",
        image: "img/charts/scatterCharts.png"
    },
    {
        id:6,
        title: "3D Charts",
        image: "img/charts/3dCharts.png"
    },
    {
        id:7,
        title: "Heat Maps",
        image: "img/charts/heatMapsChart.png"
    },
    {
        id:8,
        title: "Stock Charts",
        image: "img/charts/stockCharts.png"
    }
    //,
    // {
    //     id:9,
    //     title: "More Charts",
    //     image: "img/charts/guagesCharts.png"
    // }




]
export default Category