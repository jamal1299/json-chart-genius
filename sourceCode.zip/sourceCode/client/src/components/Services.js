import React, { useRef, useState} from "react";
import Category from "./catogory";
import Charts from "./charts";

function Services() {
    const [selectedItem, setSelectedItem] = useState(null);
    const [categoryData, setCategoryData] = useState(Category);
    const BacktoCategory = useRef(null);
    const scrollToBox = useRef(null);

    const displayChart = (item) => {
        setSelectedItem(item);
        setCategoryData(null);
        if(BacktoCategory.current) {
            BacktoCategory.current.style.display = "block";
        }
        scrollToBox.current.scrollIntoView({ behavior: 'smooth' });
    };

    const displayCategory = () => {
        setSelectedItem(null);
        setCategoryData(Category);
        if (BacktoCategory.current) {
            BacktoCategory.current.style.display = "none";
        }
    };

    return (
        <>
       
            <div className="container-xxl py-1">
                <div className="container py-5 px-lg-5">
                    <div className="wow fadeInUp" data-wow-delay="0.1s">
                        <p className="section-title text-secondary justify-content-center" ref={scrollToBox}><span></span> Services<span></span></p>
                        <h1 className="text-center mb-5" >Provided Solution</h1>
                        <p className="btn btn-primary py-sm-3 px-sm-5 rounded-pill mt-0 backToCategory" onClick={displayCategory} ref={BacktoCategory}><i className="bi bi-arrow-left leftIcon"></i>Back To Category</p>
                    </div>
                    <div className="row g-4">
                        {categoryData && categoryData.map((item) => (
                            <div key={item.id} className="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s" onClick={() => displayChart(item)}>
                                <div className="service-item d-flex flex-column text-center rounded">
                                    <div className="mb-4">
                                        <img src={item.image} alt="" width="100%" />
                                    </div>
                                    <h5>{item.title}</h5>
                                </div>
                            </div>
                        ))}
                        {selectedItem && (
                            <Charts
                                title={selectedItem.title}
                            />
                            
                        )}
                    </div>

                </div>
            </div>
        </>
    );
}

export default Services;
