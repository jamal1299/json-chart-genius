import React from "react";

function Hero()
{
    return(
        <>
           <div class="container-xxl bg-primary hero-header">
                <div class="container px-lg-5">
                    <div class="row g-5 align-items-end">
                        <div class="col-lg-6 text-center text-lg-start">
                            <h1 class="text-white mb-4 animated slideInDown">Welcome To JSON Chart Genius</h1>
                            <p class="text-white pb-3 animated slideInDown">Our mission is to simplify chart creation from JSON data, making it accessible to users of all backgrounds. Join us on this journey to transform raw data into visually compelling insights. Your journey into the world of dynamic visualization begins here, where information meets inspiration.
                                
                            </p>
                            <a href="/#" class="btn btn-secondary py-sm-3 px-sm-5 rounded-pill me-3 animated slideInLeft">Read More</a>
                            <a href="/#" class="btn btn-light py-sm-3 px-sm-5 rounded-pill animated slideInRight">Contact Us</a>
                        </div>
                        <div class="col-lg-6 text-center text-lg-start">
                            <img class="img-fluid animated zoomIn" src="img/hero.png" alt="" />
                        </div>
                    </div>
                </div>
            </div></>
    );
}
export default Hero;