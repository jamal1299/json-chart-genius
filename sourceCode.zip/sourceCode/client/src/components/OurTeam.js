import React from "react";
function OurTeam(){
    return(
        <>
         <div class="container-xxl py-1">
            <div class="container py-1 px-lg-5">
                <div class="wow fadeInUp" data-wow-delay="0.1s">
                    <p class="section-title text-secondary justify-content-center"><span></span>Our Team<span></span></p>
                    <h1 class="text-center mb-5">Our Team Members</h1>
                </div>
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item bg-light rounded">
                            <div class="text-center border-bottom p-4">
                                <img class="img-fluid rounded-circle mb-4" src="img/noreen.png" alt="" />
                                <h5>Noreen Khan</h5>
                                <span>Project Manager</span>
                            </div>
                            <div class="d-flex justify-content-center p-4">
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item bg-light rounded">
                            <div class="text-center border-bottom p-4">
                                <img class="img-fluid rounded-circle mb-4" src="img/jamal.png" alt="" />
                                <h5>Jamal Mehmood</h5>
                                <span>Web Devloper</span>
                            </div>
                            <div class="d-flex justify-content-center p-4">
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item bg-light rounded">
                            <div class="text-center border-bottom p-4">
                                <img class="img-fluid rounded-circle mb-4" src="img/jamal.png" alt="" />
                                <h5>Jawad Wakeel</h5>
                                <span>Web Devloper</span>
                            </div>
                            <div class="d-flex justify-content-center p-4">
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-square mx-1"  href="/#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        </>
    );
}
export default OurTeam;