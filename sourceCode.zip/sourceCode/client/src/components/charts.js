import React, { useState,useEffect } from "react";
import ALLCharts from "./items";
import RenderChart from "./renderChart";
function Charts(props) {
    const items = ALLCharts.filter((item) => item.category === props.title);
    const [selectedItem, setSelectedItem] = useState(null);
    const [chartsData, setChartData] = useState(items);


    const renderChart = (item) => {
        setSelectedItem(item);
        setChartData(null);
    }



    return (
        <>
            {items.map((item) => {

                return (
                    <>
                        {chartsData && <div class="col-lg-4 col-md-6 wow fadeInUp" onClick={() => renderChart(item)} data-wow-delay="0.1s" key={item.id} >
                            <div class="service-item d-flex flex-column text-center rounded">
                                <div class="mb-4">
                                    <img src={item.image} alt="" width="100%" />
                                </div>
                                <h5 >{item.title}</h5>

                            </div>
                        </div>
                        }

                    </>
                )



            })}

            {
                selectedItem &&
                <RenderChart
                    ChartName={selectedItem.title}
                    ChartImage={selectedItem.image}
                    exampleData={selectedItem.exampleData}
                    title={selectedItem.chartAttribute && selectedItem.chartAttribute.title && selectedItem.chartAttribute.title.text ? selectedItem.chartAttribute.title.text : ''}
                    titleAlignment = {selectedItem.chartAttribute && selectedItem.chartAttribute.title && selectedItem.chartAttribute.title.align ? selectedItem.chartAttribute.title.align : ''}
                    subTitle={selectedItem.chartAttribute && selectedItem.chartAttribute.subtitle && selectedItem.chartAttribute.subtitle.text ? selectedItem.chartAttribute.subtitle.text : ''}
                    subTitleAlignment = {selectedItem.chartAttribute && selectedItem.chartAttribute.subtitle && selectedItem.chartAttribute.subtitle.align ? selectedItem.chartAttribute.subtitle.align : ''}
                    yAxistext= {selectedItem.chartAttribute && selectedItem.chartAttribute.yAxistext ? selectedItem.chartAttribute.yAxistext : ''}
                    xAxistext= {selectedItem.chartAttribute && selectedItem.chartAttribute.xAxistext ? selectedItem.chartAttribute.xAxistext : ''}
                    category={selectedItem.category}
                    treeMap= {selectedItem.treeMap ? selectedItem.treeMap : 'Not'}
                 



                />

            }




        </>
    );
}
export default Charts;