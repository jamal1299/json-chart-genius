const SnippetsPy = {
    "Line Charts": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.global_options.shared_options import SharedOptions
# Create the chart
my_chart = Chart(
            container="chart_container",  
            options={
                "chart": {
                    "type": "line"
                }, 
                "title": {
                        "text": '${title}',
                        "align": '${titleAlignment}'
                },
                "subtitle": {
                        "text": '${subTitle}',
                        "align": '${subTitleAlignment}'
                },
                
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "xAxis": {
                    "title": {"text": "${xAxistext}"}
                },
                "legend": {
                    "layout": "vertical",
                    "align": "right",
                    "verticalAlign": "middle",
                },
                "plotOptions": {
                    "series": {
                        "label": {"connectorAllowed": False},
                        "marker": {"enabled": False},  
                    }
                },
                "series":${stringifyUploadedData},
                "responsive": {
                    "rules": [
                        {
                            "condition": {"maxWidth": 500},
                            "chartOptions": {
                                "legend": {
                                    "layout": "horizontal",
                                    "align": "center",
                                    "verticalAlign": "bottom",
                                }
                            },
                        }
                    ]
                },
            },
        )
# Display the chart in your Jupyter Notebook
my_chart.display()
            
        `
        return PyScript;
    },
    "Spline with symbols": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
        
# Create the chart
my_chart = Chart(
            container="chart_container",  
            options={
                "chart": {"type": "spline"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {
                    "text": "${subTitle}","align":"${subTitleAlignment}"
                },
                "xAxis": {
                    "title": {"text": "${xAxistext}"},
                },
                "yAxis": {
                    "title": {"text": "${yAxistext}"},
                },
                "tooltip": {"crosshairs": True, "shared": True},
                "plotOptions": {
                    "spline": {
                        "marker": {
                            "radius": 4,
                            "lineColor": "#666666",
                            "lineWidth": 1,
                        }
                    }
                },
                "series":${stringifyUploadedData},
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Inverted axes": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
 
# Create the chart
my_chart = Chart(
            container="chart_container",   
            options={
                "chart": {"type": "spline", "inverted": True},
                "title": {"text": "${title}", "align": "${titleAlignment}"},
                "subtitle": {"text": "${subTitle}", "align": "${subTitleAlignment}"},
                "xAxis": {
                    "reversed": False,
                    "title": {"enabled": True, "text": "${xAxistext}"},
                    "maxPadding": 0.05,
                    "showLastLabel": True,
                },
                "yAxis": {
                    "title": {"text": "${yAxistext}"},
                    "lineWidth": 2,
                },
                "legend": {"enabled": False},
                "tooltip": {
                    "headerFormat": "<b>{series.name}</b><br/>",
                    "pointFormat": "{point.x} km: {point.y}°C",
                },
                "plotOptions": {"spline": {"marker": {"enable": False}}},
                "series": ${stringifyUploadedData},
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "With data labels": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import LineSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
 my_chart = Chart(
            container="chart_container",   
            options={
                "chart": {"type": "line"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {
                    "text": "${subTitle}","align":"${subTitleAlignment}"
                },
                "xAxis": {"title": {"text": "${xAxistext}"}},
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "plotOptions": {
                    "line": {
                        "dataLabels": {"enabled": True},
                        "enableMouseTracking": False,  # Disable mouse tracking for data points
                    }
                },
                "series": ${stringifyUploadedData},
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()        
        
        `
        return PyScript;
    },
    "Logarithmic axis": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import LineSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
my_chart = Chart(
            container="chart_container",   
            options={
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {
                    "text": "${subTitle}","align":"${subTitleAlignment}"
                },
                "xAxis": {
                    "tickInterval": 1,
                    "type": "logarithmic",
                    "title": {"text": "${xAxistext}"}
                },
                "yAxis": {
                    "type": "logarithmic",
                    "minorTickInterval": 0.1,
                    "title": {"text": "${yAxistext}"}
                },
                "tooltip": {
                    "headerFormat": "<b>{series.name}</b><br>",
                    "pointFormat": "x = {point.x}, y = {point.y}",
                },
                "series": ${stringifyUploadedData},
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "irregular intervals": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "spline"},
                "title": {"text": "${title}",align:${titleAlignment}},
                "subtitle": {"text": "${subTitle},align:${subTitleAlignment}"},
                "xAxis": {
                    "title": {"text": "${xAxistext}"},
                },
                "yAxis": {
                    "title": {"text": "${yAxistext}"},
                    "min": 0,
                },
                "tooltip": {
                    "headerFormat": "<b>{series.name}</b><br>",
                    "pointFormat": "{point.x:%e. %b}: {point.y:.2f} m",
                },
                "plotOptions": {
                    "series": {
                        "marker": {
                            "symbol": "circle",
                            "fillColor": "#FFFFFF",
                            "enabled": True,
                            "radius": 2.5,
                            "lineWidth": 1,
                            "lineColor": None,
                        }
                    }
                },
                "colors": ["#6CF", "#39F", "#06C", "#036", "#000"],
                "series": ${stringifyUploadedData},
                    },
               
        )
        
# Display the chart
my_chart.display()        
        
        `
        return PyScript;
    },
    "Plot bands": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import LineSeries
from highcharts_core.global_options.shared_options import SharedOptions
from datetime import datetime


# Create the chart
my_chart = Chart(
    container="container",   
    options={
        "chart": {
            "type": "spline",
            "scrollablePlotArea": {
                "minWidth": 600,
                "scrollPositionX": 1
            }
        },
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": {
            "type": "datetime",
            "labels": {"overflow": "justify"},
            "title": {"text": "${xAxistext}"}
        },
        "yAxis": {
            "title": {"text": "${yAxistext}"},
            "minorGridLineWidth": 0,
            "gridLineWidth": 0,
            "alternateGridColor": None,
            "plotBands": [
                {"from": 0.3, "to": 1.5, "color": "rgba(68, 170, 213, 0.1)", "label": {"text": "Light air", "style": {"color": "#606060"}}},
                {"from": 1.5, "to": 3.3, "color": "rgba(0, 0, 0, 0)", "label": {"text": "Light breeze", "style": {"color": "#606060"}}},
                {"from": 3.3, "to": 5.5, "color": "rgba(68, 170, 213, 0.1)", "label": {"text": "Gentle breeze", "style": {"color": "#606060"}}},
                {"from": 5.5, "to": 8, "color": "rgba(0, 0, 0, 0)", "label": {"text": "Moderate breeze", "style": {"color": "#606060"}}},
                {"from": 8, "to": 11, "color": "rgba(68, 170, 213, 0.1)", "label": {"text": "Fresh breeze", "style": {"color": "#606060"}}},
                {"from": 11, "to": 14, "color": "rgba(0, 0, 0, 0)", "label": {"text": "Strong breeze", "style": {"color": "#606060"}}},
                {"from": 14, "to": 17, "color": "rgba(68, 170, 213, 0.1)", "label": {"text": "Near gale", "style": {"color": "#606060"}}},
                {"from": 17, "to": 20.5, "color": "rgba(0, 0, 0, 0)", "label": {"text": "Fresh gale", "style": {"color": "#606060"}}},
                {"from": 20.5, "to": 24, "color": "rgba(68, 170, 213, 0.1)", "label": {"text": "Strong gale", "style": {"color": "#606060"}}},
            ]
        },
        "tooltip": {"valueSuffix": " m/s"},
        "plotOptions": {
            "spline": {
                "lineWidth": 4,
                "states": {"hover": {"lineWidth": 5}},
                "marker": {"enabled": False},
                "pointInterval": 3600000,  # one hour
                "pointStart": datetime(2020, 4, 15, 0, 0, 0).timestamp() * 1000
            }
        },
        "series": ${stringifyUploadedData},
        "navigation": {"menuItemStyle": {"fontSize": "10px"}}
    },
)

# Display the chart in your Jupyter Notebook
my_chart.display()

        `
        return PyScript;
    },
    "Basic area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
from datetime import datetime
   
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": {
                    "allowDecimals": False,
                    "title": {"text": "${xAxistext}"},
                },
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "tooltip": {"pointFormat": "{series.name} had stockpiled <b>{point.y:,.0f}</b><br/>warheads in {point.x}"},
                "plotOptions": {
                    "area": {
                        "pointStart": 1940,
                        "marker": {
                            "enabled": False,
                            "symbol": "circle",
                            "radius": 2,
                            "states": {"hover": {"enabled": True}}
                        }
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Stacked area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": {
                    "title": {"text": "${xAxistext}"},
                },
                "yAxis": {
                    "title": {"text": "${yAxistext}"},
                },
                "tooltip": {
                    "shared": True,
                    "headerFormat": '<span style="font-size:12px"><b>{point.key}</b></span><br>'
                },
                "plotOptions": {
                    "series": {"pointStart": 2012},
                    "area": {
                        "stacking": "normal",
                        "lineColor": "#666666",
                        "lineWidth": 1,
                        "marker": {"lineWidth": 1, "lineColor": "#666666"}
                    }
                },
                "series":${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Percentage area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
        
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "accessibility": {
                    "point": {
                        "valueDescriptionFormat": '{index}. {point.category}, {point.y:,.1f} billions, {point.percentage:.1f}%.'
                    }
                },
                "xAxis":{"title": {"text": "${xAxistext}"}},
                "yAxis": {
                    "labels": {"format": "{value}%"},
                    "title": {"text": "${yAxistext}"}
                },
                "tooltip": {
                    "pointFormat": '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.1f} billion Gt)<br/>',
                    "split": True
                },
                "plotOptions": {
                    "series": {"pointStart": 1990},
                    "area": {
                        "stacking": "percent",
                        "marker": {"enabled": False}
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Area-spline": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "legend": {
                    "layout": "vertical",
                    "align": "left",
                    "verticalAlign": "top",
                    "x": 150,
                    "y": 60,
                    "floating": True,
                    "borderWidth": 1,
                    "backgroundColor": "#FFFFFF"
                },
                "xAxis": {"title": {"text": "${xAxistext}"}},
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "plotOptions": {
                    "series": {"pointStart": 2014},
                    "area": {"fillOpacity": 0.5}
                },
                "credits": {"enabled": False},
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        
        `
        return PyScript;
    },
    "Missing points": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": {"title": {"text": "${xAxistext}"}},
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "credits": {"enabled": False},
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()        
        `
        return PyScript;
    },
    "With negative values Area Chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.area import AreaSeries
from highcharts_core.global_options.shared_options import SharedOptions
from datetime import datetime
   
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "area"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": {
                    "allowDecimals": False,
                    "title": {"text": "${xAxistext}"},
                },
                "yAxis": {"title": {"text": "${yAxistext}"}},
                "tooltip": {"pointFormat": "{series.name} had stockpiled <b>{point.y:,.0f}</b><br/>warheads in {point.x}"},
                "plotOptions": {
                    "area": {
                        "pointStart": 1940,
                        "marker": {
                            "enabled": False,
                            "symbol": "circle",
                            "radius": 2,
                            "states": {"hover": {"enabled": True}}
                        }
                    }
                },
                "credits": {
                    "enabled": False,
                },
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Basic bar": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.bar import BarSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
my_chart = Chart(
            container="container",   
            options={
                "chart": {"type": "bar"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"}, "gridLineWidth": 1, "lineWidth": 0},
                "yAxis": {"min": 0, "title": {"text": "${yAxistext}", "align": "high"}, "labels": {"overflow": "justify"}, "gridLineWidth": 0},
                "tooltip": {"valueSuffix": " millions"},
                "plotOptions": {"bar": {"borderRadius": 5, "dataLabels": {"enabled": True}, "groupPadding": 0.1}},
                "legend": {"layout": "vertical", "align": "right", "verticalAlign": "top", "x": -40, "y": 80, "floating": True, "borderWidth": 1, "backgroundColor": "#FFFFFF", "shadow": True},
                "credits": {"enabled": False},
                "series":${stringifyUploadedData}
            },
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Basic column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
# Create the chart
my_chart = Chart(
        container="container",  
        options={
        "chart": {"type": "column"}, 
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"}, "gridLineWidth": 1, "lineWidth": 0},
        "yAxis": { "title": {"text": "${yAxistext}"}, "gridLineWidth": 1, "lineWidth": 0},
        "plotOptions": {"column": {"pointPadding": 0.2, "borderWidth": 0}}, 
        "series": ${stringifyUploadedData}
        }
        )
# Display the chart in your Jupyter Notebook
my_chart.display()
        `
        return PyScript;
    },
    "Stacked and grouped": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
# Create the chart
my_chart = Chart(
        container="container", 
        options={
        "chart": {"type": "column"}, 
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"}, 
        "xAxis": { "title": {"text": "${xAxistext}"}, "gridLineWidth": 1, "lineWidth": 0}, 
        "yAxis": {"allowDecimals": False, "min": 0, "title": {"text": "${yAxistext}"}}, 
        "tooltip": {"format": '<b>{key}</b><br/>{series.name}: {y}<br/>Total: {point.stackTotal}'}, 
        "plotOptions": {"column": {"stacking": 'normal'}}, 
        "series": ${stringifyUploadedData}
        }
        )
# Display the chart in your Jupyter Notebook
my_chart.display()
        `
        return PyScript;
    },
    "Column range": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const convertDataFormat = (data) => {
            return data.map((series) => {
                // Check if data is already in the desired format
                if (Array.isArray(series.data[0]) && series.data[0].length === 2 && series.data[0][0] < 0 && series.data[0][1] > 0) {
                    // If data is already in the desired format, return it unchanged
                    return series;
                } else {
                    // Convert data to the desired format
                    return {
                        data: Array.isArray(series.data) ? series.data.map((value) => [-value, value === null ? 0 : value]) : [[-series.data, series.data === null ? 0 : series.data]],
                        name: series.name
                    };
                }
            });
        };
    
        // Convert the data format
        let uploadedData = convertDataFormat(userData);
    
        // Stringify the converted data
        let stringifyUploadedData = JSON.stringify(uploadedData);
            
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
# Create the chart
my_chart = Chart(
                container="container",  
                options={
                    "chart": {"type": "columnrange", "inverted": True},
                    "title": {"text": "${title}","align":"${titleAlignment}"},
                    "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"}, 
                    "xAxis": { "title": {"text": "${xAxistext}"}, "gridLineWidth": 1, "lineWidth": 0}, 
                    "yAxis": { "title": {"text": "${yAxistext}"}, "gridLineWidth": 1, "lineWidth": 0}, 
                    "tooltip": {"valueSuffix": "°C"},
                    "plotOptions": {
                        "columnrange": {
                            "dataLabels": {
                                "enabled": True,
                                "format": "{y}°C"
                            }
                        }
                    },
                    "legend": {"enabled": False},
                    "series": ${stringifyUploadedData},
                }
            )
            
# Display the chart in your Jupyter Notebook
my_chart.display()
            `;
        return PyScript;
    },
    "Variwide": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        // uploadedData.forEach(series => {
        //     series.data = series.data.map(value => value === null ? 0 : value);
        // });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
# Create the chart
my_chart = Chart(
        container="container",  
        options={
        "chart": {"type": 'variwide'}, 
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"} },
        "yAxis": { "title": {"text": "${yAxistext}"}},
        "legend": {"enabled": False}, 
        "series": ${stringifyUploadedData}
        }
        )
# Display the chart in your Jupyter Notebook
my_chart.display()
        `
        return PyScript;
    },
    "With negative values Bar Chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
# Create the chart
my_chart = Chart(
            container="container",  
            options={
                "chart": {"type": "column"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"}, 
                "xAxis": { "title": {"text": "${xAxistext}"} }, 
                "yAxis": { "title": {"text": "${yAxistext}"} }, 
                "credits": {"enabled": False},
                "plotOptions": {
                    "column": {
                        "borderRadius": "25"
                    }
                },
                "series": ${stringifyUploadedData}
            }
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "Stacked column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
        
        # Create the chart
        my_chart = Chart(
            container="container",  
            options={
                "chart": {"type": "column"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} }, 
                "yAxis": {
                    "min": 0,
                    "title": {"text": "Count trophies"},
                    "stackLabels": {"enabled": True},
                    { "title": {"text": "${yAxistext}"}
                },
                "legend": {
                    "align": "left",
                    "x": 70,
                    "verticalAlign": "top",
                    "y": 70,
                    "floating": True,
                    "backgroundColor": "#FFFFFF",
                    "borderColor": "#CCC",
                    "borderWidth": 1,
                    "shadow": False
                },
                "plotOptions": {
                    "column": {
                        "stacking": "normal",
                        "dataLabels": {"enabled": True}
                    }
                },
                "series": ${stringifyUploadedData}
            }
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        
        `
        return PyScript;
    },
    "Pie chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        uploadedData.forEach(item => {
            item.y = item.y === null ? 0 : item.y;
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
pie_chart = Chart(
        container="container", options={
        "chart": {"type": "pie"}, 
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"} },
        "yAxis": { "title": {"text": "${yAxistext}"} },
        "plotOptions": {
        "series": {
        "allowPointSelect": True,
        "cursor": 'pointer', "dataLabels": [
        {"enabled": True, "distance": 20}, {
        "enabled": True, "distance": -40, "format": '{point.percentage:.1f}%', "style": {
        "fontSize": '1.2em', "textOutline": 'none', "opacity": 0.7
        },"filter": {"operator": '>', "property": 'percentage', "value": 10}
        }
        ]
        }
        },
        "series": [{data: ${stringifyUploadedData} ]}
        }
        )
# Display the chart in your Jupyter Notebook
pie_chart.display()
        `
        return PyScript;
    },
    "custom entrance animation": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        uploadedData.forEach(item => {
            item.y = item.y === null ? 0 : item.y;
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.pie import PieSeries
from highcharts_core.global_options.shared_options import SharedOptions

# Create the chart
my_chart = Chart(
            container="container",  # Replace with the ID of your HTML element
            options={
                "chart": {"type": "pie"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"} },
        "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "pie": {
                        "allowPointSelect": True,
                        "borderWidth": 2,
                        "cursor": "pointer",
                        "dataLabels": {
                            "enabled": True,
                            "format": "<b>{point.name}</b><br>{point.percentage}%",
                            "distance": 20
                        }
                    }
                },
                "series": [{
                    "data": ${stringifyUploadedData}
                }]
            }
        )
        
# Display the chart in your Jupyter Notebook
my_chart.display()
        
        `
        return PyScript;
    },
    "With monochrome fill": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        uploadedData.forEach(item => {
            item.y = item.y === null ? 0 : item.y;
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.spline import SplineSeries
from highcharts_core.global_options.shared_options import SharedOptions
pie_chart = Chart(
        container="container", options={
        "chart": {"type": "pie"}, 
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"} },
        "yAxis": { "title": {"text": "${yAxistext}"} },
        "plotOptions": {
        "series": {
        "allowPointSelect": True,
        "cursor": 'pointer', "dataLabels": [
        {"enabled": True, "distance": 20}, {
        "enabled": True, "distance": -40, "format": '{point.percentage:.1f}%', "style": {
        "fontSize": '1.2em', "textOutline": 'none', "opacity": 0.7
        },"filter": {"operator": '>', "property": 'percentage', "value": 10}
        }
        ]
        }
        },
        "series": ${stringifyUploadedData}
        }
        )
# Display the chart in your Jupyter Notebook
pie_chart.display()
        `
        return PyScript;
    },
    "Semi circle donut": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(item => {
            item.y = item.y === null ? 0 : item.y;
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.global_options.shared_options import SharedOptions
from highcharts_core.options.series.pie import PieSeries
        
# Create the chart
my_chart = Chart(
            container="container",
            options={
                "chart": {
                    "plotBackgroundColor": None,
                    "plotBorderWidth": 0,
                    "plotShadow": False,
                    "type":"pie"
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "tooltip": {
                    "pointFormat": "{series.name}: <b>{point.percentage:.1f}%</b>",
                },
                "accessibility": {
                    "point": {"valueSuffix": "%"},
                },
                "plotOptions": {
                    "pie": {
                        "dataLabels": {
                            "enabled": True,
                            "distance": -50,
                            "style": {"fontWeight": "bold", "color": "white"},
                        },
                        "startAngle": -90,
                        "endAngle": 90,
                        "center": ["50%", "75%"],
                        "size": "110%",
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
# Display the chart in your Jupyter Notebook
my_chart.display()
        `
        return PyScript;
    },
    "Bubble chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.global_options.shared_options import SharedOptions
from highcharts_core.options.series.scatter import ScatterSeries

        # Build the chart
scatter_chart = Chart(
            container="container",
            options={
                **color_options,
                'chart': {'type': 'scatter', 'zoomType': 'xy'},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                'legend': {'enabled': True},
                'plotOptions': {
                    'scatter': {
                        'marker': {
                            'radius': 2.5,
                            'symbol': 'circle',
                            'states': {'hover': {'enabled': True, 'lineColor': 'rgb(100,100,100)'}}
                        },
                        'states': {'hover': {'marker': {'enabled': False}}},
                        'jitter': {'x': 0.005}
                    }
                },
                'series': ${stringifyUploadedData}
            }
        )
        
        # Display the chart
scatter_chart.display()
        
                
        `
        return PyScript;
    },
    "Scatter plot": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.scatter import ScatterSeries

chart = Chart(
            container="container",
            options={
                "chart": {"type": "scatter"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "scatter": {
                        "showInLegend": False,
                        "jitter": {"x": 0.24, "y": 0},
                        "marker": {"radius": 2, "symbol": "circle"},
                        "tooltip": {"pointFormat": "Measurement: {point.y:.3f}"},
                    }
                },
                "series":${stringifyUploadedData}
            },
        )
# Display the chart
chart.display()
        `
        return PyScript;
    },
    "plot with jitter": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.scatter import ScatterSeries

chart = Chart(
            container="container",
            options={
                "chart": {"type": "scatter"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "scatter": {
                        "showInLegend": False,
                        "jitter": {"x": 0.24, "y": 0},
                        "marker": {"radius": 2, "symbol": "circle"},
                        "tooltip": {"pointFormat": "Measurement: {point.y:.3f}"},
                    }
                },
                "series":${stringifyUploadedData}
            },
        )
# Display the chart
chart.display()
        `
        return PyScript;
    },
    "Packed bubble chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.packedbubble import PackedBubbleSeries
        
        # Create the chart
packedbubble_chart = Chart(
            container="container",
            options={
                "chart": {"type": "packedbubble", "height": "1000"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "packedbubble": {
                        "minSize": "30%",
                        "maxSize": "120%",
                        "zMin": 0,
                        "zMax": 1000,
                        "layoutAlgorithm": {"splitSeries": False, "gravitationalConstant": 0.02},
                        "dataLabels": {
                            "enabled": True,
                            "format": "{point.name}",
                            "filter": {"property": "y", "operator": ">", "value": 250},
                            "style": {"color": "black", "textOutline": "none", "fontWeight": "normal"},
                        },
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart
packedbubble_chart.display()
        
        `
        return PyScript;
    },
    "3D column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
        # Create the chart
column_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "column",
                    "options3d": {
                        "enabled": True,
                        "alpha": 15,
                        "beta": 15,
                        "viewDistance": 25,
                        "depth": 40,
                    },
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "series": {"pointStart": 2016},
                    "column": {"stacking": "normal", "depth": 40},
                },
                "series": ${stringifyUploadedData}
            },
        )
        
# Display the chart
column_chart.display()
        
        `
        return PyScript;
    },
    "3D donuts": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.pie import PieSeries

pie_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "pie",
                    "options3d": {"enabled": True, "alpha": 45},
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "pie": {"innerSize": 100, "depth": 45},
                },
                "series": ${stringifyUploadedData}
            },
        )
        
        # Display the chart
pie_chart.display()               
        `
        return PyScript;
    },
    "3D funnel": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
       # Create the chart
funnel3d_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "funnel3d",
                    "options3d": {"enabled": True, "alpha": 10, "depth": 50, "viewDistance": 50},
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "series": {
                        "dataLabels": {
                            "enabled": True,
                            "format": "<b>{point.name}</b> ({point.y:,.0f})",
                            "allowOverlap": True,
                            "y": 10,
                        },
                        "neckWidth": "30%",
                        "neckHeight": "25%",
                        "width": "80%",
                        "height": "80%",
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
        # Display the chart
funnel3d_chart.display()
                 
        `
        return PyScript;
    },
    "3D pyramid": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
        # Create the chart
pyramid3d_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "pyramid3d",
                    "options3d": {"enabled": True, "alpha": 10, "depth": 50, "viewDistance": 50},
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "plotOptions": {
                    "series": {
                        "dataLabels": {
                            "enabled": True,
                            "format": "<b>{point.name}</b> ({point.y:,.0f})",
                            "allowOverlap": True,
                            "x": 10,
                            "y": -5,
                        },
                        "width": "60%",
                        "height": "80%",
                        "center": ["50%", "45%"],
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
        # Display the chart
pyramid3d_chart.display()
        
                 
        `
        return PyScript;
    },
    "3D pie": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
        # Create the chart
pie_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "pie",
                    "options3d": {"enabled": True, "alpha": 45, "beta": 0},
                },
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "accessibility": {"point": {"valueSuffix": "%"}},
                "tooltip": {"pointFormat": "{series.name}: <b>{point.percentage:.1f}%</b>"},
                "plotOptions": {
                    "pie": {
                        "allowPointSelect": True,
                        "cursor": "pointer",
                        "depth": 35,
                        "dataLabels": {"enabled": True, "format": "{point.name}"},
                    }
                },
                "series": ${stringifyUploadedData}
            },
        )
        
        # Display the chart
pie_chart.display()
        
        `
        return PyScript;
    },
    "3D cylinder": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        uploadedData.forEach(series => {
            series.data = series.data.map(value => value === null ? 0 : value);
        });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
        # Create the chart
column_chart = Chart(
            container="container",
            options={
                "chart": {
                    "type": "column",
                    "options3d": {"enabled": True, "alpha": 15, "beta": 15, "depth": 50, "viewDistance": 25},
                },
                "tooltip": {"headerFormat": "<b>{point.key}</b><br>", "pointFormat": "Cars sold: {point.y}"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "legend": {"enabled": False},
                "plotOptions": {"column": {"depth": 25}},
                "series": ${stringifyUploadedData}
            },
        )
        
        # Display the chart
column_chart.display()
        
        
        `
        return PyScript;
    },
    "Heat map": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        // uploadedData.forEach(series => {
        //     series.data = series.data.map(value => value === null ? 0 : value);
        // });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.heatmap import HeatmapSeries

# Define the series data
series_data = [{
    "name": "Sales per employee",
    "borderWidth": 1,
    "data": ${stringifyUploadedData},
    "dataLabels": {"enabled": True, "color": "#000000"}
}]

# Create the chart
heatmap_chart = Chart(
    container="container",
    options={
        "chart": {
            "type": "heatmap",
            "marginTop": 40,
            "marginBottom": 80,
            "plotBorderWidth": 1
        },
        "title": {"text": "${title}","align":"${titleAlignment}"},
        "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
        "xAxis": { "title": {"text": "${xAxistext}"} },
        "yAxis": { "title": {"text": "${yAxistext}"} },
        "colorAxis": {"min": 0, "minColor": "#FFFFFF", "maxColor": "#7cb5ec"},  # Assume '#7cb5ec' for maxColor
        "legend": {
            "align": "right",
            "layout": "vertical",
            "margin": 0,
            "verticalAlign": "top",
            "y": 25,
            "symbolHeight": 280
        },
        "series": series_data,
        "responsive": {
            "rules": [{
                "condition": {"maxWidth": 500},
                "chartOptions": {
                    "yAxis": {"labels": {"format": "{substr value 0 1}"}}
                }
            }]
        }
    },
)

# Display the chart
heatmap_chart.display()

        `
        return PyScript;
    },
    "Large heat map": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        // Iterate over the series data and replace null with None
        // uploadedData.forEach(series => {
        //     series.data = series.data.map(value => value === null ? 0 : value);
        // });
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
        from highcharts_core.options.series.heatmap import HeatmapSeries
        
        
        # Define the series data
        series_data = [{
            "data": ${stringifyUploadedData},
            "borderWidth": 0,
            "nullColor": '#EFEFEF',
            "tooltip": {
                "headerFormat": 'Temperature<br/>',
                "pointFormat": '<b>{point.value} ℃</b>'
            }
        }]
        
        # Create the chart
        heatmap_chart = Chart(
            container="container",
            options={
                "chart": {"type": "heatmap"},
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "colorAxis": {
                    "stops": [[0, '#3060cf'], [0.5, '#fffbbc'], [0.8, '#c4463a'], [1, '#c4463a']],
                    "startOnTick": False,
                    "endOnTick": False,
                    "labels": {"format": '{value}℃'}
                },
                "series": series_data
            },
        )
        
# Display the chart
heatmap_chart.display()
        
        `
        return PyScript;
    },
    "map with color axis": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        uploadedData.flatMap((item)=>{
            if(item === "null") {
                return 0;
            } else {
                return item;
            }
        })
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_core.chart import Chart
from highcharts_core.options.series.treemap import TreemapSeries
        
        # Define the series data
series_data = [{
            "type": 'treemap',
            "layoutAlgorithm": 'squarified',
            "clip": False,
            "data":${stringifyUploadedData}
        }]
        
        # Create the chart
treemap_chart = Chart(
            container="container",
            options={
                "series": series_data,
                "title": {"text": "Highcharts Treemap"}
            },
            "title": {"text": "${title}","align":"${titleAlignment}"},
            "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
            "xAxis": { "title": {"text": "${xAxistext}"} },
            "yAxis": { "title": {"text": "${yAxistext}"} },
        )
        
# Display the chart
treemap_chart.display()
        
        
        `
        return PyScript;
    },
    "Flags marking events": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        let v1 ;
        let v2;
        let newData = uploadedData.map((item)=>{
            v1 = item[0] === null ? 0 : item[0];
            v2= item[1] === null ? 0 : item[1];
            return [v1,v2]
        });
        let stringifyUploadedData = JSON.stringify(newData);
        const PyScript = `from highcharts_core.chart import Chart

        # Define the series data
series_data = [{
            "type": 'line',
            "name": 'AAPL Stock Price',
            "data": ${stringifyUploadedData},
            "step": 'center',  # Change this line to specify step interpolation
            "tooltip": {
                "valueDecimals": 2
            }
        }]
        
        # Create the chart
chart = Chart(
            container="container",
            options={
                "series": series_data,
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
            },

        )
        
# Display the chart
chart.display()
        
        `
        return PyScript;
    },
    
    "Intraday candlestick": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        uploadedData.flatMap((item)=>{
            if(item === "null") {
                return 0;
            } else {
                return item;
            }
        })
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const PyScript = `from highcharts_stock.chart import Chart
from highcharts_stock.options.series.candlestick import CandlestickSeries
from highcharts_stock.options.range_selector import RangeSelector
from highcharts_stock.global_options.shared_options import SharedOptions
# Sample data
sample_data = ${stringifyUploadedData};
# Create the chart
my_stock_chart = Chart(
            container="container",  # Replace with the ID of your HTML element
            options={
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
                "rangeSelector": {
                    "buttons": [
                        {"type": "hour", "count": 1, "text": '1h'},
                        {"type": "day", "count": 1, "text": '1D'},
                        {"type": "all", "count": 1, "text": 'All'},
                    ],
                    "selected": 1,
                    "inputEnabled": False,
                },
                "series": [
                    CandlestickSeries(
                        name='AAPL',
                        data=sample_data,
                        tooltip={'valueDecimals': 2}
                    )
                ],
            },
        )
my_stock_chart.display()
        `
        return PyScript;
    },
    "Single series": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        let uploadedData = userData;
        let v1 ;
        let v2;
        let newData = uploadedData.map((item)=>{
            v1 = item[0] === null ? 0 : item[0];
            v2= item[1] === null ? 0 : item[1];
            return [v1,v2]
        });
        let stringifyUploadedData = JSON.stringify(newData);
        const PyScript = `from highcharts_core.chart import Chart

        # Define the series data
series_data = [{
            "type": 'line',
            "name": 'AAPL Stock Price',
            "data": ${stringifyUploadedData},
            "step": 'center',  # Change this line to specify step interpolation
            "tooltip": {
                "valueDecimals": 2
            }
        }]
        
        # Create the chart
chart = Chart(
            container="container",
            options={
                "series": series_data,
                "title": {"text": "${title}","align":"${titleAlignment}"},
                "subtitle": {"text": "${subTitle}","align":"${subTitleAlignment}"},
                "xAxis": { "title": {"text": "${xAxistext}"} },
                "yAxis": { "title": {"text": "${yAxistext}"} },
            },
        )
        
# Display the chart
chart.display()
        
        `
        return PyScript;
    },   
    
}
export default SnippetsPy;