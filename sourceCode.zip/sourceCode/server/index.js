import express from 'express';
import bodyParser from 'body-parser';
import codeSnippets from './snippets.mjs';
import SnippetsPy from './snippetsPy.mjs'
import cors from 'cors'

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

app.post('/generate-chart', (req, res) => {
    try {
        const chartType = req.body.chartType;
        const userData = req.body.userData;
        const title = req.body.title;
        const titleAlignment = req.body.titleAlignment;
        const subTitle = req.body.subTitle;
        const subTitleAlignment = req.body.subTitleAlignment;
        const yAxistext = req.body.yAxistext;
        const xAxistext = req.body.xAxistext;
        const minColor = req.body.minColor ? req.body.minColor : "#FFFFFF";
        const maxColor = req.body.maxColor ? req.body.maxColor : "#56bffe";
        const stockColor = req.body.stockColor ? req.body.stockColor : "#56bffe";
        const treeColor = req.body.treeColor ? req.body.treeColor : "#56bffe";
        if (codeSnippets[chartType]) {
            const generatedCode = codeSnippets[chartType](userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext, minColor, maxColor, stockColor, treeColor);
            const generatedCodePy = SnippetsPy[chartType](userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext);

            res.status(200).send({ generatedCode: generatedCode, generatedCodePy: generatedCodePy });
        } else {
            res.status(400).send('Invalid chart type');
        }
    } catch (error) {
        console.error('Error:', error);
        console.error('Request Body:', req.body);
        res.status(500).send('Internal Server Error');
    }
});
// Error handling middleware
app.use((err, req, res, next) => {
    console.error('An error occurred:', err);
    res.status(500).send('Internal Server Error');
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
