const codeSnippets = {
    "Line Charts": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = ` Highcharts.chart('container', {

        title: {
            text: '${title}',
            align: '${titleAlignment}'
        },
    
        subtitle: {
            text: '${subTitle}',
            align: '${subTitleAlignment}'
        },
        yAxis: {
            title: {
                text: '${yAxistext}'
            }
        },
    
        xAxis: {
        title: {
                text: '${xAxistext}'
            },
            labels: {
                align: 'center', // Align labels at the center
                y: 20 // Position labels below the xAxis
            }
        },  
        legend: {
            layout: 'horizontal',
            align: 'center', 
            verticalAlign: 'bottom'
        },
    
        plotOptions: {
            series: {
                label: {
                    connectorAllowed: false
                },
                pointStart: 2008
            }
        },
    
        series: ${chartData},
    
        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
        }
    
    });  `
        return script;
    },
    "Spline with symbols": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'spline'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                crosshairs: true,
                shared: true
            },
            plotOptions: {
                spline: {
                    marker: {
                        radius: 4,
                        lineColor: '#666666',
                        lineWidth: 1
                    }
                }
            },
            series: ${chartData}
        });
        `
        return script;

    },
    "Inverted axes": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'spline',
                inverted: true
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                reversed: false,
                title: {
                    enabled: true,
                    text: '${xAxistext}'
                },
                maxPadding: 0.05,
                showLastLabel: true
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                },
                lineWidth: 2
            },
            legend: {
                enabled: false
            },
            tooltip: {
                headerFormat: '<b>{series.name}</b><br/>',
                pointFormat: '{point.x} km: {point.y}°C'
            },
            plotOptions: {
                spline: {
                    marker: {
                        enable: false
                    }
                }
            },
            series: ${chartData}
        });
        
        `
        return script;

    },
    "With data labels": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'line'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align:'${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true
                    },
                    enableMouseTracking: false
                }
            },
            series: ${chartData}
        });
        `
        return script;

    },
    "Logarithmic axis": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {

            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    enabled: true,
                    text: '${xAxistext}'
                },
                tickInterval: 1,
                type: 'logarithmic',
                accessibility: {
                    rangeDescription: 'Range: 1 to 10'
                }
            },
        
            yAxis: {
                title: {
                    enabled: true,
                    text: '${yAxistext}'
                },
                type: 'logarithmic',
                minorTickInterval: 0.1,
                accessibility: {
                    rangeDescription: 'Range: 0.1 to 1000'
                }
            },
        
            tooltip: {
                headerFormat: '<b>{series.name}</b><br />',
                pointFormat: 'x = {point.x}, y = {point.y}'
            },
        
            series: ${chartData}
        });
        
        `
        return script;

    },
    "irregular intervals": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'spline'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                },
                min: 0
            },
            tooltip: {
                headerFormat: '<b>{series.name}</b><br>',
                pointFormat: '{point.x:%e. %b}: {point.y:.2f} m'
            },
        
            plotOptions: {
                series: {
                    marker: {
                        symbol: 'circle',
                        fillColor: '#FFFFFF',
                        enabled: true,
                        radius: 2.5,
                        lineWidth: 1,
                        lineColor: null
                    }
                }
            },
        
            colors: ['#6CF', '#39F', '#06C', '#036', '#000'],
        
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "Plot bands": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'spline',
                scrollablePlotArea: {
                    minWidth: 600,
                    scrollPositionX: 1
                }
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                },
                minorGridLineWidth: 0,
                gridLineWidth: 0,
                alternateGridColor: null,
                plotBands: [{ // Light air
                    from: 0.3,
                    to: 1.5,
                    color: 'rgba(68, 170, 213, 0.1)',
                    label: {
                        text: 'Light air',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Light breeze
                    from: 1.5,
                    to: 3.3,
                    color: 'rgba(0, 0, 0, 0)',
                    label: {
                        text: 'Light breeze',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Gentle breeze
                    from: 3.3,
                    to: 5.5,
                    color: 'rgba(68, 170, 213, 0.1)',
                    label: {
                        text: 'Gentle breeze',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Moderate breeze
                    from: 5.5,
                    to: 8,
                    color: 'rgba(0, 0, 0, 0)',
                    label: {
                        text: 'Moderate breeze',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Fresh breeze
                    from: 8,
                    to: 11,
                    color: 'rgba(68, 170, 213, 0.1)',
                    label: {
                        text: 'Fresh breeze',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Strong breeze
                    from: 11,
                    to: 14,
                    color: 'rgba(0, 0, 0, 0)',
                    label: {
                        text: 'Strong breeze',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Near Gale
                    from: 14,
                    to: 17,
                    color: 'rgba(68, 170, 213, 0.1)',
                    label: {
                        text: 'Near gale',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Fresh Gale
                    from: 17,
                    to: 20.5,
                    color: 'rgba(0, 0, 0, 0)',
                    label: {
                        text: 'Fresh gale',
                        style: {
                            color: '#606060'
                        }
                    }
                }, { // Strong Gale
                    from: 20.5,
                    to: 24,
                    color: 'rgba(68, 170, 213, 0.1)',
                    label: {
                        text: 'Strong gale',
                        style: {
                            color: '#606060'
                        }
                    }
                }]
            },
            tooltip: {
                valueSuffix: ' m/s'
            },
            plotOptions: {
                spline: {
                    lineWidth: 4,
                    states: {
                        hover: {
                            lineWidth: 5
                        }
                    },
                    marker: {
                        enabled: false
                    },
                    pointInterval: 3600000, // one hour
                    pointStart: Date.UTC(2020, 3, 15, 0, 0, 0)
                }
            },
            series: ${chartData},
            navigation: {
                menuItemStyle: {
                    fontSize: '10px'
                }
            }
        });
        
        
        `
        return script;

    },
    "Basic area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'area'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                },
                allowDecimals: false,
                
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                area: {
                    pointStart: 1940,
                    marker: {
                        enabled: false,
                        symbol: 'circle',
                        radius: 2,
                        states: {
                            hover: {
                                enabled: true
                            }
                        }
                    }
                }
            },
            series: ${chartData}
        });
        
        
        
        `
        return script;

    },
    "Stacked area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'area'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                },
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                shared: true,
                headerFormat: '<span style="font-size:12px"><b>{point.key}</b></span><br>'
            },
            plotOptions: {
                series: {
                    pointStart: 2012
                },
                area: {
                    stacking: 'normal',
                    lineColor: '#666666',
                    lineWidth: 1,
                    marker: {
                        lineWidth: 1,
                        lineColor: '#666666'
                    }
                }
            },
            series: ${chartData}
        });
        
        `
        return script;

    },
    "Percentage area": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'area'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis:{  title: {
                text: '${xAxistext}'
            }},
            yAxis: {
                labels: {
                    format: '{value}%'
                },
                title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.1f} billion Gt)<br/>',
                split: true
            },
            plotOptions: {
                series: {
                    pointStart: 1990
                },
                area: {
                    stacking: 'percent',
                    marker: {
                        enabled: false
                    }
                }
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "Area-spline": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'areaspline'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                verticalAlign: 'top',
                x: 120,
                y: 70,
                floating: true,
                borderWidth: 1,
                backgroundColor:
                    Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF'
            },
            xAxis: {
                plotBands: [{ // Highlight the two last years
                    from: 2019,
                    to: 2020,
                    color: 'rgba(68, 170, 213, .2)'
                }],
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                  title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                shared: true,
                headerFormat: '<b>Hunting season starting autumn {point.x}</b><br>'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                series: {
                    pointStart: 2000
                },
                areaspline: {
                    fillOpacity: 0.5
                }
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "Missing points": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'area'
            },
            title: {
                text: '${title}',
                align:'${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                verticalAlign: 'top',
                x: 150,
                y: 60,
                floating: true,
                borderWidth: 1,
                backgroundColor:
                    Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                series: {
                    pointStart: 2014
                },
                area: {
                    fillOpacity: 0.5
                }
            },
            credits: {
                enabled: false
            },
            series: ${chartData}
        });
            
        `
        return script;

    },
    "With negative values Area Chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'area'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            credits: {
                enabled: false
            },
            series: ${chartData}
        });
        `
        return script;

    },
    "Basic bar": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'bar'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: null
                },
                gridLineWidth: 1,
                lineWidth: 0,
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '${xAxistext}'
                },
                labels: {
                    overflow: 'justify'
                },
                gridLineWidth: 0
            },
            tooltip: {
                valueSuffix: ' millions'
            },
            plotOptions: {
                bar: {
                    borderRadius: '50%',
                    dataLabels: {
                        enabled: true
                    },
                    groupPadding: 0.1
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -40,
                y: 80,
                floating: true,
                borderWidth: 1,
                backgroundColor:
                    Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
                shadow: true
            },
            credits: {
                enabled: false
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "Basic column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                crosshair: true,
                accessibility: {
                    description: 'Countries'
                },
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                valueSuffix: ' (1000 MT)'
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "Stacked and grouped": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {

    chart: {
        type: 'column'
    },

    title: {
        text: '${title}',
        align: '${titleAlignment}'
    },
    subtitle: {
        text: '${subTitle}',
        align: '${subTitleAlignment}'
    },

    xAxis: {
        title: {
            text: '${xAxistext}'
        }
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: '${yAxistext}'
        }
    },

    tooltip: {
        format: '<b>{key}</b><br/>{series.name}: {y}<br/>' +
            'Total: {point.stackTotal}'
    },

    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },

    series: ${chartData}
});

        
        `
        return script;

    },
    "Column range": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const convertDataFormat = (data) => {
            return data.map((series) => {
                // Check if data is already in the desired format
                if (Array.isArray(series.data[0]) && series.data[0].length === 2 && series.data[0][0] < 0 && series.data[0][1] > 0) {
                    // If data is already in the desired format, return it unchanged
                    return series;
                } else {
                    // Convert data to the desired format
                    return {
                        data: Array.isArray(series.data) ? series.data.map((value) => [-value, value === null ? 0 : value]) : [[-series.data, series.data === null ? 0 : series.data]],
                        name: series.name
                    };
                }
            });
        };

        // Convert the data format
        let uploadedData = convertDataFormat(userData);

        // Stringify the converted data
        let stringifyUploadedData = JSON.stringify(uploadedData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'columnrange',
                inverted: true
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                columnrange: {
                    borderRadius: '50%',
                    dataLabels: {
                        enabled: true,
                    }
                }
            },
            legend: {
                enabled: false
            },
            series: ${stringifyUploadedData}
            });
        `
        return script;

    },
    "Variwide": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);

        // Parse chartData into an array of objects
        const parsedUserData = JSON.parse(chartData);

        // Check if any object in parsedUserData has a data property
        const updateData = parsedUserData.some(obj => obj.data !== undefined && obj.data !== null)
            ? JSON.stringify(parsedUserData.map(obj => obj.data))
            : chartData;

        console.log(updateData);
        const script = `Highcharts.chart('container', {

            chart: {
                type: 'variwide'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                },
                type: 'category'
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },

            legend: {
                enabled: false
            },
        
            series: [{ 
                data:${updateData},
                dataLabels: {
                    enabled: true,
                },
                
                borderRadius: 3,
                colorByPoint: true
            }]
        
        });
        
        `
        return script;

    },
    "With negative values Bar Chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                column: {
                    borderRadius: '25%'
                }
            },
            series: ${chartData}
        });
            
        `
        return script;

    },
    "Stacked column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
                
            },
            yAxis: {
                min: 0,
                title: {
                    text: '${yAxistext}'
                },
                stackLabels: {
                    enabled: true
                }
            },
            legend: {
                align: 'left',
                x: 70,
                verticalAlign: 'top',
                y: 70,
                floating: true,
                backgroundColor:
                    Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b><br/>',
                pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: ${chartData}
        });
        
            
        `
        return script;

    },
    "Pie chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'pie'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                } 
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
                
            },
            plotOptions: {
                series: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: [{
                        enabled: true,
                        distance: 20
                    }, {
                        enabled: true,
                        distance: -40,
                        format: '{point.percentage:.1f}%',
                        style: {
                            fontSize: '1.2em',
                            textOutline: 'none',
                            opacity: 0.7
                        },
                        filter: {
                            operator: '>',
                            property: 'percentage',
                            value: 10
                        }
                    }]
                }
            },
            series: [{data: ${chartData}}]

        });
        
        `
        return script;

    },
    "custom entrance animation": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `
        (function (H) {
            H.seriesTypes.pie.prototype.animate = function (init) {
                const series = this,
                    chart = series.chart,
                    points = series.points,
                    {
                        animation
                    } = series.options,
                    {
                        startAngleRad
                    } = series;
        
                function fanAnimate(point, startAngleRad) {
                    const graphic = point.graphic,
                        args = point.shapeArgs;
        
                    if (graphic && args) {
        
                        graphic
                            // Set inital animation values
                            .attr({
                                start: startAngleRad,
                                end: startAngleRad,
                                opacity: 1
                            })
                            // Animate to the final position
                            .animate({
                                start: args.start,
                                end: args.end
                            }, {
                                duration: animation.duration / points.length
                            }, function () {
                                // On complete, start animating the next point
                                if (points[point.index + 1]) {
                                    fanAnimate(points[point.index + 1], args.end);
                                }
                                // On the last point, fade in the data labels, then
                                // apply the inner size
                                if (point.index === series.points.length - 1) {
                                    series.dataLabelsGroup.animate({
                                        opacity: 1
                                    },
                                    void 0,
                                    function () {
                                        points.forEach(point => {
                                            point.opacity = 1;
                                        });
                                        series.update({
                                            enableMouseTracking: true
                                        }, false);
                                        chart.update({
                                            plotOptions: {
                                                pie: {
                                                    innerSize: '40%',
                                                    borderRadius: 8
                                                }
                                            }
                                        });
                                    });
                                }
                            });
                    }
                }
        
                if (init) {
                    // Hide points on init
                    points.forEach(point => {
                        point.opacity = 0;
                    });
                } else {
                    fanAnimate(points[0], startAngleRad);
                }
            };
        }(Highcharts));
        
        Highcharts.chart('container', {
            chart: {
                type: 'pie'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                } 
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                } 
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            accessibility: {
                point: {
                    valueSuffix: '%'
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    borderWidth: 2,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b><br>{point.percentage}%',
                        distance: 20
                    }
                }
            },
            series: [{
                // Disable mouse tracking on load, enable after custom animation
                enableMouseTracking: false,
                animation: {
                    duration: 2000
                },
                colorByPoint: true,
                data: ${chartData}
            }]
        });
        
        `
        return script;

    },
    "With monochrome fill": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);;
        const script = `var colorShade = Highcharts.getOptions().colors.map((c, i) =>
        Highcharts.color(Highcharts.getOptions().colors[0])
            .brighten((i - 3) / 7)
            .get()
    );

    
    Highcharts.chart('container', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: '${title}',
            align: '${titleAlignment}'
        },
        subtitle: {
            text: '${subTitle}',
            align: '${subTitleAlignment}'
        },
        xAxis: {
            title: {
                text: '${xAxistext}'
            } 
        },
        yAxis: {
            title: {
                text: '${yAxistext}'
            } 
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                colors:colorShade,
                borderRadius: 5,
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
                    distance: -50,
                    filter: {
                        property: 'percentage',
                        operator: '>',
                        value: 4
                    }
                }
            }
        },
        series:[{ data : ${chartData} }]
    });
    
    
        `
        return script;

    },
    "Semi circle donut": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: 0,
        plotShadow: false
    },
    title: {
        text: '${title}',
        align: '${titleAlignment}'
    },
    subtitle: {
        text: '${subTitle}',
        align: '${subTitleAlignment}'
    },
    xAxis: {
        title: {
            text: '${xAxistext}'
        } 
    },
    yAxis: {
        title: {
            text: '${yAxistext}'
        } 
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: true,
                distance: -50,
                style: {
                    fontWeight: 'bold',
                    color: 'white'
                }
            },
            startAngle: -90,
            endAngle: 90,
            center: ['50%', '75%'],
            size: '110%'
        }
    },
    series: [{
        type: 'pie',
        name: 'Browser share',
        innerSize: '50%',
        data:${chartData}
    }]
});

    
        `
        return script;

    },
    "Bubble chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {

            chart: {
                type: 'bubble',
                plotBorderWidth: 1,
                zoomType: 'xy'
            },
        
            legend: {
                enabled: false
            },
        
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            accessibility: {
                point: {
                    valueDescriptionFormat: '{index}. {point.name}, fat: {point.x}g, sugar: {point.y}g, obesity: {point.z}%.'
                }
            },
        
            xAxis: {
                gridLineWidth: 1,
                title: {
                    text: '${xAxistext}'
                },
                plotLines: [{
                    color: 'black',
                    dashStyle: 'dot',
                    width: 2,
                    value: 65,
                    label: {
                        rotation: 0,
                        y: 15,
                        style: {
                            fontStyle: 'italic'
                        }
                        
                    },
                    zIndex: 3
                }],
                
            },
        
            yAxis: {
                startOnTick: false,
                endOnTick: false,
                maxPadding: 0.2,
                title: {
                    text: '${yAxistext}'
                },
                plotLines: [{
                    color: 'black',
                    dashStyle: 'dot',
                    width: 2,
                    value: 50,
                    label: {
                        align: 'right',
                        style: {
                            fontStyle: 'italic'
                        },
                        
                        x: -10
                    },
                    zIndex: 3
                }],
               
            },
        
           
        
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}'
                    }
                }
            },
        
            series: ${chartData}
        
        });
        `
        return script;

    },
    "Scatter plot": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.setOptions({
            colors: ['rgba(5,141,199,0.5)', 'rgba(80,180,50,0.5)', 'rgba(237,86,27,0.5)']
        });
            Highcharts.chart('container', {
                chart: {
                    type: 'scatter',
                    zoomType: 'xy'
                },
                title: {
                    text: '${title}',
                    align: '${titleAlignment}'
                },
                subtitle: {
                    text: '${subTitle}',
                    align: '${subTitleAlignment}'
                },
                xAxis: {
                    title: {
                        text: '${xAxistext}'
                    },
                    startOnTick: true,
                    endOnTick: true,
                    showLastLabel: true
                },
                yAxis: {
                    title: {
                        text: '${yAxistext}'
                    }
                },
                legend: {
                    enabled: true
                },
                plotOptions: {
                    scatter: {
                        marker: {
                            radius: 2.5,
                            symbol: 'circle',
                            states: {
                                hover: {
                                    enabled: true,
                                    lineColor: 'rgb(100,100,100)'
                                }
                            }
                        },
                        states: {
                            hover: {
                                marker: {
                                    enabled: false
                                }
                            }
                        },
                        jitter: {
                            x: 0.005
                        }
                    }
                },
                series: 
                    ${chartData}
                   
                
        });
        `
        return script;

    },
    "plot with jitter": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `var colors = Highcharts.getOptions().colors.map(color =>
            Highcharts.color(color).setOpacity(0.5).get()
        );
        
        Highcharts.chart('container', {
            chart: {
                type: 'scatter'
            },     
            colors,
        
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },      
            plotOptions: {
                scatter: {
                    showInLegend: false,
                    jitter: {
                        x: 0.24,
                        y: 0
                    },
                    marker: {
                        radius: 2,
                        symbol: 'circle'
                    },
                    tooltip: {
                        pointFormat: 'Measurement: {point.y:.3f}'
                    }
                }
            },
        
            series: ${chartData}
        });
        `
        return script;

    },
    "Packed bubble chart": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'packedbubble',
                height: '100%'
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                }
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                }
            },
            tooltip: {
                useHTML: true,
                pointFormat: '<b>{point.name}:</b> {point.value}m CO<sub>2</sub>'
            },
            plotOptions: {
                packedbubble: {
                    minSize: '30%',
                    maxSize: '120%',
                    zMin: 0,
                    zMax: 1000,
                    layoutAlgorithm: {
                        splitSeries: false,
                        gravitationalConstant: 0.02
                    },
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}',
                        filter: {
                            property: 'y',
                            operator: '>',
                            value: 250
                        },
                        style: {
                            color: 'black',
                            textOutline: 'none',
                            fontWeight: 'normal'
                        }
                    }
                }
            },
            series: ${chartData}
        });
        
        `
        return script;

    },
    "3D column": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'column',
                options3d: {
                    enabled: true,
                    alpha: 15,
                    beta: 15,
                    viewDistance: 25,
                    depth: 40
                }
            },
        
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}',
                    labels: {
                        skew3d: true,
                        style: {
                            fontSize: '16px'
                        }
                    }
                }
            },
            yAxis: {
                labels: {
                    skew3d: true,
                    style: {
                        fontSize: '16px'
                    }
                },
                title: {
                    text: '${yAxistext}'
                }
            },

        
            plotOptions: {
                series: {
                    pointStart: 2016
                },
                column: {
                    stacking: 'normal',
                    depth: 40
                }
            },
        
            series: ${chartData}
        });
        
        `
        return script;

    },
    "3D donuts": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45
                }
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}',
                    labels: {
                        skew3d: true,
                        style: {
                            fontSize: '16px'
                        }
                    }
                }
            },
            yAxis: {
                labels: {
                    skew3d: true,
                    style: {
                        fontSize: '16px'
                    }
                },
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                pie: {
                    innerSize: 100,
                    depth: 45
                }
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "3D funnel": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'funnel3d',
                options3d: {
                    enabled: true,
                    alpha: 10,
                    depth: 50,
                    viewDistance: 50
                }
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}',
                    labels: {
                        skew3d: true,
                        style: {
                            fontSize: '16px'
                        }
                    }
                }
            },
            yAxis: {
                labels: {
                    skew3d: true,
                    style: {
                        fontSize: '16px'
                    }
                },
                title: {
                    text: '${yAxistext}'
                }
            },
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b> ({point.y:,.0f})',
                        allowOverlap: true,
                        y: 10
                    },
                    neckWidth: '30%',
                    neckHeight: '25%',
                    width: '80%',
                    height: '80%'
                }
            },
            series: ${chartData}
        });
        
        `
        return script;

    },
    "3D pyramid": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
    chart: {
        type: 'pyramid3d',
        options3d: {
            enabled: true,
            alpha: 10,
            depth: 50,
            viewDistance: 50
        }
    },
    title: {
        text: '${title}',
        align: '${titleAlignment}'
    },
    subtitle: {
        text: '${subTitle}',
        align: '${subTitleAlignment}'
    },
    xAxis: {
        title: {
            text: '${xAxistext}',
            labels: {
                skew3d: true,
                style: {
                    fontSize: '16px'
                }
            }
        }
    },
    yAxis: {
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        },
        title: {
            text: '${yAxistext}'
        }
    },
    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b> ({point.y:,.0f})',
                allowOverlap: true,
                x: 10,
                y: -5
            },
            width: '60%',
            height: '80%',
            center: ['50%', '45%']
        }
    },
    series: ${chartData}
});
        `
        return script;

    },
    "3D pie": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                }
            },
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}',
                    labels: {
                        skew3d: true,
                        style: {
                            fontSize: '16px'
                        }
                    }
                }
            },
            yAxis: {
                labels: {
                    skew3d: true,
                    style: {
                        fontSize: '16px'
                    }
                },
                title: {
                    text: '${yAxistext}'
                }
            },
            accessibility: {
                point: {
                    valueSuffix: '%'
                }
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    depth: 35,
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}'
                    }
                }
            },
            series: ${chartData}
        });
        
        
        `
        return script;

    },
    "3D cylinder": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext) => {
        const chartData = JSON.stringify(userData);
        const script = `var chart = new Highcharts.Chart({
    chart: {
        renderTo: 'container',
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 15,
            depth: 50,
            viewDistance: 25
        }
    },
    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: 'Cars sold: {point.y}'
    },
    title: {
        text: '${title}',
        align: '${titleAlignment}'
    },
    subtitle: {
        text: '${subTitle}',
        align: '${subTitleAlignment}'
    },
    xAxis: {
        title: {
            text: '${xAxistext}',
            labels: {
                skew3d: true,
                style: {
                    fontSize: '16px'
                }
            }
        }
    },
    yAxis: {
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        },
        title: {
            text: '${yAxistext}'
        }
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    series: ${chartData}
});

        
        `
        return script;

    },
    "Heat map": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.Templating.helpers.substr = (s, from, length) =>
    s.substr(from, length);

// Create the chart
Highcharts.chart('container', {

    chart: {
        type: 'heatmap',
        marginTop: 40,
        marginBottom: 80,
        plotBorderWidth: 1
    },
    title: {
        text: '${title}',
        align: '${titleAlignment}'
    },
    subtitle: {
        text: '${subTitle}',
        align: '${subTitleAlignment}'
    },
    xAxis: {
        title: {
            text: '${xAxistext}'
        } 
    },
    yAxis: {
        title: {
            text: '${yAxistext}'
        } 
    },
    accessibility: {
        point: {
            descriptionFormat: '{(add index 1)}. ' +
                '{series.xAxis.categories.(x)} sales ' +
                '{series.yAxis.categories.(y)}, {value}.'
        }
    },
    colorAxis: {
        min: 0,
        minColor: "${minColor}",
        maxColor:"${maxColor}"
    },

    legend: {
        align: 'right',
        layout: 'vertical',
        margin: 0,
        verticalAlign: 'top',
        y: 25,
        symbolHeight: 280
    },

    series: [{
        name: 'Sales per employee',
        borderWidth: 1,
        data: ${chartData},
        dataLabels: {
            enabled: true,
            color: '#000000'
        }
    }],

    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                yAxis: {
                    labels: {
                        format: '{substr value 0 1}'
                    }
                }
            }
        }]
    }

});
        
        `
        return script;

    },
    "Large heat map": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {
            chart: {
                type: 'heatmap'
            },
        
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                } 
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                } 
            },
        
            colorAxis: {
                min: 0,
                minColor: "${minColor}",
                maxColor:"${maxColor}"
            },
        
            series: [{
                data : ${chartData},
                borderWidth: 0,
                nullColor: '#EFEFEF',
                tooltip: {
                    headerFormat: 'Temperature<br/>',
                    pointFormat: '<b>{point.value} ℃</b>'
                }
            }]
        });
        
        `
        return script;

    },
    "map with color axis": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor,stockColor,treeColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.chart('container', {   
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                } 
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                } 
            },
            series: [{
                type: 'treemap',
                color: '${treeColor}',
                layoutAlgorithm: 'squarified',
                clip: false,
                data:${chartData}
            }]
        });
        
        `
        return script;

    },
    "Flags marking events": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor,stockColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.stockChart('container', {
            rangeSelector: {
                selected: 1
            },
    
            title: {
                text: '${title}',
                align: '${titleAlignment}'
            },
            subtitle: {
                text: '${subTitle}',
                align: '${subTitleAlignment}'
            },
            xAxis: {
                title: {
                    text: '${xAxistext}'
                } 
            },
            yAxis: {
                title: {
                    text: '${yAxistext}'
                } 
            },
            series: [{
                name: 'AAPL Stock Price',
                color: '${stockColor}', 
                data: ${chartData},
                step: true,
                tooltip: {
                    valueDecimals: 2
                }
            }]
        });
        
        `
        return script;

    },
    "Intraday candlestick": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor,stockColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.stockChart('container', {
                rangeSelector: {
                    selected: 1
                },
        
                title: {
                    text: '${title}',
                    align: '${titleAlignment}'
                },
                subtitle: {
                    text: '${subTitle}',
                    align: '${subTitleAlignment}'
                },
                xAxis: {
                    title: {
                        text: '${xAxistext}'
                    } 
                },
                yAxis: {
                    title: {
                        text: '${yAxistext}'
                    } 
                },
        
                series: [{
                    type: 'candlestick',
                    name: 'AAPL Stock Price',
                    color: '${stockColor}', 
                    data: ${chartData},
                    dataGrouping: {
                        units: [
                            [
                                'week', // unit name
                                [1] // allowed multiples
                            ], [
                                'month',
                                [1, 2, 3, 4, 6]
                            ]
                        ]
                    }
                }]
            });
        
        `
        return script;

    },
    "Single series": (userData, title, titleAlignment, subTitle, subTitleAlignment, yAxistext, xAxistext,minColor,maxColor,stockColor) => {
        const chartData = JSON.stringify(userData);
        const script = `Highcharts.stockChart('container', {
                rangeSelector: {
                    selected: 1
                },
                title: {
                    text: '${title}',
                    align: '${titleAlignment}'
                },
                subtitle: {
                    text: '${subTitle}',
                    align: '${subTitleAlignment}'
                },
                xAxis: {
                    title: {
                        text: '${xAxistext}'
                    } 
                },
                yAxis: {
                    title: {
                        text: '${yAxistext}'
                    } 
                },
        
                series: [{
                    name: 'AAPL',
                    color: '${stockColor}', 
                    data: ${chartData},
                    tooltip: {
                        valueDecimals: 2
                    }
                }]
            });
        `
        return script;

    },

}
export default codeSnippets;